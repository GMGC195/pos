@echo off
title POS Print Agent - Branch 2 Installer
set DEST_DIR=%LocalAppData%\POSAgent_Branch2
if not exist "%DEST_DIR%" mkdir "%DEST_DIR%"
taskkill /f /im branch2-agent.exe >nul 2>&1

if not exist "%~dp0branch2-agent.exe" (
    echo [ERROR] branch2-agent.exe not found!
    pause
    exit /b
)

copy /y "%~dp0branch2-agent.exe" "%DEST_DIR%\branch2-agent.exe" >nul
set STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
echo Set WshShell = CreateObject("WScript.Shell") > "%STARTUP_DIR%\branch2-agent.vbs"
echo WshShell.Run chr(34) ^& "%DEST_DIR%\branch2-agent.exe" ^& chr(34), 0, False >> "%STARTUP_DIR%\branch2-agent.vbs"
wscript "%STARTUP_DIR%\branch2-agent.vbs"
echo [OK] Branch 2 Agent Installed and running in background!
pause