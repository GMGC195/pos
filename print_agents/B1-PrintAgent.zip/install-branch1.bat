@echo off
title POS Print Agent - Branch 1 Installer
call "%~dp0install-autostart.bat"
