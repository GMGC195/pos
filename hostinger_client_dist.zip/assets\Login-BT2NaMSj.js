import{o as e}from"./rolldown-runtime-C0FnF6B9.js";import{h as t,m as n}from"./vendor-charts-QYGyGCjd.js";import{c as r}from"./vendor-router-CP39mYx_.js";import{i}from"./branding-BmC7Ep50.js";import{n as a}from"./AuthContext-DRuhpdUG.js";import{$ as o,M as s,Nt as c,Tt as l,Zt as u,c as d,k as f,mt as p,nt as m,st as h,tt as g,ut as _,wt as v,xt as y}from"./vendor-icons-8FYInbYV.js";import{t as b}from"./vendor-motion-VUg_h9-k.js";var x=e(t(),1),S=`/assets/1%20al%20rasaq-BmrqsCd_.png`,C=n(),w=`http://localhost:5000`,T=[{icon:h,title:`Smart Dashboard`,desc:`Real-time insights for smarter decisions`},{icon:y,title:`Mark Attendance`,desc:`Easy check-in & check-out tracking for staff`},{icon:u,title:`Monthly Attendance Reports`,desc:`Aggregated attendance sheets at a glance`},{icon:c,title:`Today's Attendance`,desc:`Monitor active shifts and breaks in real time`}];function E(){let{login:e}=a(),t=r(),[n,c]=(0,x.useState)(`login`),[u,h]=(0,x.useState)({usernameOrEmail:``,password:``,email:``,otp:``,newPassword:``,confirmPassword:``}),[y,E]=(0,x.useState)(``),[D,O]=(0,x.useState)(``),[k,A]=(0,x.useState)(!1),[j,M]=(0,x.useState)(!1),[N,P]=(0,x.useState)(!1),[F,I]=(0,x.useState)(!1),L=(e,t)=>h(n=>({...n,[e]:t})),R=async n=>{n.preventDefault(),E(``),A(!0);try{let n=await fetch(`${w}/api/auth/login`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({usernameOrEmail:u.usernameOrEmail,password:u.password})}),r=await n.json();if(!n.ok)throw Error(r.error||`Login failed`);e(r.user,r.token),I(!0),setTimeout(()=>{let e=r.user?.role?.trim().toLowerCase();t(e===`salary pay operator`?`/payroll`:e===`operator`?`/attendance`:`/pos`,{replace:!0})},750)}catch(e){E(e.message)}finally{A(!1)}},z=async e=>{e.preventDefault(),E(``),O(``),A(!0);try{let e=await fetch(`${w}/api/auth/forgot-password`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({email:u.email})}),t=await e.json();if(!e.ok)throw Error(t.error||`Request failed`);O(t.message),c(`otp`)}catch(e){E(e.message)}finally{A(!1)}};return(0,C.jsxs)(C.Fragment,{children:[(0,C.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Dancing+Script:wght@700&display=swap');

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        .lp-root {
          min-height: 100vh;
          display: flex;
          align-items: stretch;
          font-family: 'Inter', sans-serif;
          background: #0d3038;
          position: relative;
          overflow: hidden;
          perspective: 1500px;
        }

        /* Dot grid */
        .lp-dots {
          position: absolute; inset: 0; pointer-events: none; z-index: 0;
          background-image: radial-gradient(rgba(255,255,255,0.055) 1px, transparent 1px);
          background-size: 28px 28px;
        }

        /* Decorative circles */
        .lp-deco {
          position: absolute; border-radius: 50%; pointer-events: none; z-index: 0;
        }
        .lp-deco-1 {
          width: 480px; height: 480px;
          border: 1.5px solid rgba(255,255,255,0.045);
          top: -160px; right: 390px;
        }
        .lp-deco-2 {
          width: 320px; height: 320px;
          border: 1.5px solid rgba(255,255,255,0.04);
          bottom: -80px; left: 80px;
        }
        .lp-deco-3 {
          width: 240px; height: 240px;
          background: rgba(244,180,0,0.045);
          top: 80px; right: 430px;
        }
        .lp-deco-4 {
          width: 160px; height: 160px;
          background: rgba(255,255,255,0.025);
          bottom: 100px; left: 340px;
        }

        /* ── LEFT PANEL ── */
        .lp-left {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          padding: 48px 36px 36px;
          position: relative;
          z-index: 1;
          text-align: center;
        }

        .lp-logo {
          width: auto; height: 116px;
          object-fit: contain;
          margin-bottom: 22px;
        }

        .lp-welcome {
          font-size: 17px; font-weight: 400;
          color: rgba(255,255,255,0.65);
          margin-bottom: 4px; letter-spacing: 0.3px;
        }

        .lp-brand-name {
          font-size: 46px; font-weight: 900;
          color: #fff; line-height: 1.05;
          letter-spacing: 4px; margin-bottom: 10px;
        }
        .lp-brand-name span { color: #F4B400; }

        .lp-tagline {
          font-size: 11.5px; letter-spacing: 4px;
          text-transform: uppercase;
          color: rgba(255,255,255,0.45);
          margin-bottom: 6px;
        }

        .lp-divider {
          width: 38px; height: 3px;
          background: #F4B400; border-radius: 2px;
          margin: 12px auto 26px; opacity: 0.85;
        }

        /* 2-column feature grid */
        .lp-features {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px 20px;
          width: 100%; max-width: 440px;
          margin-bottom: 26px;
        }

        .lp-feature {
          display: flex; align-items: flex-start; gap: 11px;
          text-align: left;
        }

        .lp-feat-icon-wrap {
          width: 40px; height: 40px; flex-shrink: 0;
          border-radius: 50%;
          border: 1.5px solid rgba(244,180,0,0.4);
          background: rgba(244,180,0,0.09);
          display: flex; align-items: center; justify-content: center;
          color: #F4B400;
        }

        .lp-feat-text h4 {
          font-size: 12.5px; font-weight: 700;
          color: #fff; margin-bottom: 2px;
        }
        .lp-feat-text p {
          font-size: 10.5px;
          color: rgba(255,255,255,0.42);
          line-height: 1.45;
        }

        /* Slogan */
        .lp-slogan { margin-top: 2px; }
        .lp-slogan-script {
          font-family: 'Dancing Script', cursive;
          font-size: 21px; font-weight: 700;
          color: #F4B400;
          display: flex; align-items: center; gap: 7px;
          justify-content: center;
        }
        .lp-slogan-sub {
          font-size: 10.5px; color: rgba(255,255,255,0.35);
          margin-top: 5px; letter-spacing: 0.4px;
        }

        /* ── RIGHT: floating white card ── */
        .lp-right {
          width: 460px;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 32px 28px;
          margin-right: 200px;
          position: relative;
          z-index: 2;
        }

        .lp-card {
          width: 100%;
          background: #fff;
          border-radius: 24px;
          padding: 36px 32px 26px;
          box-shadow:
            0 24px 80px rgba(0,0,0,0.38),
            0 4px 16px rgba(0,0,0,0.18);
        }

        .lp-card-logo {
          display: block;
          width: auto; height: 76px;
          object-fit: contain;
          margin: 0 auto 16px;
          background-color: #0d3038;
          padding: 8px 16px;
          border-radius: 12px;
        }

        .lp-card-title {
          font-size: 25px; font-weight: 800;
          color: #111827;
          text-align: center; margin-bottom: 4px;
        }
        .lp-card-sub {
          font-size: 13.5px; color: #9ca3af;
          text-align: center; margin-bottom: 24px;
        }

        /* Fields */
        .lp-field { margin-bottom: 14px; }
        .lp-label {
          display: block;
          font-size: 13px; font-weight: 600;
          color: #374151; margin-bottom: 7px;
        }
        .lp-input-wrap {
          position: relative;
          display: flex; align-items: center;
        }
        .lp-input-icon {
          position: absolute; left: 13px;
          color: #9ca3af; pointer-events: none; z-index: 1;
          display: flex; align-items: center;
        }
        .lp-input {
          width: 100%;
          padding: 12px 42px 12px 40px;
          border: 1.5px solid #e5e7eb;
          border-radius: 10px;
          font-size: 14px; font-family: inherit;
          color: #111827; background: #fafafa;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
        }
        .lp-input::placeholder { color: #c8ccd4; }
        .lp-input:focus {
          border-color: #F4B400;
          box-shadow: 0 0 0 3px rgba(244,180,0,0.14);
          background: #fff;
        }
        .lp-eye {
          position: absolute; right: 11px;
          background: none; border: none; cursor: pointer;
          color: #9ca3af; padding: 4px;
          display: flex; align-items: center;
          transition: color 0.15s;
        }
        .lp-eye:hover { color: #374151; }

        /* Forgot row */
        .lp-forgot-row {
          text-align: right; margin-top: -4px; margin-bottom: 18px;
        }
        .lp-forgot-btn {
          background: none; border: none;
          color: #D4A000; font-size: 13px; font-weight: 600;
          cursor: pointer; font-family: inherit;
          transition: color 0.15s;
        }
        .lp-forgot-btn:hover { color: #b38a00; }

        /* Submit button */
        .lp-submit {
          width: 100%; padding: 13.5px;
          background: linear-gradient(135deg, #F4B400, #D4A000);
          border: none; border-radius: 11px;
          color: #000; font-size: 14.5px; font-weight: 800;
          letter-spacing: 1.5px; text-transform: uppercase;
          cursor: pointer; font-family: inherit;
          box-shadow: 0 4px 16px rgba(244,180,0,0.38);
          transition: transform 0.15s, box-shadow 0.15s, opacity 0.15s;
          display: flex; align-items: center; justify-content: center; gap: 9px;
        }
        .lp-submit:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 8px 28px rgba(244,180,0,0.5);
        }
        .lp-submit:active:not(:disabled) { transform: translateY(0); }
        .lp-submit:disabled { opacity: 0.6; cursor: not-allowed; }

        /* Secondary buttons */
        .lp-back-btn {
          background: none; border: none; color: #9ca3af;
          font-size: 12.5px; cursor: pointer; width: 100%;
          text-align: center; padding: 8px; text-decoration: underline;
          font-family: inherit; margin-top: 8px; display: block;
        }
        .lp-link-btn {
          background: none; border: none; color: #D4A000;
          font-size: 13px; cursor: pointer; font-weight: 700;
          font-family: inherit; display: block;
          text-align: center; margin-top: 8px; padding: 4px;
        }

        /* Alert messages */
        .lp-error {
          background: rgba(239,68,68,0.07);
          border: 1px solid rgba(239,68,68,0.25);
          border-radius: 8px; padding: 10px 13px;
          color: #dc2626; font-size: 13px;
          display: flex; align-items: center; gap: 8px;
          margin-bottom: 14px;
        }
        .lp-info {
          background: rgba(16,185,129,0.07);
          border: 1px solid rgba(16,185,129,0.25);
          border-radius: 8px; padding: 10px 13px;
          color: #059669; font-size: 13px;
          display: flex; align-items: center; gap: 8px;
          margin-bottom: 14px;
        }

        .lp-otp-hint {
          font-size: 11px; color: #9ca3af; margin-top: 5px;
        }

        /* Footer */
        .lp-card-footer {
          margin-top: 18px; text-align: center;
          color: #9ca3af; font-size: 11.5px;
          border-top: 1px solid #f0f0f0; padding-top: 14px;
          line-height: 1.75;
        }
        .lp-version-badge {
          display: inline-block;
          background: #f3f4f6; color: #6b7280;
          font-size: 10px; font-weight: 600;
          padding: 2px 8px; border-radius: 20px;
          border: 1px solid #e5e7eb; margin-left: 4px;
          vertical-align: middle;
        }

        /* ── RESPONSIVE ── */
        @media (max-width: 1024px) {
          .lp-brand-name { font-size: 38px; }
          .lp-right { width: 420px; }
        }

        @media (max-width: 820px) {
          .lp-root { flex-direction: column; justify-content: center; align-items: center; }
          .lp-left { display: none !important; }
          .lp-features { display: none !important; }
          .lp-right { width: 100%; padding: 16px; margin-right: 0; }
          .lp-card { padding: 26px 22px 20px; border-radius: 20px; }
        }

        @media (max-width: 480px) {
          .lp-left { display: none !important; }
          .lp-right { padding: 12px; }
          .lp-card { padding: 22px 16px 16px; }
        }
      `}),(0,C.jsxs)(`div`,{className:`lp-root`,children:[(0,C.jsx)(`div`,{className:`lp-dots`}),(0,C.jsx)(`div`,{className:`lp-deco lp-deco-1`}),(0,C.jsx)(`div`,{className:`lp-deco lp-deco-2`}),(0,C.jsx)(`div`,{className:`lp-deco lp-deco-3`}),(0,C.jsx)(`div`,{className:`lp-deco lp-deco-4`}),(0,C.jsxs)(b.div,{className:`lp-left`,variants:{hidden:{opacity:0,rotateX:-180,z:-100},show:{opacity:1,rotateX:0,z:0,transition:{type:`spring`,damping:15,stiffness:50,duration:1.2}},success:{opacity:0,rotateX:180,z:-100,transition:{ease:`easeInOut`,duration:.75}}},initial:`hidden`,animate:F?`success`:`show`,children:[(0,C.jsx)(`img`,{src:S,alt:i,className:`lp-logo`}),(0,C.jsx)(`div`,{className:`lp-divider`}),(0,C.jsx)(`div`,{className:`lp-features`,children:T.map(e=>{let t=e.icon;return(0,C.jsxs)(`div`,{className:`lp-feature`,children:[(0,C.jsx)(`div`,{className:`lp-feat-icon-wrap`,children:(0,C.jsx)(t,{size:18,strokeWidth:2})}),(0,C.jsxs)(`div`,{className:`lp-feat-text`,children:[(0,C.jsx)(`h4`,{children:e.title}),(0,C.jsx)(`p`,{children:e.desc})]})]},e.title)})}),(0,C.jsxs)(`div`,{className:`lp-slogan`,children:[(0,C.jsxs)(`div`,{className:`lp-slogan-script`,children:[(0,C.jsx)(`span`,{style:{opacity:.7,fontSize:14},children:`→`}),`Cook. Serve. Satisfy.`,(0,C.jsx)(`span`,{style:{opacity:.7,fontSize:14},children:`←`})]}),(0,C.jsx)(`p`,{className:`lp-slogan-sub`,children:`All-in-one Restaurant Management Solution`})]})]}),(0,C.jsx)(b.div,{className:`lp-right`,variants:{hidden:{opacity:0,rotateX:180,z:-100},show:{opacity:1,rotateX:0,z:0,transition:{type:`spring`,damping:15,stiffness:50,duration:1.2,delay:.1}},success:{opacity:0,rotateX:-180,z:-100,transition:{ease:`easeInOut`,duration:.75}}},initial:`hidden`,animate:F?`success`:`show`,children:(0,C.jsxs)(`div`,{className:`lp-card`,children:[(0,C.jsx)(`img`,{src:S,alt:i,className:`lp-card-logo`}),(0,C.jsxs)(`h2`,{className:`lp-card-title`,children:[n===`login`&&`Welcome Back!`,n===`forgot`&&`Forgot Password`,n===`otp`&&`Enter OTP`,n===`reset`&&`Reset Password`]}),(0,C.jsxs)(`p`,{className:`lp-card-sub`,children:[n===`login`&&`Sign in to your AL RAWAQ account`,n===`forgot`&&`We'll send a verification code to your email`,n===`otp`&&`OTP sent to ${u.email}`,n===`reset`&&`Choose a strong new password`]}),y&&(0,C.jsxs)(`div`,{className:`lp-error`,children:[(0,C.jsx)(f,{size:15}),y]}),D&&(0,C.jsxs)(`div`,{className:`lp-info`,children:[(0,C.jsx)(f,{size:15}),D]}),n===`login`&&(0,C.jsxs)(`form`,{onSubmit:R,children:[(0,C.jsxs)(`div`,{className:`lp-field`,children:[(0,C.jsx)(`label`,{className:`lp-label`,children:`Username or Email`}),(0,C.jsxs)(`div`,{className:`lp-input-wrap`,children:[(0,C.jsx)(`span`,{className:`lp-input-icon`,children:(0,C.jsx)(d,{size:16,strokeWidth:2})}),(0,C.jsx)(`input`,{className:`lp-input`,placeholder:`Enter username or email`,value:u.usernameOrEmail,onChange:e=>L(`usernameOrEmail`,e.target.value),required:!0,autoFocus:!0})]})]}),(0,C.jsxs)(`div`,{className:`lp-field`,children:[(0,C.jsx)(`label`,{className:`lp-label`,children:`Password`}),(0,C.jsxs)(`div`,{className:`lp-input-wrap`,children:[(0,C.jsx)(`span`,{className:`lp-input-icon`,children:(0,C.jsx)(g,{size:16,strokeWidth:2})}),(0,C.jsx)(`input`,{className:`lp-input`,type:j?`text`:`password`,placeholder:`Enter your password`,value:u.password,onChange:e=>L(`password`,e.target.value),required:!0}),(0,C.jsx)(`button`,{type:`button`,className:`lp-eye`,onClick:()=>M(e=>!e),children:j?(0,C.jsx)(l,{size:16,strokeWidth:2}):(0,C.jsx)(v,{size:16,strokeWidth:2})})]})]}),(0,C.jsx)(`div`,{className:`lp-forgot-row`,children:(0,C.jsx)(`button`,{type:`button`,className:`lp-forgot-btn`,onClick:()=>{E(``),O(``),c(`forgot`)},children:`Forgot password?`})}),(0,C.jsxs)(`button`,{type:`submit`,className:`lp-submit`,disabled:k,children:[(0,C.jsx)(m,{size:17,strokeWidth:2.5}),k?`SIGNING IN…`:`SIGN IN`]})]}),n===`forgot`&&(0,C.jsxs)(`form`,{onSubmit:z,children:[(0,C.jsxs)(`div`,{className:`lp-field`,children:[(0,C.jsx)(`label`,{className:`lp-label`,children:`Your Email Address`}),(0,C.jsxs)(`div`,{className:`lp-input-wrap`,children:[(0,C.jsx)(`span`,{className:`lp-input-icon`,children:(0,C.jsx)(o,{size:16,strokeWidth:2})}),(0,C.jsx)(`input`,{className:`lp-input`,type:`email`,placeholder:`Enter your email`,value:u.email,onChange:e=>L(`email`,e.target.value),required:!0,autoFocus:!0})]})]}),(0,C.jsxs)(`button`,{type:`submit`,className:`lp-submit`,disabled:k,children:[(0,C.jsx)(s,{size:16,strokeWidth:2.5}),k?`SENDING…`:`SEND OTP`]}),(0,C.jsx)(`button`,{type:`button`,className:`lp-back-btn`,onClick:()=>{E(``),c(`login`)},children:`← Back to Login`})]}),n===`otp`&&(0,C.jsxs)(`form`,{onSubmit:e=>{e.preventDefault(),c(`reset`)},children:[(0,C.jsxs)(`div`,{className:`lp-field`,children:[(0,C.jsx)(`label`,{className:`lp-label`,children:`6-Digit OTP`}),(0,C.jsxs)(`div`,{className:`lp-input-wrap`,children:[(0,C.jsx)(`span`,{className:`lp-input-icon`,children:(0,C.jsx)(p,{size:16,strokeWidth:2})}),(0,C.jsx)(`input`,{className:`lp-input`,style:{letterSpacing:8,fontWeight:800,fontSize:20,textAlign:`center`,paddingLeft:44},placeholder:`000000`,maxLength:6,value:u.otp,onChange:e=>L(`otp`,e.target.value.replace(/\D/g,``)),required:!0,autoFocus:!0})]}),(0,C.jsx)(`p`,{className:`lp-otp-hint`,children:`Check your inbox and spam folder`})]}),(0,C.jsxs)(`button`,{type:`submit`,className:`lp-submit`,disabled:u.otp.length<6,children:[(0,C.jsx)(f,{size:16,strokeWidth:2.5}),`VERIFY OTP`]}),(0,C.jsx)(`button`,{type:`button`,className:`lp-link-btn`,onClick:z,disabled:k,children:k?`Resending…`:`↺  Resend OTP`}),(0,C.jsx)(`button`,{type:`button`,className:`lp-back-btn`,onClick:()=>{E(``),c(`forgot`)},children:`← Change Email`})]}),n===`reset`&&(0,C.jsxs)(`form`,{onSubmit:async e=>{if(e.preventDefault(),E(``),u.newPassword!==u.confirmPassword)return E(`Passwords do not match`);A(!0);try{let e=await fetch(`${w}/api/auth/reset-password`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({email:u.email,otp:u.otp,newPassword:u.newPassword})}),t=await e.json();if(!e.ok)throw Error(t.error||`Reset failed`);O(`Password reset! You can now log in.`),c(`login`)}catch(e){E(e.message)}finally{A(!1)}},children:[(0,C.jsxs)(`div`,{className:`lp-field`,children:[(0,C.jsx)(`label`,{className:`lp-label`,children:`New Password`}),(0,C.jsxs)(`div`,{className:`lp-input-wrap`,children:[(0,C.jsx)(`span`,{className:`lp-input-icon`,children:(0,C.jsx)(_,{size:16,strokeWidth:2})}),(0,C.jsx)(`input`,{className:`lp-input`,type:N?`text`:`password`,placeholder:`Enter new password`,value:u.newPassword,onChange:e=>L(`newPassword`,e.target.value),required:!0,minLength:6,autoFocus:!0}),(0,C.jsx)(`button`,{type:`button`,className:`lp-eye`,onClick:()=>P(e=>!e),children:N?(0,C.jsx)(l,{size:16,strokeWidth:2}):(0,C.jsx)(v,{size:16,strokeWidth:2})})]})]}),(0,C.jsxs)(`div`,{className:`lp-field`,children:[(0,C.jsx)(`label`,{className:`lp-label`,children:`Confirm Password`}),(0,C.jsxs)(`div`,{className:`lp-input-wrap`,children:[(0,C.jsx)(`span`,{className:`lp-input-icon`,children:(0,C.jsx)(g,{size:16,strokeWidth:2})}),(0,C.jsx)(`input`,{className:`lp-input`,type:`password`,placeholder:`Confirm new password`,value:u.confirmPassword,onChange:e=>L(`confirmPassword`,e.target.value),required:!0})]})]}),(0,C.jsxs)(`button`,{type:`submit`,className:`lp-submit`,disabled:k,children:[(0,C.jsx)(f,{size:16,strokeWidth:2.5}),k?`RESETTING…`:`RESET PASSWORD`]})]}),(0,C.jsxs)(`div`,{className:`lp-card-footer`,children:[`© `,new Date().getFullYear(),` `,i,` — Restaurant ERP.`,(0,C.jsx)(`br`,{}),`All rights reserved.`,(0,C.jsx)(`span`,{className:`lp-version-badge`,children:``})]})]})})]})]})}export{E as default};