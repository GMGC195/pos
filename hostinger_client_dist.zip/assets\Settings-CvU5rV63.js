import{o as e}from"./rolldown-runtime-C0FnF6B9.js";import{h as t,m as n}from"./vendor-charts-QYGyGCjd.js";import{st as r}from"./vendor-misc-D0IzzYHV.js";import{n as i}from"./AuthContext-DRuhpdUG.js";import{t as a}from"./api-Dg-qdIy2.js";import{$ as o,A as s,Et as c,Ht as ee,I as te,Jt as ne,O as re,P as ie,S as ae,Tt as l,W as oe,at as se,c as u,ct as ce,dt as le,k as ue,lt as de,s as fe,t as pe,tt as d,u as me,v as he,wt as f,z as ge,zt as _e}from"./vendor-icons-8FYInbYV.js";var p=e(t(),1),m=n();function h(){let{user:e,updateUser:t}=i(),[n,c]=(0,p.useState)(`account`),[h,g]=(0,p.useState)(!1),[_,ye]=(0,p.useState)(localStorage.getItem(`printMode`)||`standard`),[be,xe]=(0,p.useState)(!1),[v,y]=(0,p.useState)(()=>localStorage.getItem(`printerIp`)||`127.0.0.1`),[b,Se]=(0,p.useState)(!1),[x,S]=(0,p.useState)(!1),[C,w]=(0,p.useState)(`block`),[T,Ce]=(0,p.useState)(()=>localStorage.getItem(`pos_stock_view_mode`)||`cards`),[E,D]=(0,p.useState)([`mr.caffee25@gmail.com`]),O=[{value:`block`,title:`Block Order`,badge:`Default`,badgeColor:`#dc2626`,badgeBg:`rgba(239, 68, 68, 0.12)`,icon:s,iconColor:`#dc2626`,iconBg:`rgba(239, 68, 68, 0.12)`,desc:`Stop order if ingredients are out of stock.`,detail:`Strict inventory protection: orders cannot be placed if recipe ingredients are out of stock.`},{value:`allow_negative`,title:`Allow Negative`,badge:`Deficit`,badgeColor:`#d97706`,badgeBg:`rgba(217, 119, 6, 0.12)`,icon:de,iconColor:`#d97706`,iconBg:`rgba(217, 119, 6, 0.12)`,desc:`Allow order & deduct stock below zero.`,detail:`Flexible tracking: orders proceed smoothly while stock counts track deficit below zero.`},{value:`ignore`,title:`Ignore Stock`,badge:`Bypass`,badgeColor:`#4f46e5`,badgeBg:`rgba(79, 70, 229, 0.12)`,icon:l,iconColor:`#4f46e5`,iconBg:`rgba(79, 70, 229, 0.12)`,desc:`Allow order without stock check or deduction.`,detail:`Unrestricted checkout: stock verification and recipe ingredient deductions are completely bypassed.`}],[we,Te]=(0,p.useState)(``),[k,A]=(0,p.useState)(``),[j,M]=(0,p.useState)(!1),N=(0,p.useRef)(null),P=(0,p.useRef)(null),[F,I]=(0,p.useState)({username:e?.username||``,email:e?.email||``,password:``,confirmPassword:``}),[L,Ee]=(0,p.useState)(!1),[De,Oe]=(0,p.useState)([]),[ke,Ae]=(0,p.useState)([]),[je,Me]=(0,p.useState)([]),[Ne,R]=(0,p.useState)(!1),[z,B]=(0,p.useState)(null),[V,H]=(0,p.useState)(!1),[Pe,U]=(0,p.useState)(!1),[W,G]=(0,p.useState)({username:``,email:``,password:``,role:`Operator`,shift:``,branch:``,employee_id:``}),Fe=[`Day`,`Night`],Ie=[`Restaurant 1`,`Restaurant 2`,`Restaurant 3`],[Le,K]=(0,p.useState)(!1),[q,Re]=(0,p.useState)(``),[J,ze]=(0,p.useState)(`Admin`),[Y,Be]=(0,p.useState)(`system`),[X,Ve]=(0,p.useState)(`All`),[He,Z]=(0,p.useState)(null);(0,p.useEffect)(()=>{let e=e=>{N.current&&!N.current.contains(e.target)&&U(!1),P.current&&!P.current.contains(e.target)&&K(!1)};return document.addEventListener(`mousedown`,e),()=>document.removeEventListener(`mousedown`,e)},[]);let Ue=async()=>{try{let e=await a.get(`/api/employees/working-hours/list`);Me(e.data)}catch{r.error(`Failed to fetch shifts`)}};(0,p.useEffect)(()=>{(async()=>{try{let e=await a.get(`/api/auth/profile`);e.data&&(t(e.data),I(t=>({...t,username:e.data.username,email:e.data.email})))}catch(e){console.error(`Failed to refresh profile`,e)}})()},[]),(0,p.useEffect)(()=>{let t=e?.role?.toLowerCase(),r=t===`admin`||t===`developer`;n===`users`&&r&&(Q(),Ue(),Xe()),(n===`hardware`||(n===`pos_settings`||n===`report_emails`)&&r)&&We()},[n,e?.role]);let We=async()=>{try{let e=await a.get(`/api/settings`);if(e.data){xe(e.data.auto_print_enabled);let t=localStorage.getItem(`printerIp`),n=e.data.printer_ip,r=n&&n.trim()&&n!==`127.0.0.1`?n.trim():t&&t.trim()?t.trim():n||`127.0.0.1`;if(y(r),localStorage.setItem(`printerIp`,r),w(e.data.low_stock_behavior||`block`),Array.isArray(e.data.report_emails)&&e.data.report_emails.length>0)D(e.data.report_emails);else if(typeof e.data.report_emails==`string`)try{let t=JSON.parse(e.data.report_emails);Array.isArray(t)&&t.length>0&&D(t)}catch{e.data.report_emails&&D([e.data.report_emails])}}}catch(e){console.error(`Failed to fetch settings`,e)}},Ge=async e=>{e&&e.preventDefault();let t=(v||``).trim();if(!t){r.error(`Please enter a printer IP address`);return}Se(!0);try{localStorage.setItem(`printerIp`,t),y(t),await a.put(`/api/settings`,{printer_ip:t}),S(!0),setTimeout(()=>S(!1),2500),r.success(`Thermal Printer IP saved successfully!`)}catch(e){console.error(`Failed to save printer IP to server:`,e),S(!0),setTimeout(()=>S(!1),2500),r.success(`Printer IP saved for this device`)}finally{Se(!1)}},Ke=async()=>{M(!0);try{await a.put(`/api/settings`,{auto_print_enabled:be,printer_ip:v,low_stock_behavior:C,report_emails:E}),v&&localStorage.setItem(`printerIp`,v.trim()),r.success(`Settings saved globally`)}catch{r.error(`Failed to save settings`)}finally{M(!1)}},qe=e=>{e&&e.preventDefault();let t=we.trim().toLowerCase();if(A(``),!t){A(`Please enter an email address`);return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t)){A(`Please enter a valid email address (e.g. name@domain.com)`);return}if(E.some(e=>e.toLowerCase()===t)){A(`This email is already in the recipient list`);return}let n=[...E,t];D(n),Te(``),Ye(n)},Je=e=>{if(E.length<=1){r.error(`At least one recipient email is required`);return}let t=E.filter((t,n)=>n!==e);D(t),Ye(t)},Ye=async e=>{M(!0);try{await a.put(`/api/settings`,{auto_print_enabled:be,printer_ip:v,low_stock_behavior:C,report_emails:e}),r.success(`Recipient emails updated successfully`)}catch{r.error(`Failed to update recipient emails`)}finally{M(!1)}},Xe=async()=>{try{let e=await a.get(`/api/auth/employee-options`);Ae(e.data||[])}catch(e){console.error(`Failed to load employee options:`,e)}},Q=async()=>{try{let e=await a.get(`/api/auth/users`);Oe(e.data)}catch{r.error(`Failed to fetch users`)}},Ze=De.filter(e=>{let t=e.username&&e.username.toLowerCase().includes(q.toLowerCase())||e.email&&e.email.toLowerCase().includes(q.toLowerCase()),n=e.role===`Employee`,r=Y===`system`?!n:n,i=!1;i=J===`All`||e.role===J;let a=!0;if(X!==`All`)if(e.role===`Admin`||e.role===`Developer`||e.role===`Management`)a=!0;else{let t=e.branch||``;a=t.includes(`Branch ${X}`)||t.includes(`Restaurant ${X}`)}return t&&r&&i&&a}).sort((e,t)=>{let n=e=>e===`Developer`?3:e===`Admin`?2:+(e===`Management`);return n(t.role)-n(e.role)}),Qe=async e=>{if(e.preventDefault(),F.password&&F.password!==F.confirmPassword)return r.error(`Passwords do not match`);g(!0);try{let e=await a.put(`/api/auth/profile`,F);t(e.data.user),r.success(`Profile updated successfully`),I(e=>({...e,password:``,confirmPassword:``}))}catch(e){r.error(e.response?.data?.error||`Update failed`)}finally{g(!1)}},$e=async e=>{e.preventDefault(),g(!0);let t={...W};[`Order Taker`,`Cashier`].includes(t.role)&&!t.branch&&(t.branch=`Branch 1`),t.role===`Operator`&&!t.branch&&(t.branch=`Restaurant 1`);try{await a.post(`/api/auth/users`,t),r.success(`User created successfully`),R(!1),G({username:``,email:``,password:``,role:`Operator`,shift:``,branch:``,employee_id:``}),H(!1),U(!1),K(!1),Q()}catch(e){r.error(e.response?.data?.error||`Creation failed`)}finally{g(!1)}},et=async e=>{e.preventDefault(),g(!0);let t={...W};[`Order Taker`,`Cashier`].includes(t.role)&&!t.branch&&(t.branch=`Branch 1`),t.role===`Operator`&&!t.branch&&(t.branch=`Restaurant 1`);try{await a.put(`/api/auth/users/${z.id}`,t),r.success(`User updated successfully`),B(null),G({username:``,email:``,password:``,role:`Operator`,shift:``,branch:``,employee_id:``}),H(!1),U(!1),K(!1),Q()}catch(e){r.error(e.response?.data?.error||`Update failed`)}finally{g(!1)}},tt=e=>{Z(e)},nt=async()=>{if(He)try{await a.delete(`/api/auth/users/${He}`),r.success(`User deleted`),Q()}catch(e){r.error(e.response?.data?.error||`Deletion failed`)}finally{Z(null)}},rt=e=>{B(e),G({username:e.username,email:e.email,password:``,role:e.role,shift:e.shift||``,branch:e.branch||``,employee_id:e.employee_id||``}),R(!0),U(!1),K(!1)},it=e=>{e.preventDefault(),e.stopPropagation(),Ee(!L)},at=e?.role?.toLowerCase(),$=at===`admin`||at===`developer`;return(0,m.jsxs)(`div`,{className:`settings-container`,children:[(0,m.jsxs)(`div`,{className:`settings-header`,children:[(0,m.jsx)(`h1`,{children:`System Settings`}),(0,m.jsx)(`p`,{children:`Manage your account and team`})]}),(0,m.jsxs)(`div`,{className:`settings-layout`,children:[(0,m.jsxs)(`aside`,{className:`settings-nav`,children:[(0,m.jsxs)(`button`,{className:`settings-nav-item ${n===`account`?`active`:``}`,onClick:()=>c(`account`),children:[(0,m.jsx)(u,{size:18}),` My Account`]}),$&&(0,m.jsxs)(`button`,{className:`settings-nav-item ${n===`users`?`active`:``}`,onClick:()=>c(`users`),children:[(0,m.jsx)(fe,{size:18}),` User Management`]}),(0,m.jsxs)(`button`,{className:`settings-nav-item ${n===`hardware`?`active`:``}`,onClick:()=>c(`hardware`),children:[(0,m.jsx)(ee,{size:18}),` Hardware & Printers`]}),$&&(0,m.jsxs)(`button`,{className:`settings-nav-item ${n===`pos_settings`?`active`:``}`,onClick:()=>c(`pos_settings`),children:[(0,m.jsx)(ae,{size:18}),` POS Options`]}),$&&(0,m.jsxs)(`button`,{className:`settings-nav-item ${n===`report_emails`?`active`:``}`,onClick:()=>c(`report_emails`),children:[(0,m.jsx)(o,{size:18}),` Report Emails`]})]}),(0,m.jsxs)(`main`,{className:`settings-content`,children:[n===`hardware`&&(0,m.jsxs)(`div`,{className:`settings-card fade-in`,children:[(0,m.jsx)(`div`,{className:`card-header`,children:(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`h2`,{children:`Hardware & Printers`}),(0,m.jsx)(`p`,{children:`Configure device-specific hardware settings (These settings apply only to this device)`})]})}),(0,m.jsxs)(`div`,{className:`settings-form`,children:[(0,m.jsxs)(`div`,{className:`form-group`,style:{maxWidth:400},children:[(0,m.jsx)(`label`,{children:`Print Mode`}),(0,m.jsxs)(`select`,{value:_,onChange:e=>{ye(e.target.value),localStorage.setItem(`printMode`,e.target.value),r.success(`Print mode saved for this device`)},style:{padding:`12px`,borderRadius:`8px`,border:`1px solid var(--surface-2)`,width:`100%`},children:[(0,m.jsx)(`option`,{value:`standard`,children:`Standard Print (Browser / Laptop USB)`}),(0,m.jsx)(`option`,{value:`cloud`,children:`Cloud Auto-Printing (Thermal Printer)`}),(0,m.jsx)(`option`,{value:`rawbt`,children:`RawBT App (Android Mobile Direct Print)`})]}),(0,m.jsx)(`p`,{style:{fontSize:13,color:`var(--text-muted)`,marginTop:8,lineHeight:1.5},children:_===`standard`?`Uses the standard browser print dialog. Best for laptops or desktop computers connected to a USB printer.`:_===`cloud`?`Automatically pushes new orders directly to the kitchen thermal printer over the local network via Pusher.`:`Uses the RawBT Android app to print directly to a network/LAN printer. Best for waiters punching orders from mobile phones.`})]}),_===`cloud`&&(0,m.jsxs)(`div`,{className:`form-group`,style:{maxWidth:460,marginTop:24,paddingTop:24,borderTop:`1px solid var(--surface-2)`},children:[(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:`8px`},children:[(0,m.jsx)(`label`,{style:{fontSize:`15px`,fontWeight:600,color:`var(--text-primary)`,margin:0},children:`Cloud Printer Configuration`}),(0,m.jsx)(`span`,{style:{fontSize:`11px`,padding:`2px 8px`,borderRadius:`6px`,background:`rgba(16, 185, 129, 0.12)`,color:`#10b981`,fontWeight:600},children:`Port 9100 (TCP RAW)`})]}),(0,m.jsxs)(`div`,{style:{marginTop:`14px`},children:[(0,m.jsx)(`label`,{style:{fontSize:`13px`,fontWeight:500,color:`var(--text-secondary)`,display:`block`,marginBottom:`6px`},children:`Thermal Printer IP Address`}),(0,m.jsxs)(`div`,{style:{display:`flex`,gap:`8px`,alignItems:`center`},children:[(0,m.jsx)(`div`,{style:{position:`relative`,flex:1},children:(0,m.jsx)(`input`,{type:`text`,value:v,onChange:e=>{y(e.target.value),S(!1)},onKeyDown:e=>{e.key===`Enter`&&(e.preventDefault(),Ge())},placeholder:`e.g. 192.168.1.100`,style:{padding:`11px 14px`,borderRadius:`8px`,border:x?`1.5px solid #10b981`:`1px solid var(--surface-2)`,width:`100%`,background:`var(--surface)`,fontSize:`14px`,fontFamily:`monospace`,color:`var(--text-primary)`,boxSizing:`border-box`,transition:`border-color 0.2s ease`,outline:`none`}})}),(0,m.jsx)(`button`,{type:`button`,id:`btn-save-printer-ip`,onClick:Ge,disabled:b,style:{display:`inline-flex`,alignItems:`center`,justifyContent:`center`,gap:`7px`,padding:`11px 20px`,background:x?`#10b981`:`var(--primary, #e11d48)`,color:`#ffffff`,border:`none`,borderRadius:`8px`,fontSize:`13.5px`,fontWeight:600,cursor:b?`not-allowed`:`pointer`,opacity:b?.75:1,whiteSpace:`nowrap`,boxShadow:`0 2px 6px rgba(0, 0, 0, 0.12)`,transition:`all 0.2s ease`,flexShrink:0},children:b?(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(te,{size:15,className:`spin`}),(0,m.jsx)(`span`,{children:`Saving...`})]}):x?(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(ne,{size:16}),(0,m.jsx)(`span`,{children:`Saved`})]}):(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(ie,{size:16}),(0,m.jsx)(`span`,{children:`Save`})]})})]}),(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`6px`,marginTop:`8px`},children:[(0,m.jsx)(le,{size:13,color:`var(--text-muted)`}),(0,m.jsxs)(`p`,{style:{fontSize:`12px`,color:`var(--text-muted)`,margin:0},children:[`Enter the local IP address of your receipt thermal printer (e.g., 192.168.1.87) and click `,(0,m.jsx)(`strong`,{children:`Save`}),`.`]})]})]})]})]})]}),n===`pos_settings`&&$&&(0,m.jsxs)(`div`,{className:`settings-card fade-in`,children:[(0,m.jsx)(`div`,{className:`card-header`,children:(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`h2`,{children:`POS Options`}),(0,m.jsx)(`p`,{children:`Global settings for Point of Sale functionality`})]})}),(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,gap:`12px`,padding:`12px 16px`,background:`rgba(244, 180, 0, 0.08)`,border:`1px solid rgba(244, 180, 0, 0.25)`,borderRadius:`12px`,marginBottom:`20px`},children:[(0,m.jsx)(le,{size:18,style:{color:`var(--primary)`,flexShrink:0,marginTop:`2px`}}),(0,m.jsxs)(`div`,{style:{fontSize:`13px`,color:`var(--text-secondary)`,lineHeight:`1.5`},children:[(0,m.jsx)(`strong`,{style:{color:`var(--text-primary)`,display:`block`,marginBottom:`2px`},children:`Insufficient Inventory Rule`}),`Controls checkout behavior when an item or its recipe ingredients are depleted.`]})]}),(0,m.jsxs)(`div`,{className:`settings-form`,children:[(0,m.jsxs)(`div`,{children:[(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:`12px`,flexWrap:`wrap`,gap:`10px`},children:[(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`label`,{style:{fontSize:`14px`,fontWeight:700,color:`var(--text-primary)`,display:`block`,margin:0},children:`Insufficient Stock Behavior`}),(0,m.jsx)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:`Select how orders are handled when stock is depleted`})]}),(0,m.jsxs)(`div`,{style:{display:`inline-flex`,padding:`3px`,background:`var(--surface-2)`,borderRadius:`8px`,gap:`2px`},children:[(0,m.jsxs)(`button`,{type:`button`,className:`pos-view-pill-btn ${T===`cards`?`active`:``}`,onClick:()=>{Ce(`cards`),localStorage.setItem(`pos_stock_view_mode`,`cards`)},children:[(0,m.jsx)(ce,{size:13}),` Cards Grid`]}),(0,m.jsxs)(`button`,{type:`button`,className:`pos-view-pill-btn ${T===`dropdown`?`active`:``}`,onClick:()=>{Ce(`dropdown`),localStorage.setItem(`pos_stock_view_mode`,`dropdown`)},children:[(0,m.jsx)(se,{size:13}),` Dropdown`]})]})]}),T===`cards`&&(0,m.jsx)(`div`,{className:`pos-stock-grid`,children:O.map(e=>{let t=C===e.value;return(0,m.jsxs)(`div`,{onClick:()=>w(e.value),className:`pos-stock-card ${t?`selected`:``}`,children:[(0,m.jsx)(`div`,{style:{width:16,height:16,borderRadius:`50%`,border:t?`5px solid var(--primary)`:`2px solid #cbd5e1`,background:`#fff`,flexShrink:0,marginTop:`2px`,transition:`all 0.15s ease`}}),(0,m.jsxs)(`div`,{style:{flex:1,minWidth:0},children:[(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:`6px`},children:[(0,m.jsx)(`span`,{style:{fontWeight:700,fontSize:`13px`,color:`var(--text-primary)`,whiteSpace:`nowrap`},children:e.title}),(0,m.jsx)(`span`,{style:{fontSize:`10px`,fontWeight:700,padding:`1px 5px`,borderRadius:`4px`,background:e.badgeBg,color:e.badgeColor,flexShrink:0},children:e.badge})]}),(0,m.jsx)(`p`,{style:{fontSize:`11px`,color:`var(--text-secondary)`,lineHeight:`1.35`,margin:`3px 0 0 0`},children:e.desc})]})]},e.value)})}),T===`dropdown`&&(0,m.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`12px`,maxWidth:`520px`},children:[(0,m.jsxs)(`select`,{value:C,onChange:e=>w(e.target.value),style:{width:`100%`,padding:`11px 14px`,borderRadius:`10px`,border:`1.5px solid var(--surface-2)`,background:`var(--surface)`,fontSize:`13.5px`,fontWeight:600,color:`var(--text-primary)`,cursor:`pointer`},children:[(0,m.jsx)(`option`,{value:`block`,children:`Block Order (Default) — Stop checkout if out of stock`}),(0,m.jsx)(`option`,{value:`allow_negative`,children:`Allow Negative Stock — Allow checkout & deduct below zero`}),(0,m.jsx)(`option`,{value:`ignore`,children:`Ignore Stock Check — Allow checkout without stock checks`})]}),(()=>{let e=O.find(e=>e.value===C)||O[0],t=e.icon;return(0,m.jsxs)(`div`,{style:{padding:`12px 14px`,borderRadius:`10px`,background:`rgba(244, 180, 0, 0.06)`,border:`1.5px solid var(--primary)`,display:`flex`,alignItems:`center`,gap:`12px`},children:[(0,m.jsx)(`div`,{style:{width:32,height:32,borderRadius:8,background:e.iconBg,color:e.iconColor,display:`flex`,alignItems:`center`,justifyContent:`center`,flexShrink:0},children:(0,m.jsx)(t,{size:17})}),(0,m.jsxs)(`div`,{style:{flex:1},children:[(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`8px`,marginBottom:`2px`},children:[(0,m.jsx)(`strong`,{style:{fontSize:`13px`,color:`var(--text-primary)`},children:e.title}),(0,m.jsx)(`span`,{style:{fontSize:`10.5px`,fontWeight:700,padding:`1px 6px`,borderRadius:`4px`,background:e.badgeBg,color:e.badgeColor},children:e.badge})]}),(0,m.jsx)(`p`,{style:{fontSize:`12px`,color:`var(--text-secondary)`,margin:0,lineHeight:1.4},children:e.detail})]})]})})()]})]}),(0,m.jsxs)(`div`,{style:{marginTop:24,display:`flex`,alignItems:`center`,gap:`14px`,flexWrap:`wrap`},children:[(0,m.jsx)(`button`,{type:`button`,className:`btn-save`,onClick:Ke,disabled:j,children:j?`Saving...`:(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(_e,{size:18}),` Save Global Settings`]})}),(0,m.jsx)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:`Applies globally to all active POS registers and terminals.`})]})]})]}),n===`report_emails`&&$&&(0,m.jsxs)(`div`,{className:`settings-card fade-in`,children:[(0,m.jsx)(`div`,{className:`card-header`,children:(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`h2`,{children:`Report Recipient Emails`}),(0,m.jsx)(`p`,{children:`Configure which email addresses automatically receive Shift Closing and Daily Closing sales reports`})]})}),(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,gap:`14px`,padding:`16px 18px`,background:`rgba(59, 130, 246, 0.08)`,border:`1px solid rgba(59, 130, 246, 0.2)`,borderRadius:`12px`,marginBottom:`24px`},children:[(0,m.jsx)(o,{size:22,style:{color:`#2563eb`,flexShrink:0,marginTop:`2px`}}),(0,m.jsxs)(`div`,{style:{fontSize:`13px`,color:`var(--text-secondary)`,lineHeight:`1.6`},children:[(0,m.jsx)(`strong`,{style:{color:`var(--text-primary)`,display:`block`,marginBottom:`2px`},children:`Automated Email Dispatch`}),`Whenever a cashier completes a Shift Closing or an Admin submits the Daily Closing report, the full financial summary (Sales, Cash, Card, Category breakdown, Interval items) is instantly dispatched via email to all active addresses listed below.`]})]}),(0,m.jsxs)(`div`,{style:{marginBottom:`28px`},children:[(0,m.jsx)(`label`,{style:{fontSize:`13px`,fontWeight:600,color:`var(--text-secondary)`,display:`block`,marginBottom:`8px`},children:`Add New Recipient Email`}),(0,m.jsxs)(`form`,{onSubmit:qe,style:{display:`flex`,gap:`10px`,alignItems:`flex-start`,flexWrap:`wrap`},children:[(0,m.jsxs)(`div`,{style:{flex:`1`,minWidth:`260px`,position:`relative`},children:[(0,m.jsxs)(`div`,{className:`input-with-icon`,children:[(0,m.jsx)(o,{size:16}),(0,m.jsx)(`input`,{type:`email`,placeholder:`e.g. manager@restaurant.com`,value:we,onChange:e=>{Te(e.target.value),k&&A(``)},style:{paddingLeft:`40px`}})]}),k&&(0,m.jsx)(`p`,{style:{color:`var(--red, #e31837)`,fontSize:`12px`,marginTop:`6px`,fontWeight:500},children:k})]}),(0,m.jsxs)(`button`,{type:`submit`,disabled:j,style:{display:`flex`,alignItems:`center`,gap:`8px`,padding:`12px 20px`,background:`var(--primary, #e31837)`,color:`#fff`,border:`none`,borderRadius:`10px`,fontWeight:600,fontSize:`14px`,cursor:`pointer`,transition:`all 0.2s`},children:[(0,m.jsx)(ge,{size:16}),` Add Email`]})]})]}),(0,m.jsx)(`div`,{className:`divider`,style:{margin:`20px 0`}}),(0,m.jsxs)(`div`,{children:[(0,m.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,marginBottom:`14px`},children:[(0,m.jsxs)(`label`,{style:{fontSize:`14px`,fontWeight:700,color:`var(--text-primary)`},children:[`Configured Recipients (`,E.length,`)`]}),(0,m.jsx)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:`At least one email is required`})]}),E.length===0?(0,m.jsx)(`div`,{style:{padding:`30px`,textAlign:`center`,background:`var(--surface)`,borderRadius:`12px`,border:`1.5px dashed var(--surface-2)`,color:`var(--text-muted)`},children:`No recipient emails configured. Please add at least one email.`}):(0,m.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`10px`},children:E.map((e,t)=>(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,padding:`12px 16px`,background:`var(--surface)`,border:`1px solid var(--surface-2)`,borderRadius:`10px`,transition:`all 0.2s ease`},children:[(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`12px`},children:[(0,m.jsx)(`div`,{style:{width:`36px`,height:`36px`,borderRadius:`8px`,background:`rgba(227, 24, 55, 0.08)`,color:`var(--primary, #e31837)`,display:`flex`,alignItems:`center`,justifyContent:`center`},children:(0,m.jsx)(o,{size:18})}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`div`,{style:{fontWeight:600,fontSize:`14px`,color:`var(--text-primary)`},children:e}),(0,m.jsx)(`div`,{style:{fontSize:`11px`,color:`var(--text-muted)`,marginTop:`2px`},children:`Receives Shift & Daily Reports`})]})]}),(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`10px`},children:[(0,m.jsx)(`span`,{style:{fontSize:`11px`,fontWeight:600,padding:`3px 8px`,borderRadius:`20px`,background:`rgba(16, 185, 129, 0.1)`,color:`#10b981`},children:`Active`}),(0,m.jsx)(`button`,{type:`button`,title:`Remove recipient`,onClick:()=>Je(t),disabled:E.length<=1||j,style:{display:`flex`,alignItems:`center`,justifyContent:`center`,width:`32px`,height:`32px`,borderRadius:`8px`,background:`transparent`,border:`1px solid var(--surface-2)`,color:E.length<=1?`var(--text-muted)`:`var(--red, #e31837)`,cursor:E.length<=1?`not-allowed`:`pointer`,opacity:E.length<=1?.4:1,transition:`all 0.2s`},children:(0,m.jsx)(he,{size:16})})]})]},e+t))}),(0,m.jsxs)(`div`,{style:{marginTop:`24px`,display:`flex`,gap:`12px`,alignItems:`center`},children:[(0,m.jsx)(`button`,{type:`button`,className:`btn-save`,onClick:()=>Ye(E),disabled:j,children:j?`Saving...`:(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(_e,{size:18}),` Save Recipient Emails`]})}),(0,m.jsx)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:`Changes are also automatically saved when adding or removing emails.`})]})]})]}),n===`account`&&(0,m.jsxs)(`div`,{className:`settings-card fade-in`,children:[(0,m.jsx)(`div`,{className:`card-header`,children:(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`h2`,{children:`Account Information`}),(0,m.jsx)(`p`,{children:`Update your profile details and password`})]})}),(0,m.jsxs)(`form`,{onSubmit:Qe,className:`settings-form`,children:[(0,m.jsxs)(`div`,{className:`form-grid`,children:[(0,m.jsxs)(`div`,{className:`form-group`,children:[(0,m.jsx)(`label`,{children:`Username / Display Name`}),(0,m.jsxs)(`div`,{className:`input-with-icon`,children:[(0,m.jsx)(u,{size:16}),(0,m.jsx)(`input`,{type:`text`,value:F.username,onChange:e=>I({...F,username:e.target.value}),required:!0})]})]}),(0,m.jsxs)(`div`,{className:`form-group`,children:[(0,m.jsx)(`label`,{children:`Email Address`}),(0,m.jsxs)(`div`,{className:`input-with-icon`,children:[(0,m.jsx)(o,{size:16}),(0,m.jsx)(`input`,{type:`email`,value:F.email,onChange:e=>I({...F,email:e.target.value}),required:!0})]})]}),(0,m.jsxs)(`div`,{className:`form-group`,children:[(0,m.jsx)(`label`,{children:`Account Role`}),(0,m.jsxs)(`div`,{className:`input-with-icon readonly`,children:[(0,m.jsx)(re,{size:16}),(0,m.jsx)(`input`,{type:`text`,value:e?.role||`Admin`,readOnly:!0})]})]})]}),(0,m.jsx)(`div`,{className:`divider`}),(0,m.jsx)(`div`,{className:`card-header`,style:{padding:`0 0 16px`},children:(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`h2`,{children:`Change Password`}),(0,m.jsx)(`p`,{children:`Leave blank to keep current password`})]})}),(0,m.jsxs)(`div`,{className:`form-grid`,children:[(0,m.jsxs)(`div`,{className:`form-group`,children:[(0,m.jsx)(`label`,{children:`New Password`}),(0,m.jsxs)(`div`,{className:`input-with-icon`,children:[(0,m.jsx)(d,{size:16}),(0,m.jsx)(`input`,{type:L?`text`:`password`,value:F.password,onChange:e=>I({...F,password:e.target.value}),placeholder:`••••••••`}),(0,m.jsx)(`button`,{type:`button`,className:`eye-toggle`,onClick:it,children:L?(0,m.jsx)(l,{size:16}):(0,m.jsx)(f,{size:16})})]})]}),(0,m.jsxs)(`div`,{className:`form-group`,children:[(0,m.jsx)(`label`,{children:`Confirm Password`}),(0,m.jsxs)(`div`,{className:`input-with-icon`,children:[(0,m.jsx)(d,{size:16}),(0,m.jsx)(`input`,{type:L?`text`:`password`,value:F.confirmPassword,onChange:e=>I({...F,confirmPassword:e.target.value}),placeholder:`••••••••`}),(0,m.jsx)(`button`,{type:`button`,className:`eye-toggle`,onClick:it,children:L?(0,m.jsx)(l,{size:16}):(0,m.jsx)(f,{size:16})})]})]})]}),(0,m.jsx)(`div`,{style:{marginTop:32},children:(0,m.jsx)(`button`,{type:`submit`,className:`btn-save`,disabled:h,children:h?`Saving...`:(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(_e,{size:18}),` Save Changes`]})})})]})]}),n===`users`&&$&&(0,m.jsx)(`div`,{className:`fade-in`,children:Ne?(0,m.jsxs)(`div`,{className:`settings-card`,children:[(0,m.jsx)(`div`,{className:`card-header`,children:(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`h2`,{children:z?`Edit User`:`Add New User`}),(0,m.jsx)(`p`,{children:z?`Updating details for ${z.username}`:`Create a new account for your team`})]})}),(0,m.jsxs)(`form`,{onSubmit:z?et:$e,className:`settings-form`,children:[(0,m.jsxs)(`div`,{className:`form-grid`,children:[(0,m.jsxs)(`div`,{className:`form-group`,children:[(0,m.jsx)(`label`,{children:`Username`}),(0,m.jsx)(`input`,{type:`text`,value:W.username,onChange:e=>G({...W,username:e.target.value}),required:!0})]}),(0,m.jsxs)(`div`,{className:`form-group`,children:[(0,m.jsx)(`label`,{children:`Email Address`}),(0,m.jsx)(`input`,{type:`email`,value:W.email,onChange:e=>G({...W,email:e.target.value}),required:!0})]}),(0,m.jsxs)(`div`,{className:`form-group`,children:[(0,m.jsx)(`label`,{children:`Role`}),(0,m.jsxs)(`select`,{value:W.role,onChange:e=>{let t=e.target.value,n=W.branch;[`Order Taker`,`Cashier`].includes(t)&&(!n||n.startsWith(`Restaurant`))?n=`Branch 1`:t===`Operator`&&(!n||n.startsWith(`Branch`))?n=`Restaurant 1`:[`Order Taker`,`Cashier`,`Operator`,`Employee`].includes(t)||(n=``),G({...W,role:t,shift:t===`Operator`?W.shift||`Morning`:``,branch:n})},children:[(0,m.jsx)(`option`,{value:`Admin`,children:`Admin`}),(0,m.jsx)(`option`,{value:`Order Taker`,children:`Order Taker`}),(0,m.jsx)(`option`,{value:`Cashier`,children:`Cashier`}),(0,m.jsx)(`option`,{value:`Operator`,children:`Operator`}),(0,m.jsx)(`option`,{value:`Salary Pay Operator`,children:`Salary Pay Operator`}),(0,m.jsx)(`option`,{value:`HR Manager`,children:`HR Manager`}),(0,m.jsx)(`option`,{value:`Management`,children:`Management`}),(0,m.jsx)(`option`,{value:`Employee`,children:`Employee`}),e?.role?.toLowerCase()===`developer`&&(0,m.jsx)(`option`,{value:`Developer`,children:`Developer`})]})]}),(W.role===`Order Taker`||W.role===`Cashier`||W.role===`Operator`)&&(0,m.jsxs)(`div`,{className:`form-group`,children:[(0,m.jsx)(`label`,{children:`Assigned Restaurant`}),(0,m.jsx)(`select`,{value:W.branch||(W.role===`Operator`?`Restaurant 1`:`Branch 1`),onChange:e=>G({...W,branch:e.target.value}),children:W.role===`Operator`?(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(`option`,{value:`Restaurant 1`,children:`Restaurant 1`}),(0,m.jsx)(`option`,{value:`Restaurant 2`,children:`Restaurant 2`}),(0,m.jsx)(`option`,{value:`Restaurant 3`,children:`Restaurant 3`})]}):(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(`option`,{value:`Branch 1`,children:`Branch 1`}),(0,m.jsx)(`option`,{value:`Branch 2`,children:`Branch 2`}),(0,m.jsx)(`option`,{value:`Branch 3`,children:`Branch 3`})]})})]}),W.role===`Employee`&&(0,m.jsxs)(`div`,{className:`form-group`,style:{gridColumn:`span 2`},children:[(0,m.jsxs)(`label`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,fontWeight:700},children:[(0,m.jsx)(`span`,{children:`Linked Employee Record *`}),W.employee_id&&(0,m.jsxs)(`span`,{style:{fontSize:11,color:`var(--primary)`,fontWeight:600},children:[`#`,W.employee_id,` Selected`]})]}),(0,m.jsxs)(`select`,{value:W.employee_id||``,onChange:e=>{let t=e.target.value,n=ke.find(e=>String(e.id)===String(t)),r={...W,employee_id:t};n&&(z||(W.username||(r.username=(n.name||``).toLowerCase().replace(/\s+/g,`_`)),!W.email&&n.email&&(r.email=n.email)),n.branch&&(r.branch=n.branch)),G(r)},required:!0,style:{padding:`12px 14px`,borderRadius:`12px`,border:`1.5px solid var(--surface-2)`,background:`var(--surface)`,fontSize:`14px`,width:`100%`,color:`var(--text-primary)`},children:[(0,m.jsx)(`option`,{value:``,children:`-- Select an Employee from Database --`}),ke.map(e=>{let t=e.linked_user_id&&(!z||e.linked_user_id!==z.id);return(0,m.jsxs)(`option`,{value:e.id,disabled:t,children:[e.name,` (`,e.employee_code||`EMP-${e.id}`,`) — `,e.role||`Staff`,` `,e.branch?`[${e.branch}]`:``,` `,t?`⚠️ (Already linked to @${e.linked_username})`:``]},e.id)})]}),(0,m.jsx)(`p`,{style:{fontSize:11.5,color:`var(--text-muted)`,margin:`4px 0 0 0`},children:`Linking an employee connects this login account to their Employee Portal, attendance, and Khata.`})]}),(W.role===`Operator`||W.role===`Employee`)&&(0,m.jsxs)(`div`,{className:`form-group`,style:{position:`relative`},ref:N,children:[(0,m.jsx)(`label`,{children:`Assigned Shift(s)`}),(0,m.jsxs)(`div`,{className:`form-group-input`,style:{padding:`12px 14px`,border:`1.5px solid var(--surface-2)`,borderRadius:`12px`,background:`var(--surface)`,cursor:`pointer`,display:`flex`,justifyContent:`space-between`,alignItems:`center`,minHeight:`45px`},onClick:()=>U(!Pe),children:[(0,m.jsx)(`div`,{style:{flex:1,whiteSpace:`nowrap`,overflow:`hidden`,textOverflow:`ellipsis`,fontSize:`14px`,color:W.shift?`var(--text-primary)`:`var(--text-muted)`},children:W.shift?W.shift.split(`,`).join(`, `):`Select Shifts...`}),(0,m.jsx)(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,style:{flexShrink:0,color:`var(--text-muted)`},children:(0,m.jsx)(`path`,{d:`m6 9 6 6 6-6`})})]}),Pe&&(0,m.jsx)(`div`,{style:{position:`absolute`,top:`100%`,left:0,right:0,marginTop:`8px`,background:`white`,border:`1px solid var(--surface-2)`,borderRadius:`12px`,boxShadow:`0 10px 25px rgba(0,0,0,0.1)`,zIndex:100,maxHeight:`220px`,overflowY:`auto`,padding:`8px`},children:Fe.map(e=>{let t=W.shift?W.shift.split(`,`):[],n=t.includes(e);return(0,m.jsxs)(`label`,{style:{display:`flex`,alignItems:`center`,padding:`10px 12px`,gap:`12px`,cursor:`pointer`,borderRadius:`8px`,transition:`background 0.2s`,background:n?`rgba(var(--primary-rgb), 0.05)`:`transparent`},onMouseOver:e=>!n&&(e.currentTarget.style.background=`var(--surface-1)`),onMouseOut:e=>!n&&(e.currentTarget.style.background=`transparent`),children:[(0,m.jsx)(`input`,{type:`checkbox`,checked:n,onChange:n=>{let r;r=n.target.checked?[...t,e]:t.filter(t=>t!==e),G({...W,shift:r.join(`,`)})},style:{width:`18px`,height:`18px`,cursor:`pointer`,accentColor:`var(--primary)`,margin:0}}),(0,m.jsx)(`span`,{style:{fontSize:`14px`,fontWeight:n?600:500,color:`var(--text-primary)`},children:e})]},e)})})]}),W.role===`Employee`&&(0,m.jsxs)(`div`,{className:`form-group`,style:{position:`relative`},ref:P,children:[(0,m.jsx)(`label`,{children:`Assigned Branch(es)`}),(0,m.jsxs)(`div`,{className:`form-group-input`,style:{padding:`12px 14px`,border:`1.5px solid var(--surface-2)`,borderRadius:`12px`,background:`var(--surface)`,cursor:`pointer`,display:`flex`,justifyContent:`space-between`,alignItems:`center`,minHeight:`45px`},onClick:e=>{e.stopPropagation(),K(!Le)},children:[(0,m.jsx)(`div`,{style:{flex:1,whiteSpace:`nowrap`,overflow:`hidden`,textOverflow:`ellipsis`,fontSize:`14px`,color:W.branch?`var(--text-primary)`:`var(--text-muted)`},children:W.branch?W.branch.split(`,`).join(`, `):`Select Branches...`}),(0,m.jsx)(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,style:{flexShrink:0,color:`var(--text-muted)`},children:(0,m.jsx)(`path`,{d:`m6 9 6 6 6-6`})})]}),Le&&(0,m.jsx)(`div`,{style:{position:`absolute`,bottom:`100%`,left:0,right:0,marginBottom:`8px`,background:`white`,border:`1px solid var(--surface-2)`,borderRadius:`12px`,boxShadow:`0 10px 25px rgba(0,0,0,0.1)`,zIndex:100,maxHeight:`220px`,overflowY:`auto`,padding:`8px`},children:Ie.map(e=>{let t=W.branch?W.branch.split(`,`):[],n=t.includes(e);return(0,m.jsxs)(`label`,{style:{display:`flex`,alignItems:`center`,padding:`10px 12px`,gap:`12px`,cursor:`pointer`,borderRadius:`8px`,transition:`background 0.2s`,background:n?`rgba(var(--primary-rgb), 0.05)`:`transparent`},onMouseOver:e=>!n&&(e.currentTarget.style.background=`var(--surface-1)`),onMouseOut:e=>!n&&(e.currentTarget.style.background=`transparent`),children:[(0,m.jsx)(`input`,{type:`checkbox`,checked:n,onChange:n=>{let r;r=n.target.checked?[...t,e]:t.filter(t=>t!==e),G({...W,branch:r.join(`,`)})},style:{width:`18px`,height:`18px`,cursor:`pointer`,accentColor:`var(--primary)`,margin:0}}),(0,m.jsx)(`span`,{style:{fontSize:`14px`,fontWeight:n?600:500,color:`var(--text-primary)`},children:e})]},e)})})]}),(0,m.jsxs)(`div`,{className:`form-group`,children:[(0,m.jsx)(`label`,{children:z?`New Password (Optional)`:`Password`}),(0,m.jsxs)(`div`,{className:`input-with-icon`,children:[(0,m.jsx)(d,{size:16}),(0,m.jsx)(`input`,{type:V?`text`:`password`,value:W.password,onChange:e=>G({...W,password:e.target.value}),required:!z,placeholder:z?`Leave blank to keep current`:``,disabled:z?.role?.toLowerCase()===`developer`&&e.role?.toLowerCase()!==`developer`,style:{paddingRight:36}}),(0,m.jsx)(`button`,{type:`button`,className:`eye-toggle`,onClick:e=>{e.preventDefault(),e.stopPropagation(),H(!V)},children:V?(0,m.jsx)(l,{size:16}):(0,m.jsx)(f,{size:16})})]})]})]}),(0,m.jsxs)(`div`,{style:{display:`flex`,gap:12,marginTop:24},children:[(0,m.jsx)(`button`,{type:`submit`,className:`btn-save`,disabled:h,children:h?`Processing...`:z?`Update User`:`Create User`}),(0,m.jsx)(`button`,{type:`button`,className:`btn-cancel`,onClick:()=>{R(!1),B(null),G({username:``,email:``,password:``,role:`Operator`,shift:``,branch:``,employee_id:``}),H(!1)},children:`Cancel`})]})]})]}):(0,m.jsxs)(`div`,{className:`settings-card`,children:[(0,m.jsxs)(`div`,{className:`card-header settings-team-header`,style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`},children:[(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`h2`,{children:`Team Members`}),(0,m.jsx)(`p`,{children:`Manage access levels and account status`})]}),(0,m.jsxs)(`div`,{className:`settings-team-actions`,style:{display:`flex`,gap:12},children:[(0,m.jsxs)(`button`,{className:`btn-cancel`,onClick:Q,style:{display:`flex`,alignItems:`center`,justifyContent:`center`,gap:6,height:38,padding:`0 12px`,fontSize:13,background:`var(--surface-1)`,color:`var(--text)`,border:`1.5px solid var(--surface-2)`,borderRadius:8,cursor:`pointer`},children:[(0,m.jsx)(te,{size:14}),` Refresh`]}),(0,m.jsxs)(`button`,{className:`btn-add-user`,onClick:()=>R(!0),style:{display:`flex`,alignItems:`center`,justifyContent:`center`,gap:6},children:[(0,m.jsx)(me,{size:18}),` Add User`]})]})]}),(0,m.jsxs)(`div`,{style:{display:`flex`,gap:`8px`,padding:`16px 24px 0 24px`,background:`var(--surface-1)`,overflowX:`auto`,whiteSpace:`nowrap`},children:[(0,m.jsx)(`button`,{onClick:()=>{Be(`system`),ze(`Admin`),Ve(`All`)},style:{padding:`10px 20px`,border:`none`,background:Y===`system`?`var(--primary)`:`var(--surface-2)`,color:Y===`system`?`white`:`var(--text-muted)`,borderRadius:`8px 8px 0 0`,fontWeight:600,cursor:`pointer`,flexShrink:0},children:`System Users`}),(0,m.jsx)(`button`,{onClick:()=>{Be(`employee`),ze(`Employee`),Ve(`All`)},style:{padding:`10px 20px`,border:`none`,background:Y===`employee`?`var(--primary)`:`var(--surface-2)`,color:Y===`employee`?`white`:`var(--text-muted)`,borderRadius:`8px 8px 0 0`,fontWeight:600,cursor:`pointer`,flexShrink:0},children:`Employees`})]}),(0,m.jsx)(`div`,{style:{display:`flex`,flexWrap:`wrap`,gap:`12px`,padding:`16px 24px`,borderBottom:`1px solid var(--surface-2)`,background:`var(--surface-1)`,alignItems:`center`},children:(0,m.jsxs)(`div`,{style:{flex:1,minWidth:`240px`,position:`relative`},children:[(0,m.jsx)(`span`,{style:{position:`absolute`,left:`12px`,top:`50%`,transform:`translateY(-50%)`,color:`var(--text-muted)`,display:`flex`,alignItems:`center`},children:(0,m.jsxs)(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.3`,strokeLinecap:`round`,strokeLinejoin:`round`,children:[(0,m.jsx)(`circle`,{cx:`11`,cy:`11`,r:`8`}),(0,m.jsx)(`path`,{d:`m21 21-4.3-4.3`})]})}),(0,m.jsx)(`input`,{type:`text`,placeholder:`Search by name or email...`,value:q,onChange:e=>Re(e.target.value),style:{width:`100%`,padding:`10px 12px 10px 36px`,border:`1.5px solid var(--surface-2)`,borderRadius:`8px`,background:`var(--surface)`,color:`var(--text)`,outline:`none`,fontSize:`13px`}})]})}),Y===`system`&&(0,m.jsx)(`div`,{style:{display:`flex`,gap:`8px`,padding:`12px 24px 0`,background:`var(--surface-1)`,overflowX:`auto`},children:[`Admin`,`Management`,`Operator`,`Salary Pay Operator`,`Cashier`,`Order Taker`].map(e=>(0,m.jsx)(`button`,{onClick:()=>ze(e),style:{padding:`6px 16px`,border:`1px solid var(--surface-2)`,background:J===e?`var(--primary)`:`white`,color:J===e?`white`:`var(--text)`,borderRadius:`20px`,fontSize:`13px`,cursor:`pointer`,fontWeight:500,whiteSpace:`nowrap`},children:e},e))}),(0,m.jsx)(`div`,{style:{display:`flex`,gap:`8px`,padding:`12px 24px`,background:`var(--surface-1)`,borderBottom:`1.5px solid var(--surface-2)`,overflowX:`auto`},children:[`All`,`1`,`2`,`3`].map(e=>(0,m.jsx)(`button`,{onClick:()=>Ve(e),style:{padding:`6px 16px`,border:`1px solid var(--surface-2)`,background:X===e?`var(--primary)`:`white`,color:X===e?`white`:`var(--text)`,borderRadius:`20px`,fontSize:`13px`,cursor:`pointer`,fontWeight:500,whiteSpace:`nowrap`},children:e===`All`?`All Branches`:`Branch ${e} (R${e})`},e))}),(0,m.jsx)(`div`,{className:`users-table-wrap desktop-table-view`,style:{overflowX:`auto`,width:`100%`},children:(0,m.jsx)(`div`,{style:{minWidth:`800px`},children:(0,m.jsxs)(`table`,{className:`users-table`,style:{width:`100%`},children:[(0,m.jsx)(`thead`,{children:(0,m.jsxs)(`tr`,{children:[(0,m.jsx)(`th`,{style:{width:`50px`},children:`#`}),(0,m.jsx)(`th`,{children:`User`}),(0,m.jsx)(`th`,{children:`Role`}),(0,m.jsx)(`th`,{children:`Shift`}),(0,m.jsx)(`th`,{children:`Date Joined`}),(0,m.jsx)(`th`,{style:{textAlign:`right`},children:`Actions`})]})}),(0,m.jsx)(`tbody`,{children:Ze.map((t,n)=>(0,m.jsxs)(`tr`,{children:[(0,m.jsx)(`td`,{style:{fontSize:13,fontWeight:600,color:`var(--text-muted)`},children:n+1}),(0,m.jsx)(`td`,{children:(0,m.jsxs)(`div`,{className:`user-info-cell`,children:[(0,m.jsx)(`div`,{className:`user-avatar-sm`,children:t.username[0].toUpperCase()}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`div`,{className:`user-name`,children:t.username}),(0,m.jsx)(`div`,{className:`user-email`,children:t.email})]})]})}),(0,m.jsx)(`td`,{children:(0,m.jsxs)(`span`,{className:`role-badge ${t.role.toLowerCase()}`,children:[t.role===`Admin`?(0,m.jsx)(ue,{size:14}):t.role===`Developer`?(0,m.jsx)(re,{size:14}):(0,m.jsx)(u,{size:14}),t.role]})}),(0,m.jsx)(`td`,{style:{fontSize:13,fontWeight:600,color:`var(--text-secondary)`},children:t.role===`Employee`?t.employee_name?(0,m.jsxs)(`span`,{style:{fontSize:12,fontWeight:700,color:`var(--primary)`,display:`inline-flex`,alignItems:`center`,gap:4},children:[`👤 `,t.employee_name,` (`,t.employee_code||`EMP-${t.employee_id}`,`)`]}):(0,m.jsx)(`span`,{style:{fontSize:11,color:`#f59e0b`,fontWeight:600},children:`⚠️ Not Linked`}):t.role===`Operator`?t.shift||`None`:`--`}),(0,m.jsx)(`td`,{children:new Date(t.created_at).toLocaleDateString()}),(0,m.jsx)(`td`,{children:(0,m.jsxs)(`div`,{className:`user-actions`,children:[(0,m.jsx)(`button`,{className:`action-btn edit`,onClick:()=>rt(t),title:`Edit User`,disabled:t.role?.toLowerCase()===`developer`&&e.role?.toLowerCase()!==`developer`,children:(0,m.jsx)(oe,{size:16})}),(0,m.jsx)(`button`,{className:`action-btn delete`,onClick:()=>tt(t.id),title:`Delete User`,disabled:t.id===e.id||t.role?.toLowerCase()===`developer`&&e.role?.toLowerCase()!==`developer`,children:(0,m.jsx)(he,{size:16})})]})})]},t.id))})]})})}),(0,m.jsx)(`div`,{className:`users-mobile-grid`,style:{display:`none`,flexDirection:`column`,gap:`12px`,marginTop:`16px`},children:Ze.map(t=>(0,m.jsx)(ve,{u:t,currentUser:e,onEdit:rt,onDelete:tt},t.id))})]})})]})]}),(0,m.jsx)(`style`,{children:`
        .settings-container {
          padding: 24px;
          max-width: 1200px;
          margin: 0 auto;
        }

        .settings-header {
          margin-bottom: 32px;
        }

        .settings-header h1 {
          margin: 0;
          font-size: 24px;
          font-weight: 800;
          color: var(--text-primary);
        }

        .settings-header p {
          margin: 4px 0 0;
          color: var(--text-secondary);
          font-size: 14px;
        }

        .settings-layout {
          display: grid;
          grid-template-columns: 240px 1fr;
          gap: 32px;
          align-items: start;
        }

        /* Nav Sidebar */
        .settings-nav {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .settings-nav-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 16px;
          border-radius: 12px;
          border: none;
          background: transparent;
          color: var(--text-secondary);
          font-size: 14px;
          font-weight: 600;
          text-align: left;
          cursor: pointer;
          transition: all 0.2s;
        }

        .settings-nav-item:hover {
          background: var(--surface-2);
          color: var(--text-primary);
        }

        .settings-nav-item.active {
          background: color-mix(in srgb, var(--red) 10%, transparent);
          color: var(--red);
          border: 1px solid color-mix(in srgb, var(--red) 20%, transparent);
        }

        /* Settings Card */
        .settings-card {
          background: white;
          border: 1px solid var(--surface-2);
          border-radius: 20px;
          padding: 24px;
          box-shadow: var(--shadow);
        }

        .card-header {
          margin-bottom: 24px;
        }

        .card-header h2 {
          margin: 0;
          font-size: 18px;
          color: var(--text-primary);
          font-weight: 700;
        }

        .card-header p {
          margin: 4px 0 0;
          color: var(--text-muted);
          font-size: 14px;
        }

        /* Form Styling */
        .settings-form {
          display: flex;
          flex-direction: column;
        }

        .form-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
        }

        .form-group {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .form-group label {
          font-size: 13px;
          font-weight: 600;
          color: var(--text-secondary);
        }

        .input-with-icon {
          position: relative;
          width: 100%;
          display: flex;
          align-items: center;
        }

        .input-with-icon svg:first-child {
          position: absolute;
          left: 14px;
          color: var(--text-muted);
          z-index: 10;
          pointer-events: none;
        }

        .input-with-icon input, 
        .form-group input:not([type="radio"]):not([type="checkbox"]), 
        .form-group select {
          width: 100%;
          padding: 12px 42px 12px 42px;
          background: var(--surface);
          border: 1.5px solid var(--surface-2);
          border-radius: 12px;
          color: var(--text-primary);
          font-size: 14px;
          outline: none;
          transition: all 0.2s;
          display: block;
        }

        .form-group input:not([readonly]):not([type="radio"]):not([type="checkbox"]):focus,
        .form-group select:focus {
          border-color: var(--red);
          background: white;
          box-shadow: 0 0 0 3px color-mix(in srgb, var(--red) 10%, transparent);
        }

        .input-with-icon.readonly input {
          background: var(--surface-2);
          color: var(--text-muted);
          cursor: default;
        }

        .form-group select {
          padding-left: 14px;
          appearance: none;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='rgba(0,0,0,0.3)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
          background-repeat: no-repeat;
          background-position: right 14px center;
        }

        .input-with-icon .eye-toggle {
          position: absolute;
          right: 4px;
          top: 50%;
          transform: translateY(-50%);
          background: transparent;
          border: none;
          color: var(--text-muted);
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 34px;
          height: 34px;
          border-radius: 50%;
          z-index: 20;
          transition: all 0.2s;
        }

        .input-with-icon .eye-toggle:hover {
          background: var(--surface-2);
          color: var(--red);
        }

        .divider {
          height: 1px;
          background: var(--surface-2);
          margin: 32px 0;
        }

        /* Buttons */
        .btn-save {
          padding: 12px 24px;
          background: linear-gradient(135deg, var(--red), var(--red-dark));
          border: none;
          border-radius: 10px;
          color: #fff;
          font-size: 15px;
          font-weight: 700;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          transition: all 0.2s;
          box-shadow: 0 4px 12px rgba(227, 24, 55, 0.2);
        }

        .btn-save:hover { 
          opacity: 0.95;
          transform: translateY(-1px);
          box-shadow: 0 6px 16px rgba(227, 24, 55, 0.3);
        }
        
        .btn-save:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

        .btn-cancel {
          padding: 12px 24px;
          background: white;
          border: 1.5px solid var(--surface-2);
          border-radius: 10px;
          color: var(--text-secondary);
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        
        .btn-cancel:hover {
          background: var(--surface);
          color: var(--text-primary);
        }

        .btn-add-user {
          padding: 10px 16px;
          background: color-mix(in srgb, var(--red) 10%, transparent);
          border: 1px solid color-mix(in srgb, var(--red) 20%, transparent);
          border-radius: 10px;
          color: var(--red);
          font-size: 14px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.2s;
        }
        
        .btn-add-user:hover {
          background: var(--red);
          color: white;
        }

        /* Users Table */
        .users-table-wrap {
          margin-top: 16px;
          overflow-x: auto;
        }

        .users-table {
          width: 100%;
          border-collapse: collapse;
        }

        .users-table th {
          text-align: left;
          padding: 12px 16px;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 1px;
          color: var(--text-muted);
          border-bottom: 2px solid var(--surface-2);
        }

        .users-table td {
          padding: 16px;
          border-bottom: 1px solid var(--surface-2);
          color: var(--text-primary);
        }

        .user-info-cell {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .user-avatar-sm {
          width: 32px;
          height: 32px;
          border-radius: 10px;
          background: linear-gradient(135deg, var(--red), var(--orange));
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-weight: bold;
          font-size: 14px;
        }

        .user-name {
          font-size: 14px;
          font-weight: 600;
          color: var(--text-primary);
        }

        .user-email {
          font-size: 12px;
          color: var(--text-muted);
        }

        .role-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 10px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 700;
          text-transform: uppercase;
        }

        .role-badge.admin { background: color-mix(in srgb, var(--red) 10%, transparent); color: var(--red); }
        .role-badge.developer { background: color-mix(in srgb, #6366f1 10%, transparent); color: #6366f1; }
        .role-badge.operator { background: rgba(74,144,226,0.1); color: #4A90E2; }
        .role-badge.management { background: rgba(244,180,0,0.1); color: #F4B400; }
        .role-badge.employee { background: rgba(16,185,129,0.1); color: #10B981; }

        .user-actions {
          display: flex;
          justify-content: flex-end;
          gap: 8px;
        }

        .action-btn {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          border: 1px solid var(--surface-2);
          background: white;
          color: var(--text-muted);
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }

        .action-btn:hover:not(:disabled) {
          border-color: var(--text-primary);
          color: var(--text-primary);
          background: var(--surface);
        }

        .action-btn.delete:hover:not(:disabled) {
          border-color: #ff6b6b;
          color: #ff6b6b;
          background: #fff5f5;
        }
        
        .action-btn:disabled {
          opacity: 0.3;
          cursor: not-allowed;
        }

        .fade-in {
          animation: fadeIn 0.3s ease-in-out;
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 1000px) {
          .settings-layout {
            grid-template-columns: 1fr;
          }
          
          .settings-nav {
            flex-direction: row;
            flex-wrap: nowrap;
            overflow-x: auto;
            padding-bottom: 8px;
            width: 100%;
            -webkit-overflow-scrolling: touch;
          }
          
          .settings-nav-item {
            flex-shrink: 0;
            white-space: nowrap;
          }
          
          .form-grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 768px) {
          .desktop-table-view {
            display: none !important;
          }
          .users-mobile-grid {
            display: flex !important;
          }
          .settings-team-header {
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 16px !important;
          }
          .settings-team-actions {
            width: 100% !important;
            gap: 8px !important;
          }
          .settings-team-actions button {
            flex: 1 !important;
          }
          .settings-content, .settings-card, .settings-form {
            max-width: 100%;
            overflow-x: hidden;
            box-sizing: border-box;
          }
          .settings-container {
            overflow-x: hidden;
            width: 100%;
          }
        }

        /* POS Options Custom Styles */
        .pos-stock-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
        }

        @media (max-width: 900px) {
          .pos-stock-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 580px) {
          .pos-stock-grid {
            grid-template-columns: 1fr;
          }
        }

        .pos-stock-card {
          display: flex;
          align-items: flex-start;
          gap: 9px;
          padding: 10px 12px;
          border-radius: 10px;
          cursor: pointer;
          background: var(--surface);
          border: 1.5px solid var(--surface-2);
          transition: all 0.15s ease;
          user-select: none;
          position: relative;
          box-sizing: border-box;
        }

        .pos-stock-card:hover {
          border-color: #cbd5e1;
          background: #ffffff;
          transform: translateY(-1px);
          box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .pos-stock-card.selected {
          border-color: var(--primary) !important;
          background: rgba(244, 180, 0, 0.06) !important;
          box-shadow: 0 3px 12px rgba(244, 180, 0, 0.18) !important;
        }

        .pos-stock-card.selected:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 14px rgba(244, 180, 0, 0.22) !important;
        }

        .pos-view-pill-btn {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 5px 11px;
          border-radius: 6px;
          font-size: 12px;
          font-weight: 600;
          border: none;
          cursor: pointer;
          background: transparent;
          color: var(--text-muted);
          transition: all 0.15s ease;
        }

        .pos-view-pill-btn:hover {
          color: var(--text-primary);
        }

        .pos-view-pill-btn.active {
          background: #ffffff;
          color: var(--text-primary);
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.12);
        }
      `}),He&&(0,m.jsx)(`div`,{className:`modal-overlay`,style:{zIndex:9999},children:(0,m.jsxs)(`div`,{className:`modal`,style:{maxWidth:400},children:[(0,m.jsxs)(`div`,{className:`modal-header`,children:[(0,m.jsx)(`h2`,{children:`Confirm Deletion`}),(0,m.jsx)(`button`,{className:`btn-close`,onClick:()=>Z(null),children:(0,m.jsx)(pe,{size:20})})]}),(0,m.jsxs)(`div`,{className:`modal-body`,style:{textAlign:`center`,padding:`20px 0`},children:[(0,m.jsx)(`p`,{style:{fontSize:16,marginBottom:20},children:`Are you sure you want to delete this user?`}),(0,m.jsxs)(`div`,{style:{display:`flex`,gap:12,justifyContent:`center`},children:[(0,m.jsx)(`button`,{className:`btn btn-secondary`,style:{padding:`10px 24px`},onClick:()=>Z(null),children:`Cancel`}),(0,m.jsx)(`button`,{className:`btn btn-primary`,style:{padding:`10px 24px`,background:`var(--red)`},onClick:nt,children:`Yes, Delete`})]})]})]})})]})}function ve({u:e,currentUser:t,onEdit:n,onDelete:r}){let[i,a]=(0,p.useState)(!1);(0,p.useEffect)(()=>{let e=()=>a(!1);return window.addEventListener(`click`,e),()=>window.removeEventListener(`click`,e)},[]);let o=e.role?.toLowerCase()===`developer`&&t.role?.toLowerCase()!==`developer`,s=e.id===t.id||e.role?.toLowerCase()===`developer`&&t.role?.toLowerCase()!==`developer`;return(0,m.jsxs)(`div`,{style:{background:`white`,border:`1.5px solid var(--surface-2)`,borderRadius:`16px`,padding:`16px`,display:`flex`,alignItems:`center`,justifyContent:`space-between`,position:`relative`,boxShadow:`0 2px 8px rgba(0,0,0,0.03)`},children:[(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`12px`},children:[(0,m.jsx)(`div`,{style:{width:`40px`,height:`40px`,borderRadius:`12px`,background:`linear-gradient(135deg, var(--red), var(--orange))`,display:`flex`,alignItems:`center`,justifyContent:`center`,color:`white`,fontWeight:`bold`,fontSize:`15px`},children:e.username[0].toUpperCase()}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`div`,{style:{fontSize:`14px`,fontWeight:700,color:`var(--text-primary)`,marginBottom:`2px`},children:e.username}),(0,m.jsx)(`div`,{style:{fontSize:`11px`,color:`var(--text-muted)`,marginBottom:`6px`},children:e.email}),(0,m.jsxs)(`div`,{style:{display:`flex`,gap:`6px`,alignItems:`center`},children:[(0,m.jsx)(`span`,{className:`role-badge ${e.role.toLowerCase()}`,style:{fontSize:`10px`,padding:`2px 8px`},children:e.role}),e.role===`Operator`&&(0,m.jsxs)(`span`,{style:{fontSize:`10.5px`,color:`var(--text-secondary)`,fontWeight:600},children:[`• Shift `,e.shift||`None`]}),e.role===`Employee`&&(0,m.jsxs)(`span`,{style:{fontSize:`10.5px`,color:e.employee_name?`var(--primary)`:`#f59e0b`,fontWeight:600},children:[`• `,e.employee_name?`👤 ${e.employee_name}`:`⚠️ Not linked`]})]})]})]}),(0,m.jsxs)(`div`,{style:{position:`relative`},children:[(0,m.jsx)(`button`,{onClick:e=>{e.stopPropagation(),a(!i)},style:{background:`transparent`,border:`none`,cursor:`pointer`,padding:`8px`,color:`var(--text-muted)`,display:`flex`,alignItems:`center`,justifyContent:`center`},children:(0,m.jsx)(c,{size:20})}),i&&(0,m.jsxs)(`div`,{style:{position:`absolute`,right:0,top:`100%`,background:`white`,border:`1.5px solid var(--surface-2)`,borderRadius:`10px`,boxShadow:`0 4px 16px rgba(0,0,0,0.12)`,zIndex:100,minWidth:`120px`,marginTop:`4px`,overflow:`hidden`},children:[(0,m.jsx)(`button`,{onClick:()=>n(e),disabled:o,style:{display:`block`,width:`100%`,padding:`10px 14px`,background:`transparent`,border:`none`,cursor:o?`not-allowed`:`pointer`,fontSize:`13px`,textAlign:`left`,color:`var(--text-primary)`,fontWeight:500,opacity:o?.4:1},children:`Edit User`}),(0,m.jsx)(`button`,{onClick:()=>r(e.id),disabled:s,style:{display:`block`,width:`100%`,padding:`10px 14px`,background:`transparent`,border:`none`,cursor:s?`not-allowed`:`pointer`,fontSize:`13px`,textAlign:`left`,color:`#EF4444`,fontWeight:500,opacity:s?.4:1},children:`Delete User`})]})]})]})}export{h as default};