import{o as e}from"./rolldown-runtime-C0FnF6B9.js";import{h as t,m as n}from"./vendor-charts-QYGyGCjd.js";import{dt as r}from"./vendor-misc-DIxX4zlK.js";import{n as i}from"./AuthContext-DRuhpdUG.js";import{t as a}from"./api-BkQmdEBO.js";import{A as o,B as s,Bt as ee,Dt as c,Et as l,G as te,I as u,O as ne,P as re,R as d,S as ie,Tt as f,Ut as ae,Yt as oe,c as se,et as p,ft as ce,jt as le,k as ue,lt as de,n as fe,nt as pe,ot as me,s as he,sn as ge,t as _e,u as ve,ut as ye,v as be}from"./vendor-icons-CPnpc1Kv.js";import{t as xe}from"./timezone-kVlz-3XO.js";var m=e(t(),1),h=n();function g(){let{user:e,updateUser:t}=i(),[n,c]=(0,m.useState)(`account`),[g,_]=(0,m.useState)(!1),[v,Ce]=(0,m.useState)(localStorage.getItem(`printMode`)||`standard`),[we,Te]=(0,m.useState)(!1),[y,Ee]=(0,m.useState)(()=>localStorage.getItem(`printerIp`)||`127.0.0.1`),[b,De]=(0,m.useState)(()=>localStorage.getItem(`printerPort`)||`9100`),[Oe,ke]=(0,m.useState)(()=>localStorage.getItem(`paperWidth`)||`80mm`),[Ae,je]=(0,m.useState)(()=>localStorage.getItem(`salarySlipPrintMode`)||`global`),[Me,Ne]=(0,m.useState)(()=>localStorage.getItem(`salarySlipPaperFormat`)||`80mm`),[Pe,Fe]=(0,m.useState)(()=>localStorage.getItem(`autoPrintSalaryPayment`)===`true`),[Ie,Le]=(0,m.useState)(!1),[Re,ze]=(0,m.useState)(!1),[Be,Ve]=(0,m.useState)(!1),[x,S]=(0,m.useState)(!1),[C,He]=(0,m.useState)(`block`),[w,Ue]=(0,m.useState)(()=>localStorage.getItem(`pos_stock_view_mode`)||`cards`),[T,E]=(0,m.useState)([`mr.caffee25@gmail.com`]),[D,We]=(0,m.useState)([]),[O,Ge]=(0,m.useState)([]),[k,Ke]=(0,m.useState)(null),[A,j]=(0,m.useState)({permission_type:`pay_now`,allowed_months:[],allowed_view_months:[],allowed_pay_months:[]}),[M,qe]=(0,m.useState)(!1),[Je,Ye]=(0,m.useState)(!1),[N,Xe]=(0,m.useState)(``),Ze=[{value:`block`,title:`Block Order`,badge:`Default`,badgeColor:`#dc2626`,badgeBg:`rgba(239, 68, 68, 0.12)`,icon:o,iconColor:`#dc2626`,iconBg:`rgba(239, 68, 68, 0.12)`,desc:`Stop order if ingredients are out of stock.`,detail:`Strict inventory protection: orders cannot be placed if recipe ingredients are out of stock.`},{value:`allow_negative`,title:`Allow Negative`,badge:`Deficit`,badgeColor:`#d97706`,badgeBg:`rgba(217, 119, 6, 0.12)`,icon:ye,iconColor:`#d97706`,iconBg:`rgba(217, 119, 6, 0.12)`,desc:`Allow order & deduct stock below zero.`,detail:`Flexible tracking: orders proceed smoothly while stock counts track deficit below zero.`},{value:`ignore`,title:`Ignore Stock`,badge:`Bypass`,badgeColor:`#4f46e5`,badgeBg:`rgba(79, 70, 229, 0.12)`,icon:l,iconColor:`#4f46e5`,iconBg:`rgba(79, 70, 229, 0.12)`,desc:`Allow order without stock check or deduction.`,detail:`Unrestricted checkout: stock verification and recipe ingredient deductions are completely bypassed.`}],[Qe,$e]=(0,m.useState)(``),[et,P]=(0,m.useState)(``),[F,I]=(0,m.useState)(!1),tt=(0,m.useRef)(null),nt=(0,m.useRef)(null),[L,R]=(0,m.useState)({username:e?.username||``,email:e?.email||``,password:``,confirmPassword:``}),[z,rt]=(0,m.useState)(!1),[it,at]=(0,m.useState)([]),[ot,st]=(0,m.useState)([]),[ct,lt]=(0,m.useState)([]),[ut,B]=(0,m.useState)(!1),[V,dt]=(0,m.useState)(null),[H,U]=(0,m.useState)(!1),[ft,W]=(0,m.useState)(!1),[G,K]=(0,m.useState)({username:``,email:``,password:``,role:`Operator`,shift:``,branch:``,employee_id:``}),pt=[`Day`,`Night`],mt=[`Restaurant 1`,`Restaurant 2`,`Restaurant 3`],[ht,q]=(0,m.useState)(!1),[gt,_t]=(0,m.useState)(``),[J,vt]=(0,m.useState)(`Admin`),[Y,yt]=(0,m.useState)(`system`),[X,bt]=(0,m.useState)(`All`),[xt,Z]=(0,m.useState)(null);(0,m.useEffect)(()=>{let e=e=>{tt.current&&!tt.current.contains(e.target)&&W(!1),nt.current&&!nt.current.contains(e.target)&&q(!1)};return document.addEventListener(`mousedown`,e),()=>document.removeEventListener(`mousedown`,e)},[]);let St=async()=>{try{let e=await a.get(`/api/employees/working-hours/list`);lt(e.data)}catch{r.error(`Failed to fetch shifts`)}};(0,m.useEffect)(()=>{(async()=>{try{let e=await a.get(`/api/auth/profile`);e.data&&(t(e.data),R(t=>({...t,username:e.data.username,email:e.data.email})))}catch(e){console.error(`Failed to refresh profile`,e)}})()},[]),(0,m.useEffect)(()=>{let t=e?.role?.toLowerCase(),r=t===`admin`||t===`developer`;n===`users`&&r&&(Q(),St(),Pt()),(n===`hardware`||(n===`pos_settings`||n===`report_emails`)&&r)&&Et(),n===`salary_permissions`&&r&&Ct()},[n,e?.role]);let Ct=async()=>{qe(!0);try{let e=await a.get(`/api/settings/salary-permissions`);if(e.data){let t=e.data.users||[];if(We(t),Ge(e.data.available_months||[]),t.length>0){let e=k&&t.find(e=>e.id===k)||t[0];Ke(e.id);let n=e=>{if(!e)return[];if(Array.isArray(e))return e;if(typeof e==`string`)try{return JSON.parse(e)}catch{return[]}return[]},r=n(e.allowed_view_months),i=n(e.allowed_pay_months),a=n(e.allowed_months);r.length===0&&a.length>0&&(r=a),i.length===0&&e.permission_type===`pay_now`&&a.length>0&&(i=a),j({permission_type:e.permission_type||`pay_now`,allowed_months:r,allowed_view_months:r,allowed_pay_months:i})}}}catch(e){console.error(`Failed to load salary permissions:`,e),r.error(`Failed to load salary permissions`)}finally{qe(!1)}},wt=e=>{Ke(e.id);let t=e=>{if(!e)return[];if(Array.isArray(e))return e;if(typeof e==`string`)try{return JSON.parse(e)}catch{return[]}return[]},n=t(e.allowed_view_months),r=t(e.allowed_pay_months),i=t(e.allowed_months);n.length===0&&i.length>0&&(n=i),r.length===0&&e.permission_type===`pay_now`&&i.length>0&&(r=i),j({permission_type:e.permission_type||`pay_now`,allowed_months:n,allowed_view_months:n,allowed_pay_months:r})},Tt=async()=>{if(k){Ye(!0);try{await a.put(`/api/settings/salary-permissions/${k}`,A),r.success(`Salary payable user permissions saved successfully`),Ct()}catch(e){console.error(`Failed to save salary permissions:`,e),r.error(e.response?.data?.error||`Failed to save salary permissions`)}finally{Ye(!1)}}},Et=async()=>{try{let e=await a.get(`/api/settings`);if(e.data){Te(e.data.auto_print_enabled);let t=localStorage.getItem(`printerIp`),n=e.data.printer_ip,r=n&&n.trim()&&n!==`127.0.0.1`?n.trim():t&&t.trim()?t.trim():n||`127.0.0.1`;if(Ee(r),localStorage.setItem(`printerIp`,r),He(e.data.low_stock_behavior||`block`),Array.isArray(e.data.report_emails)&&e.data.report_emails.length>0)E(e.data.report_emails);else if(typeof e.data.report_emails==`string`)try{let t=JSON.parse(e.data.report_emails);Array.isArray(t)&&t.length>0&&E(t)}catch{e.data.report_emails&&E([e.data.report_emails])}}}catch(e){console.error(`Failed to fetch settings`,e)}},Dt=async e=>{e&&e.preventDefault();let t=(y||``).trim(),n=(b||``).trim()||`9100`;if(!t){r.error(`Please enter a printer IP address`);return}Ve(!0);try{localStorage.setItem(`printerIp`,t),localStorage.setItem(`printerPort`,n),localStorage.setItem(`paperWidth`,Oe),Ee(t),De(n),await a.put(`/api/settings`,{printer_ip:t}),S(!0),setTimeout(()=>S(!1),2500),r.success(`Thermal Printer Settings saved successfully!`)}catch(e){console.error(`Failed to save printer IP to server:`,e),S(!0),setTimeout(()=>S(!1),2500),r.success(`Printer IP saved for this device`)}finally{Ve(!1)}},Ot=async()=>{Le(!0);let t=r.loading(`Sending test kitchen ticket to printer...`);try{let n=await a.post(`/api/settings/test-print`,{printerIp:(y||``).trim()||`127.0.0.1`,printerPort:(b||``).trim()||`9100`,branchId:e?.branch||`1`});r.success(n.data?.message||`Test kitchen ticket printed successfully!`,{id:t})}catch(e){console.error(`Kitchen test print error:`,e),r.error(e?.response?.data?.error||`Failed to print test ticket. Ensure printer/agent is running.`,{id:t})}finally{Le(!1)}},kt=async()=>{ze(!0);let t=r.loading(`Sending test salary slip to printer...`);try{let n=await a.post(`/api/payroll/test-cloud-slip`,{printerIp:(y||``).trim()||`127.0.0.1`,printerPort:(b||``).trim()||`9100`,branchId:e?.branch||`1`});r.success(n.data?.message||`Test salary slip sent to thermal printer!`,{id:t})}catch(e){console.error(`Salary test print error:`,e),r.error(e?.response?.data?.error||`Failed to print test salary slip. Ensure printer/agent is running.`,{id:t})}finally{ze(!1)}},At=async()=>{I(!0);try{await a.put(`/api/settings`,{auto_print_enabled:we,printer_ip:y,low_stock_behavior:C,report_emails:T}),y&&localStorage.setItem(`printerIp`,y.trim()),r.success(`Settings saved globally`)}catch{r.error(`Failed to save settings`)}finally{I(!1)}},jt=e=>{e&&e.preventDefault();let t=Qe.trim().toLowerCase();if(P(``),!t){P(`Please enter an email address`);return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t)){P(`Please enter a valid email address (e.g. name@domain.com)`);return}if(T.some(e=>e.toLowerCase()===t)){P(`This email is already in the recipient list`);return}let n=[...T,t];E(n),$e(``),Nt(n)},Mt=e=>{if(T.length<=1){r.error(`At least one recipient email is required`);return}let t=T.filter((t,n)=>n!==e);E(t),Nt(t)},Nt=async e=>{I(!0);try{await a.put(`/api/settings`,{auto_print_enabled:we,printer_ip:y,low_stock_behavior:C,report_emails:e}),r.success(`Recipient emails updated successfully`)}catch{r.error(`Failed to update recipient emails`)}finally{I(!1)}},Pt=async()=>{try{let e=await a.get(`/api/auth/employee-options`);st(e.data||[])}catch(e){console.error(`Failed to load employee options:`,e)}},Q=async()=>{try{let e=await a.get(`/api/auth/users`);at(e.data)}catch{r.error(`Failed to fetch users`)}},Ft=it.filter(e=>{let t=e.username&&e.username.toLowerCase().includes(gt.toLowerCase())||e.email&&e.email.toLowerCase().includes(gt.toLowerCase()),n=e.role===`Employee`,r=Y===`system`?!n:n,i=!1;i=J===`All`||e.role===J;let a=!0;if(X!==`All`)if(e.role===`Admin`||e.role===`Developer`||e.role===`Management`)a=!0;else{let t=e.branch||``;a=t.includes(`Branch ${X}`)||t.includes(`Restaurant ${X}`)}return t&&r&&i&&a}).sort((e,t)=>{let n=e=>e===`Developer`?3:e===`Admin`?2:+(e===`Management`);return n(t.role)-n(e.role)}),It=async e=>{if(e.preventDefault(),L.password&&L.password!==L.confirmPassword)return r.error(`Passwords do not match`);_(!0);try{let e=await a.put(`/api/auth/profile`,L);t(e.data.user),r.success(`Profile updated successfully`),R(e=>({...e,password:``,confirmPassword:``}))}catch(e){r.error(e.response?.data?.error||`Update failed`)}finally{_(!1)}},Lt=async e=>{e.preventDefault(),_(!0);let t={...G};[`Order Taker`,`Cashier`].includes(t.role)&&!t.branch&&(t.branch=`Branch 1`),t.role===`Operator`&&!t.branch&&(t.branch=`Restaurant 1`);try{await a.post(`/api/auth/users`,t),r.success(`User created successfully`),B(!1),K({username:``,email:``,password:``,role:`Operator`,shift:``,branch:``,employee_id:``}),U(!1),W(!1),q(!1),Q()}catch(e){r.error(e.response?.data?.error||`Creation failed`)}finally{_(!1)}},Rt=async e=>{e.preventDefault(),_(!0);let t={...G};[`Order Taker`,`Cashier`].includes(t.role)&&!t.branch&&(t.branch=`Branch 1`),t.role===`Operator`&&!t.branch&&(t.branch=`Restaurant 1`);try{await a.put(`/api/auth/users/${V.id}`,t),r.success(`User updated successfully`),dt(null),K({username:``,email:``,password:``,role:`Operator`,shift:``,branch:``,employee_id:``}),U(!1),W(!1),q(!1),Q()}catch(e){r.error(e.response?.data?.error||`Update failed`)}finally{_(!1)}},zt=e=>{Z(e)},Bt=async()=>{if(xt)try{await a.delete(`/api/auth/users/${xt}`),r.success(`User deleted`),Q()}catch(e){r.error(e.response?.data?.error||`Deletion failed`)}finally{Z(null)}},Vt=e=>{dt(e),K({username:e.username,email:e.email,password:``,role:e.role,shift:e.shift||``,branch:e.branch||``,employee_id:e.employee_id||``}),B(!0),W(!1),q(!1)},Ht=e=>{e.preventDefault(),e.stopPropagation(),rt(!z)},Ut=e?.role?.toLowerCase(),$=Ut===`admin`||Ut===`developer`;return(0,h.jsxs)(`div`,{className:`settings-container`,children:[(0,h.jsxs)(`div`,{className:`settings-header`,children:[(0,h.jsx)(`h1`,{children:`System Settings`}),(0,h.jsx)(`p`,{children:`Manage your account and team`})]}),(0,h.jsxs)(`div`,{className:`settings-layout`,children:[(0,h.jsxs)(`aside`,{className:`settings-nav`,children:[(0,h.jsxs)(`button`,{className:`settings-nav-item ${n===`account`?`active`:``}`,onClick:()=>c(`account`),children:[(0,h.jsx)(se,{size:18}),` My Account`]}),$&&(0,h.jsxs)(`button`,{className:`settings-nav-item ${n===`users`?`active`:``}`,onClick:()=>c(`users`),children:[(0,h.jsx)(he,{size:18}),` User Management`]}),(0,h.jsxs)(`button`,{className:`settings-nav-item ${n===`hardware`?`active`:``}`,onClick:()=>c(`hardware`),children:[(0,h.jsx)(ae,{size:18}),` Hardware & Printers`]}),$&&(0,h.jsxs)(`button`,{className:`settings-nav-item ${n===`pos_settings`?`active`:``}`,onClick:()=>c(`pos_settings`),children:[(0,h.jsx)(ie,{size:18}),` POS Options`]}),$&&(0,h.jsxs)(`button`,{className:`settings-nav-item ${n===`report_emails`?`active`:``}`,onClick:()=>c(`report_emails`),children:[(0,h.jsx)(p,{size:18}),` Report Emails`]}),$&&(0,h.jsxs)(`button`,{className:`settings-nav-item ${n===`salary_permissions`?`active`:``}`,onClick:()=>c(`salary_permissions`),children:[(0,h.jsx)(ge,{size:18}),` Salary Permissions`]})]}),(0,h.jsxs)(`main`,{className:`settings-content`,children:[n===`hardware`&&(0,h.jsxs)(`div`,{className:`settings-card fade-in`,style:{maxWidth:840},children:[(0,h.jsx)(`div`,{className:`card-header`,style:{borderBottom:`1px solid var(--surface-2)`,paddingBottom:`16px`,marginBottom:`24px`},children:(0,h.jsxs)(`div`,{children:[(0,h.jsxs)(`h2`,{style:{display:`flex`,alignItems:`center`,gap:`8px`},children:[(0,h.jsx)(d,{size:22,style:{color:`var(--primary)`}}),`Hardware & Printers Configuration`]}),(0,h.jsx)(`p`,{children:`Configure device print modes, thermal network printers, employee salary slips, and hardware testing`})]})}),(0,h.jsxs)(`div`,{className:`settings-form`,style:{display:`flex`,flexDirection:`column`,gap:`28px`},children:[(0,h.jsxs)(`div`,{style:{background:`var(--surface-1, #f8fafc)`,border:`1px solid var(--surface-2, #e2e8f0)`,borderRadius:`12px`,padding:`20px`},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:`12px`},children:[(0,h.jsxs)(`label`,{style:{fontSize:`15px`,fontWeight:700,color:`var(--text-primary)`,margin:0,display:`flex`,alignItems:`center`,gap:`7px`},children:[(0,h.jsx)(fe,{size:17,style:{color:`#0284c7`}}),`Default Print Mode (POS & Kitchen)`]}),(0,h.jsx)(`span`,{style:{fontSize:`11px`,padding:`3px 9px`,borderRadius:`6px`,background:v===`cloud`?`#ecfdf5`:`#f1f5f9`,color:v===`cloud`?`#059669`:`#64748b`,fontWeight:700,border:`1px solid #cbd5e1`},children:v===`cloud`?`⚡ Cloud Active`:v===`rawbt`?`📱 Mobile RawBT`:`💻 Standard USB`})]}),(0,h.jsxs)(`select`,{value:v,onChange:e=>{Ce(e.target.value),localStorage.setItem(`printMode`,e.target.value),r.success(`Print mode saved for this device`)},style:{padding:`11px 14px`,borderRadius:`8px`,border:`1.5px solid var(--surface-2, #cbd5e1)`,width:`100%`,fontSize:`14px`,fontWeight:600,background:`var(--surface, #ffffff)`,color:`var(--text-primary)`},children:[(0,h.jsx)(`option`,{value:`standard`,children:`Standard Print (Browser Dialog / Laptop USB Printer)`}),(0,h.jsx)(`option`,{value:`cloud`,children:`Cloud Auto-Printing (Direct ESC/POS 80mm via Local Agent / LAN)`}),(0,h.jsx)(`option`,{value:`rawbt`,children:`RawBT App (Android Mobile Direct Print via App Intent)`})]}),(0,h.jsx)(`p`,{style:{fontSize:12.5,color:`var(--text-muted, #64748b)`,marginTop:10,lineHeight:1.5,marginBottom:0},children:v===`standard`?`Opens the standard browser print dialog. Best for laptops or desktop computers connected to a USB receipt printer.`:v===`cloud`?`Instantly pushes orders and slips to network thermal receipt printers via Pusher and local print agents on Port 9100.`:`Uses the RawBT Android app to print directly from mobile phones/tablets over LAN or Bluetooth. Ideal for mobile order-takers.`})]}),(0,h.jsxs)(`div`,{style:{background:`var(--surface-1, #f8fafc)`,border:`1px solid var(--surface-2, #e2e8f0)`,borderRadius:`12px`,padding:`20px`},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:`14px`},children:[(0,h.jsxs)(`label`,{style:{fontSize:`15px`,fontWeight:700,color:`var(--text-primary)`,margin:0,display:`flex`,alignItems:`center`,gap:`7px`},children:[(0,h.jsx)(d,{size:17,style:{color:`#d97706`}}),`Network Thermal Receipt Printer`]}),(0,h.jsx)(`span`,{style:{fontSize:`11px`,padding:`3px 8px`,borderRadius:`6px`,background:`rgba(16, 185, 129, 0.12)`,color:`#10b981`,fontWeight:700},children:`TCP RAW ESC/POS`})]}),(0,h.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`minmax(220px, 2fr) minmax(110px, 1fr) auto`,gap:`12px`,alignItems:`end`},children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`label`,{style:{fontSize:`12px`,fontWeight:600,color:`var(--text-secondary, #475569)`,display:`block`,marginBottom:`6px`},children:`Printer IP Address`}),(0,h.jsx)(`input`,{type:`text`,value:y,onChange:e=>{Ee(e.target.value),S(!1)},onKeyDown:e=>{e.key===`Enter`&&(e.preventDefault(),Dt())},placeholder:`e.g. 192.168.1.100 or 127.0.0.1`,style:{padding:`10px 12px`,borderRadius:`8px`,border:x?`1.5px solid #10b981`:`1px solid var(--surface-2, #cbd5e1)`,width:`100%`,background:`var(--surface, #ffffff)`,fontSize:`13.5px`,fontFamily:`monospace`,color:`var(--text-primary)`,boxSizing:`border-box`}})]}),(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`label`,{style:{fontSize:`12px`,fontWeight:600,color:`var(--text-secondary, #475569)`,display:`block`,marginBottom:`6px`},children:`Printer Port`}),(0,h.jsx)(`input`,{type:`text`,value:b,onChange:e=>{De(e.target.value),S(!1)},placeholder:`9100`,style:{padding:`10px 12px`,borderRadius:`8px`,border:`1px solid var(--surface-2, #cbd5e1)`,width:`100%`,background:`var(--surface, #ffffff)`,fontSize:`13.5px`,fontFamily:`monospace`,color:`var(--text-primary)`,boxSizing:`border-box`}})]}),(0,h.jsxs)(`button`,{type:`button`,id:`btn-save-printer-ip`,onClick:Dt,disabled:Be,style:{display:`inline-flex`,alignItems:`center`,justifyContent:`center`,gap:`6px`,padding:`10px 18px`,background:x?`#10b981`:`var(--primary, #e11d48)`,color:`#ffffff`,border:`none`,borderRadius:`8px`,fontSize:`13px`,fontWeight:700,cursor:Be?`not-allowed`:`pointer`,whiteSpace:`nowrap`,height:`40px`},children:[Be?(0,h.jsx)(u,{size:14,className:`spin`}):x?(0,h.jsx)(oe,{size:15}):(0,h.jsx)(re,{size:15}),(0,h.jsx)(`span`,{children:x?`Saved`:`Save Printer`})]})]}),(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,flexWrap:`wrap`,gap:`10px`,marginTop:`16px`,paddingTop:`14px`,borderTop:`1px dashed #cbd5e1`},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`6px`},children:[(0,h.jsx)(ce,{size:13,color:`var(--text-muted)`}),(0,h.jsxs)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:[`Default thermal receipt port is `,(0,h.jsx)(`strong`,{children:`9100`}),`. Enter printer's static LAN IP address.`]})]}),(0,h.jsxs)(`button`,{type:`button`,onClick:Ot,disabled:Ie,style:{display:`inline-flex`,alignItems:`center`,gap:`6px`,padding:`7px 14px`,borderRadius:`6px`,background:`#eff6ff`,color:`#0284c7`,border:`1px solid #bfdbfe`,fontSize:`12.5px`,fontWeight:700,cursor:Ie?`not-allowed`:`pointer`},children:[Ie?(0,h.jsx)(u,{size:13,className:`spin`}):(0,h.jsx)(d,{size:13}),`Test Kitchen Slip Print`]})]})]}),(0,h.jsxs)(`div`,{style:{background:`#ffffff`,border:`1.5px solid #e2e8f0`,borderRadius:`12px`,padding:`20px`,boxShadow:`0 1px 3px rgba(0,0,0,0.05)`},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:`16px`},children:[(0,h.jsxs)(`div`,{children:[(0,h.jsxs)(`h3`,{style:{fontSize:`15px`,fontWeight:700,color:`#0f172a`,margin:0,display:`flex`,alignItems:`center`,gap:`7px`},children:[(0,h.jsx)(ge,{size:18,style:{color:`#059669`}}),`Salary Slip Printing Preferences`]}),(0,h.jsx)(`p`,{style:{fontSize:`12px`,color:`#64748b`,margin:`3px 0 0 0`},children:`Configure format, routing, and automation for official employee salary payment receipts`})]}),(0,h.jsx)(`span`,{style:{fontSize:`11px`,padding:`3px 8px`,borderRadius:`6px`,background:`#ecfdf5`,color:`#059669`,fontWeight:700,border:`1px solid #a7f3d0`},children:`Salary Module`})]}),(0,h.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(260px, 1fr))`,gap:`16px`},children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`label`,{style:{fontSize:`12.5px`,fontWeight:600,color:`#334155`,display:`block`,marginBottom:`6px`},children:`Salary Slip Print Destination`}),(0,h.jsxs)(`select`,{value:Ae,onChange:e=>{je(e.target.value),localStorage.setItem(`salarySlipPrintMode`,e.target.value),r.success(`Salary slip print destination updated`)},style:{padding:`9px 12px`,borderRadius:`7px`,border:`1px solid #cbd5e1`,width:`100%`,fontSize:`13px`,fontWeight:600,background:`#fff`,color:`#1e293b`},children:[(0,h.jsxs)(`option`,{value:`global`,children:[`Follow Device Default (`,v===`cloud`?`Cloud Printer`:v===`rawbt`?`RawBT`:`Standard Browser`,`)`]}),(0,h.jsx)(`option`,{value:`cloud`,children:`Always Cloud Auto-Print (Direct 80mm ESC/POS Thermal)`}),(0,h.jsx)(`option`,{value:`standard`,children:`Always Browser Print Dialog (Window Preview / PDF)`}),(0,h.jsx)(`option`,{value:`rawbt`,children:`Always RawBT App (Android Mobile)`})]}),(0,h.jsx)(`span`,{style:{fontSize:`11px`,color:`#64748b`,display:`block`,marginTop:`4px`},children:Ae===`cloud`?`Outputs directly to Port 9100 thermal printer without dialog.`:`Can open print preview or send to mobile app.`})]}),(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`label`,{style:{fontSize:`12.5px`,fontWeight:600,color:`#334155`,display:`block`,marginBottom:`6px`},children:`Paper & Slip Format`}),(0,h.jsxs)(`select`,{value:Me,onChange:e=>{Ne(e.target.value),localStorage.setItem(`salarySlipPaperFormat`,e.target.value),r.success(`Salary slip paper format saved`)},style:{padding:`9px 12px`,borderRadius:`7px`,border:`1px solid #cbd5e1`,width:`100%`,fontSize:`13px`,fontWeight:600,background:`#fff`,color:`#1e293b`},children:[(0,h.jsx)(`option`,{value:`80mm`,children:`80mm Thermal Receipt (Standard POS Roll)`}),(0,h.jsx)(`option`,{value:`a4`,children:`A4 Full Page Voucher Statement`})]}),(0,h.jsx)(`span`,{style:{fontSize:`11px`,color:`#64748b`,display:`block`,marginTop:`4px`},children:`Optimized with clear borders, duty hours breakdown, and signature boxes.`})]})]}),(0,h.jsxs)(`div`,{style:{marginTop:`16px`,paddingTop:`14px`,borderTop:`1px solid #f1f5f9`,display:`flex`,alignItems:`center`,justifyContent:`space-between`,flexWrap:`wrap`,gap:`10px`},children:[(0,h.jsxs)(`label`,{style:{display:`flex`,alignItems:`center`,gap:`10px`,cursor:`pointer`,margin:0},children:[(0,h.jsx)(`input`,{type:`checkbox`,checked:Pe,onChange:e=>{Fe(e.target.checked),localStorage.setItem(`autoPrintSalaryPayment`,e.target.checked?`true`:`false`),r.success(e.target.checked?`Auto-print on salary payment enabled`:`Auto-print on salary payment disabled`)},style:{width:`17px`,height:`17px`,accentColor:`#059669`,cursor:`pointer`}}),(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`span`,{style:{fontSize:`13px`,fontWeight:600,color:`#1e293b`,display:`block`},children:`Auto-Print on Salary Payment`}),(0,h.jsx)(`span`,{style:{fontSize:`11px`,color:`#64748b`},children:`Automatically print or dispatch the salary receipt whenever a payment is confirmed in the Pay Now popup`})]})]}),(0,h.jsxs)(`button`,{type:`button`,onClick:kt,disabled:Re,style:{display:`inline-flex`,alignItems:`center`,gap:`6px`,padding:`7px 14px`,borderRadius:`6px`,background:`#ecfdf5`,color:`#059669`,border:`1px solid #a7f3d0`,fontSize:`12.5px`,fontWeight:700,cursor:Re?`not-allowed`:`pointer`},children:[Re?(0,h.jsx)(u,{size:13,className:`spin`}):(0,h.jsx)(d,{size:13}),`Test Salary Slip Print`]})]})]}),(0,h.jsxs)(`div`,{style:{background:`#f8fafc`,border:`1px solid #e2e8f0`,borderRadius:`12px`,padding:`16px 20px`},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:`8px`},children:[(0,h.jsxs)(`span`,{style:{fontSize:`13px`,fontWeight:700,color:`#334155`,display:`flex`,alignItems:`center`,gap:`6px`},children:[(0,h.jsx)(fe,{size:14,style:{color:`#10b981`}}),`Cloud Print Agent Infrastructure`]}),(0,h.jsx)(`span`,{style:{fontSize:`11px`,color:`#059669`,fontWeight:700},children:`Cluster: ap2 | Active`})]}),(0,h.jsxs)(`p`,{style:{fontSize:`12px`,color:`#64748b`,lineHeight:1.5,margin:0},children:[`When using Cloud Printing, orders and salary slips are sent across the Pusher event channels (`,(0,h.jsx)(`code`,{children:`branch-1-orders`}),`, `,(0,h.jsx)(`code`,{children:`branch-2-orders`}),`, `,(0,h.jsx)(`code`,{children:`branch-3-orders`}),`). The local Windows print agent running in `,(0,h.jsx)(`code`,{children:`print_agents/`}),` receives these events and immediately prints them to the receipt printer at port 9100.`]})]})]})]}),n===`pos_settings`&&$&&(0,h.jsxs)(`div`,{className:`settings-card fade-in`,children:[(0,h.jsx)(`div`,{className:`card-header`,children:(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`h2`,{children:`POS Options`}),(0,h.jsx)(`p`,{children:`Global settings for Point of Sale functionality`})]})}),(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,gap:`12px`,padding:`12px 16px`,background:`rgba(244, 180, 0, 0.08)`,border:`1px solid rgba(244, 180, 0, 0.25)`,borderRadius:`12px`,marginBottom:`20px`},children:[(0,h.jsx)(ce,{size:18,style:{color:`var(--primary)`,flexShrink:0,marginTop:`2px`}}),(0,h.jsxs)(`div`,{style:{fontSize:`13px`,color:`var(--text-secondary)`,lineHeight:`1.5`},children:[(0,h.jsx)(`strong`,{style:{color:`var(--text-primary)`,display:`block`,marginBottom:`2px`},children:`Insufficient Inventory Rule`}),`Controls checkout behavior when an item or its recipe ingredients are depleted.`]})]}),(0,h.jsxs)(`div`,{className:`settings-form`,children:[(0,h.jsxs)(`div`,{children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:`12px`,flexWrap:`wrap`,gap:`10px`},children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`label`,{style:{fontSize:`14px`,fontWeight:700,color:`var(--text-primary)`,display:`block`,margin:0},children:`Insufficient Stock Behavior`}),(0,h.jsx)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:`Select how orders are handled when stock is depleted`})]}),(0,h.jsxs)(`div`,{style:{display:`inline-flex`,padding:`3px`,background:`var(--surface-2)`,borderRadius:`8px`,gap:`2px`},children:[(0,h.jsxs)(`button`,{type:`button`,className:`pos-view-pill-btn ${w===`cards`?`active`:``}`,onClick:()=>{Ue(`cards`),localStorage.setItem(`pos_stock_view_mode`,`cards`)},children:[(0,h.jsx)(de,{size:13}),` Cards Grid`]}),(0,h.jsxs)(`button`,{type:`button`,className:`pos-view-pill-btn ${w===`dropdown`?`active`:``}`,onClick:()=>{Ue(`dropdown`),localStorage.setItem(`pos_stock_view_mode`,`dropdown`)},children:[(0,h.jsx)(me,{size:13}),` Dropdown`]})]})]}),w===`cards`&&(0,h.jsx)(`div`,{className:`pos-stock-grid`,children:Ze.map(e=>{let t=C===e.value;return(0,h.jsxs)(`div`,{onClick:()=>He(e.value),className:`pos-stock-card ${t?`selected`:``}`,children:[(0,h.jsx)(`div`,{style:{width:16,height:16,borderRadius:`50%`,border:t?`5px solid var(--primary)`:`2px solid #cbd5e1`,background:`#fff`,flexShrink:0,marginTop:`2px`,transition:`all 0.15s ease`}}),(0,h.jsxs)(`div`,{style:{flex:1,minWidth:0},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:`6px`},children:[(0,h.jsx)(`span`,{style:{fontWeight:700,fontSize:`13px`,color:`var(--text-primary)`,whiteSpace:`nowrap`},children:e.title}),(0,h.jsx)(`span`,{style:{fontSize:`10px`,fontWeight:700,padding:`1px 5px`,borderRadius:`4px`,background:e.badgeBg,color:e.badgeColor,flexShrink:0},children:e.badge})]}),(0,h.jsx)(`p`,{style:{fontSize:`11px`,color:`var(--text-secondary)`,lineHeight:`1.35`,margin:`3px 0 0 0`},children:e.desc})]})]},e.value)})}),w===`dropdown`&&(0,h.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`12px`,maxWidth:`520px`},children:[(0,h.jsxs)(`select`,{value:C,onChange:e=>He(e.target.value),style:{width:`100%`,padding:`11px 14px`,borderRadius:`10px`,border:`1.5px solid var(--surface-2)`,background:`var(--surface)`,fontSize:`13.5px`,fontWeight:600,color:`var(--text-primary)`,cursor:`pointer`},children:[(0,h.jsx)(`option`,{value:`block`,children:`Block Order (Default) — Stop checkout if out of stock`}),(0,h.jsx)(`option`,{value:`allow_negative`,children:`Allow Negative Stock — Allow checkout & deduct below zero`}),(0,h.jsx)(`option`,{value:`ignore`,children:`Ignore Stock Check — Allow checkout without stock checks`})]}),(()=>{let e=Ze.find(e=>e.value===C)||Ze[0],t=e.icon;return(0,h.jsxs)(`div`,{style:{padding:`12px 14px`,borderRadius:`10px`,background:`rgba(244, 180, 0, 0.06)`,border:`1.5px solid var(--primary)`,display:`flex`,alignItems:`center`,gap:`12px`},children:[(0,h.jsx)(`div`,{style:{width:32,height:32,borderRadius:8,background:e.iconBg,color:e.iconColor,display:`flex`,alignItems:`center`,justifyContent:`center`,flexShrink:0},children:(0,h.jsx)(t,{size:17})}),(0,h.jsxs)(`div`,{style:{flex:1},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`8px`,marginBottom:`2px`},children:[(0,h.jsx)(`strong`,{style:{fontSize:`13px`,color:`var(--text-primary)`},children:e.title}),(0,h.jsx)(`span`,{style:{fontSize:`10.5px`,fontWeight:700,padding:`1px 6px`,borderRadius:`4px`,background:e.badgeBg,color:e.badgeColor},children:e.badge})]}),(0,h.jsx)(`p`,{style:{fontSize:`12px`,color:`var(--text-secondary)`,margin:0,lineHeight:1.4},children:e.detail})]})]})})()]})]}),(0,h.jsxs)(`div`,{style:{marginTop:24,display:`flex`,alignItems:`center`,gap:`14px`,flexWrap:`wrap`},children:[(0,h.jsx)(`button`,{type:`button`,className:`btn-save`,onClick:At,disabled:F,children:F?`Saving...`:(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(ee,{size:18}),` Save Global Settings`]})}),(0,h.jsx)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:`Applies globally to all active POS registers and terminals.`})]})]})]}),n===`report_emails`&&$&&(0,h.jsxs)(`div`,{className:`settings-card fade-in`,children:[(0,h.jsx)(`div`,{className:`card-header`,children:(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`h2`,{children:`Report Recipient Emails`}),(0,h.jsx)(`p`,{children:`Configure which email addresses automatically receive Shift Closing and Daily Closing sales reports`})]})}),(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,gap:`14px`,padding:`16px 18px`,background:`rgba(59, 130, 246, 0.08)`,border:`1px solid rgba(59, 130, 246, 0.2)`,borderRadius:`12px`,marginBottom:`24px`},children:[(0,h.jsx)(p,{size:22,style:{color:`#2563eb`,flexShrink:0,marginTop:`2px`}}),(0,h.jsxs)(`div`,{style:{fontSize:`13px`,color:`var(--text-secondary)`,lineHeight:`1.6`},children:[(0,h.jsx)(`strong`,{style:{color:`var(--text-primary)`,display:`block`,marginBottom:`2px`},children:`Automated Email Dispatch`}),`Whenever a cashier completes a Shift Closing or an Admin submits the Daily Closing report, the full financial summary (Sales, Cash, Card, Category breakdown, Interval items) is instantly dispatched via email to all active addresses listed below.`]})]}),(0,h.jsxs)(`div`,{style:{marginBottom:`28px`},children:[(0,h.jsx)(`label`,{style:{fontSize:`13px`,fontWeight:600,color:`var(--text-secondary)`,display:`block`,marginBottom:`8px`},children:`Add New Recipient Email`}),(0,h.jsxs)(`form`,{onSubmit:jt,style:{display:`flex`,gap:`10px`,alignItems:`flex-start`,flexWrap:`wrap`},children:[(0,h.jsxs)(`div`,{style:{flex:`1`,minWidth:`260px`,position:`relative`},children:[(0,h.jsxs)(`div`,{className:`input-with-icon`,children:[(0,h.jsx)(p,{size:16}),(0,h.jsx)(`input`,{type:`email`,placeholder:`e.g. manager@restaurant.com`,value:Qe,onChange:e=>{$e(e.target.value),et&&P(``)},style:{paddingLeft:`40px`}})]}),et&&(0,h.jsx)(`p`,{style:{color:`var(--red, #e31837)`,fontSize:`12px`,marginTop:`6px`,fontWeight:500},children:et})]}),(0,h.jsxs)(`button`,{type:`submit`,disabled:F,style:{display:`flex`,alignItems:`center`,gap:`8px`,padding:`12px 20px`,background:`var(--primary, #e31837)`,color:`#fff`,border:`none`,borderRadius:`10px`,fontWeight:600,fontSize:`14px`,cursor:`pointer`,transition:`all 0.2s`},children:[(0,h.jsx)(s,{size:16}),` Add Email`]})]})]}),(0,h.jsx)(`div`,{className:`divider`,style:{margin:`20px 0`}}),(0,h.jsxs)(`div`,{children:[(0,h.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,marginBottom:`14px`},children:[(0,h.jsxs)(`label`,{style:{fontSize:`14px`,fontWeight:700,color:`var(--text-primary)`},children:[`Configured Recipients (`,T.length,`)`]}),(0,h.jsx)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:`At least one email is required`})]}),T.length===0?(0,h.jsx)(`div`,{style:{padding:`30px`,textAlign:`center`,background:`var(--surface)`,borderRadius:`12px`,border:`1.5px dashed var(--surface-2)`,color:`var(--text-muted)`},children:`No recipient emails configured. Please add at least one email.`}):(0,h.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`10px`},children:T.map((e,t)=>(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,padding:`12px 16px`,background:`var(--surface)`,border:`1px solid var(--surface-2)`,borderRadius:`10px`,transition:`all 0.2s ease`},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`12px`},children:[(0,h.jsx)(`div`,{style:{width:`36px`,height:`36px`,borderRadius:`8px`,background:`rgba(227, 24, 55, 0.08)`,color:`var(--primary, #e31837)`,display:`flex`,alignItems:`center`,justifyContent:`center`},children:(0,h.jsx)(p,{size:18})}),(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`div`,{style:{fontWeight:600,fontSize:`14px`,color:`var(--text-primary)`},children:e}),(0,h.jsx)(`div`,{style:{fontSize:`11px`,color:`var(--text-muted)`,marginTop:`2px`},children:`Receives Shift & Daily Reports`})]})]}),(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`10px`},children:[(0,h.jsx)(`span`,{style:{fontSize:`11px`,fontWeight:600,padding:`3px 8px`,borderRadius:`20px`,background:`rgba(16, 185, 129, 0.1)`,color:`#10b981`},children:`Active`}),(0,h.jsx)(`button`,{type:`button`,title:`Remove recipient`,onClick:()=>Mt(t),disabled:T.length<=1||F,style:{display:`flex`,alignItems:`center`,justifyContent:`center`,width:`32px`,height:`32px`,borderRadius:`8px`,background:`transparent`,border:`1px solid var(--surface-2)`,color:T.length<=1?`var(--text-muted)`:`var(--red, #e31837)`,cursor:T.length<=1?`not-allowed`:`pointer`,opacity:T.length<=1?.4:1,transition:`all 0.2s`},children:(0,h.jsx)(be,{size:16})})]})]},e+t))}),(0,h.jsxs)(`div`,{style:{marginTop:`24px`,display:`flex`,gap:`12px`,alignItems:`center`},children:[(0,h.jsx)(`button`,{type:`button`,className:`btn-save`,onClick:()=>Nt(T),disabled:F,children:F?`Saving...`:(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(ee,{size:18}),` Save Recipient Emails`]})}),(0,h.jsx)(`span`,{style:{fontSize:`12px`,color:`var(--text-muted)`},children:`Changes are also automatically saved when adding or removing emails.`})]})]})]}),n===`account`&&(0,h.jsxs)(`div`,{className:`settings-card fade-in`,children:[(0,h.jsx)(`div`,{className:`card-header`,children:(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`h2`,{children:`Account Information`}),(0,h.jsx)(`p`,{children:`Update your profile details and password`})]})}),(0,h.jsxs)(`form`,{onSubmit:It,className:`settings-form`,children:[(0,h.jsxs)(`div`,{className:`form-grid`,children:[(0,h.jsxs)(`div`,{className:`form-group`,children:[(0,h.jsx)(`label`,{children:`Username / Display Name`}),(0,h.jsxs)(`div`,{className:`input-with-icon`,children:[(0,h.jsx)(se,{size:16}),(0,h.jsx)(`input`,{type:`text`,value:L.username,onChange:e=>R({...L,username:e.target.value}),required:!0})]})]}),(0,h.jsxs)(`div`,{className:`form-group`,children:[(0,h.jsx)(`label`,{children:`Email Address`}),(0,h.jsxs)(`div`,{className:`input-with-icon`,children:[(0,h.jsx)(p,{size:16}),(0,h.jsx)(`input`,{type:`email`,value:L.email,onChange:e=>R({...L,email:e.target.value}),required:!0})]})]}),(0,h.jsxs)(`div`,{className:`form-group`,children:[(0,h.jsx)(`label`,{children:`Account Role`}),(0,h.jsxs)(`div`,{className:`input-with-icon readonly`,children:[(0,h.jsx)(ne,{size:16}),(0,h.jsx)(`input`,{type:`text`,value:e?.role||`Admin`,readOnly:!0})]})]})]}),(0,h.jsx)(`div`,{className:`divider`}),(0,h.jsx)(`div`,{className:`card-header`,style:{padding:`0 0 16px`},children:(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`h2`,{children:`Change Password`}),(0,h.jsx)(`p`,{children:`Leave blank to keep current password`})]})}),(0,h.jsxs)(`div`,{className:`form-grid`,children:[(0,h.jsxs)(`div`,{className:`form-group`,children:[(0,h.jsx)(`label`,{children:`New Password`}),(0,h.jsxs)(`div`,{className:`input-with-icon`,children:[(0,h.jsx)(pe,{size:16}),(0,h.jsx)(`input`,{type:z?`text`:`password`,value:L.password,onChange:e=>R({...L,password:e.target.value}),placeholder:`••••••••`}),(0,h.jsx)(`button`,{type:`button`,className:`eye-toggle`,onClick:Ht,children:z?(0,h.jsx)(l,{size:16}):(0,h.jsx)(f,{size:16})})]})]}),(0,h.jsxs)(`div`,{className:`form-group`,children:[(0,h.jsx)(`label`,{children:`Confirm Password`}),(0,h.jsxs)(`div`,{className:`input-with-icon`,children:[(0,h.jsx)(pe,{size:16}),(0,h.jsx)(`input`,{type:z?`text`:`password`,value:L.confirmPassword,onChange:e=>R({...L,confirmPassword:e.target.value}),placeholder:`••••••••`}),(0,h.jsx)(`button`,{type:`button`,className:`eye-toggle`,onClick:Ht,children:z?(0,h.jsx)(l,{size:16}):(0,h.jsx)(f,{size:16})})]})]})]}),(0,h.jsx)(`div`,{style:{marginTop:32},children:(0,h.jsx)(`button`,{type:`submit`,className:`btn-save`,disabled:g,children:g?`Saving...`:(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(ee,{size:18}),` Save Changes`]})})})]})]}),n===`users`&&$&&(0,h.jsx)(`div`,{className:`fade-in`,children:ut?(0,h.jsxs)(`div`,{className:`settings-card`,children:[(0,h.jsx)(`div`,{className:`card-header`,children:(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`h2`,{children:V?`Edit User`:`Add New User`}),(0,h.jsx)(`p`,{children:V?`Updating details for ${V.username}`:`Create a new account for your team`})]})}),(0,h.jsxs)(`form`,{onSubmit:V?Rt:Lt,className:`settings-form`,children:[(0,h.jsxs)(`div`,{className:`form-grid`,children:[(0,h.jsxs)(`div`,{className:`form-group`,children:[(0,h.jsx)(`label`,{children:`Username`}),(0,h.jsx)(`input`,{type:`text`,value:G.username,onChange:e=>K({...G,username:e.target.value}),required:!0})]}),(0,h.jsxs)(`div`,{className:`form-group`,children:[(0,h.jsx)(`label`,{children:`Email Address`}),(0,h.jsx)(`input`,{type:`email`,value:G.email,onChange:e=>K({...G,email:e.target.value}),required:!0})]}),(0,h.jsxs)(`div`,{className:`form-group`,children:[(0,h.jsx)(`label`,{children:`Role`}),(0,h.jsxs)(`select`,{value:G.role,onChange:e=>{let t=e.target.value,n=G.branch;[`Order Taker`,`Cashier`].includes(t)&&(!n||n.startsWith(`Restaurant`))?n=`Branch 1`:t===`Operator`&&(!n||n.startsWith(`Branch`))?n=`Restaurant 1`:[`Order Taker`,`Cashier`,`Operator`,`Employee`].includes(t)||(n=``),K({...G,role:t,shift:t===`Operator`?G.shift||`Morning`:``,branch:n})},children:[(0,h.jsx)(`option`,{value:`Admin`,children:`Admin`}),(0,h.jsx)(`option`,{value:`Order Taker`,children:`Order Taker`}),(0,h.jsx)(`option`,{value:`Cashier`,children:`Cashier`}),(0,h.jsx)(`option`,{value:`Operator`,children:`Operator`}),(0,h.jsx)(`option`,{value:`Salary Pay Operator`,children:`Salary Pay Operator`}),(0,h.jsx)(`option`,{value:`HR Manager`,children:`HR Manager`}),(0,h.jsx)(`option`,{value:`Management`,children:`Management`}),(0,h.jsx)(`option`,{value:`Employee`,children:`Employee`}),e?.role?.toLowerCase()===`developer`&&(0,h.jsx)(`option`,{value:`Developer`,children:`Developer`})]})]}),(G.role===`Order Taker`||G.role===`Cashier`||G.role===`Operator`)&&(0,h.jsxs)(`div`,{className:`form-group`,children:[(0,h.jsx)(`label`,{children:`Assigned Restaurant`}),(0,h.jsx)(`select`,{value:G.branch||(G.role===`Operator`?`Restaurant 1`:`Branch 1`),onChange:e=>K({...G,branch:e.target.value}),children:G.role===`Operator`?(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(`option`,{value:`Restaurant 1`,children:`Restaurant 1`}),(0,h.jsx)(`option`,{value:`Restaurant 2`,children:`Restaurant 2`}),(0,h.jsx)(`option`,{value:`Restaurant 3`,children:`Restaurant 3`})]}):(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(`option`,{value:`Branch 1`,children:`Branch 1`}),(0,h.jsx)(`option`,{value:`Branch 2`,children:`Branch 2`}),(0,h.jsx)(`option`,{value:`Branch 3`,children:`Branch 3`})]})})]}),G.role===`Employee`&&(0,h.jsxs)(`div`,{className:`form-group`,style:{gridColumn:`span 2`},children:[(0,h.jsxs)(`label`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,fontWeight:700},children:[(0,h.jsx)(`span`,{children:`Linked Employee Record *`}),G.employee_id&&(0,h.jsxs)(`span`,{style:{fontSize:11,color:`var(--primary)`,fontWeight:600},children:[`#`,G.employee_id,` Selected`]})]}),(0,h.jsxs)(`select`,{value:G.employee_id||``,onChange:e=>{let t=e.target.value,n=ot.find(e=>String(e.id)===String(t)),r={...G,employee_id:t};n&&(V||(G.username||(r.username=(n.name||``).toLowerCase().replace(/\s+/g,`_`)),!G.email&&n.email&&(r.email=n.email)),n.branch&&(r.branch=n.branch)),K(r)},required:!0,style:{padding:`12px 14px`,borderRadius:`12px`,border:`1.5px solid var(--surface-2)`,background:`var(--surface)`,fontSize:`14px`,width:`100%`,color:`var(--text-primary)`},children:[(0,h.jsx)(`option`,{value:``,children:`-- Select an Employee from Database --`}),ot.map(e=>{let t=e.linked_user_id&&(!V||e.linked_user_id!==V.id);return(0,h.jsxs)(`option`,{value:e.id,disabled:t,children:[e.name,` (`,e.employee_code||`EMP-${e.id}`,`) — `,e.role||`Staff`,` `,e.branch?`[${e.branch}]`:``,` `,t?`⚠️ (Already linked to @${e.linked_username})`:``]},e.id)})]}),(0,h.jsx)(`p`,{style:{fontSize:11.5,color:`var(--text-muted)`,margin:`4px 0 0 0`},children:`Linking an employee connects this login account to their Employee Portal, attendance, and Khata.`})]}),(G.role===`Operator`||G.role===`Employee`)&&(0,h.jsxs)(`div`,{className:`form-group`,style:{position:`relative`},ref:tt,children:[(0,h.jsx)(`label`,{children:`Assigned Shift(s)`}),(0,h.jsxs)(`div`,{className:`form-group-input`,style:{padding:`12px 14px`,border:`1.5px solid var(--surface-2)`,borderRadius:`12px`,background:`var(--surface)`,cursor:`pointer`,display:`flex`,justifyContent:`space-between`,alignItems:`center`,minHeight:`45px`},onClick:()=>W(!ft),children:[(0,h.jsx)(`div`,{style:{flex:1,whiteSpace:`nowrap`,overflow:`hidden`,textOverflow:`ellipsis`,fontSize:`14px`,color:G.shift?`var(--text-primary)`:`var(--text-muted)`},children:G.shift?G.shift.split(`,`).join(`, `):`Select Shifts...`}),(0,h.jsx)(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,style:{flexShrink:0,color:`var(--text-muted)`},children:(0,h.jsx)(`path`,{d:`m6 9 6 6 6-6`})})]}),ft&&(0,h.jsx)(`div`,{style:{position:`absolute`,top:`100%`,left:0,right:0,marginTop:`8px`,background:`white`,border:`1px solid var(--surface-2)`,borderRadius:`12px`,boxShadow:`0 10px 25px rgba(0,0,0,0.1)`,zIndex:100,maxHeight:`220px`,overflowY:`auto`,padding:`8px`},children:pt.map(e=>{let t=G.shift?G.shift.split(`,`):[],n=t.includes(e);return(0,h.jsxs)(`label`,{style:{display:`flex`,alignItems:`center`,padding:`10px 12px`,gap:`12px`,cursor:`pointer`,borderRadius:`8px`,transition:`background 0.2s`,background:n?`rgba(var(--primary-rgb), 0.05)`:`transparent`},onMouseOver:e=>!n&&(e.currentTarget.style.background=`var(--surface-1)`),onMouseOut:e=>!n&&(e.currentTarget.style.background=`transparent`),children:[(0,h.jsx)(`input`,{type:`checkbox`,checked:n,onChange:n=>{let r;r=n.target.checked?[...t,e]:t.filter(t=>t!==e),K({...G,shift:r.join(`,`)})},style:{width:`18px`,height:`18px`,cursor:`pointer`,accentColor:`var(--primary)`,margin:0}}),(0,h.jsx)(`span`,{style:{fontSize:`14px`,fontWeight:n?600:500,color:`var(--text-primary)`},children:e})]},e)})})]}),G.role===`Employee`&&(0,h.jsxs)(`div`,{className:`form-group`,style:{position:`relative`},ref:nt,children:[(0,h.jsx)(`label`,{children:`Assigned Branch(es)`}),(0,h.jsxs)(`div`,{className:`form-group-input`,style:{padding:`12px 14px`,border:`1.5px solid var(--surface-2)`,borderRadius:`12px`,background:`var(--surface)`,cursor:`pointer`,display:`flex`,justifyContent:`space-between`,alignItems:`center`,minHeight:`45px`},onClick:e=>{e.stopPropagation(),q(!ht)},children:[(0,h.jsx)(`div`,{style:{flex:1,whiteSpace:`nowrap`,overflow:`hidden`,textOverflow:`ellipsis`,fontSize:`14px`,color:G.branch?`var(--text-primary)`:`var(--text-muted)`},children:G.branch?G.branch.split(`,`).join(`, `):`Select Branches...`}),(0,h.jsx)(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,style:{flexShrink:0,color:`var(--text-muted)`},children:(0,h.jsx)(`path`,{d:`m6 9 6 6 6-6`})})]}),ht&&(0,h.jsx)(`div`,{style:{position:`absolute`,bottom:`100%`,left:0,right:0,marginBottom:`8px`,background:`white`,border:`1px solid var(--surface-2)`,borderRadius:`12px`,boxShadow:`0 10px 25px rgba(0,0,0,0.1)`,zIndex:100,maxHeight:`220px`,overflowY:`auto`,padding:`8px`},children:mt.map(e=>{let t=G.branch?G.branch.split(`,`):[],n=t.includes(e);return(0,h.jsxs)(`label`,{style:{display:`flex`,alignItems:`center`,padding:`10px 12px`,gap:`12px`,cursor:`pointer`,borderRadius:`8px`,transition:`background 0.2s`,background:n?`rgba(var(--primary-rgb), 0.05)`:`transparent`},onMouseOver:e=>!n&&(e.currentTarget.style.background=`var(--surface-1)`),onMouseOut:e=>!n&&(e.currentTarget.style.background=`transparent`),children:[(0,h.jsx)(`input`,{type:`checkbox`,checked:n,onChange:n=>{let r;r=n.target.checked?[...t,e]:t.filter(t=>t!==e),K({...G,branch:r.join(`,`)})},style:{width:`18px`,height:`18px`,cursor:`pointer`,accentColor:`var(--primary)`,margin:0}}),(0,h.jsx)(`span`,{style:{fontSize:`14px`,fontWeight:n?600:500,color:`var(--text-primary)`},children:e})]},e)})})]}),(0,h.jsxs)(`div`,{className:`form-group`,children:[(0,h.jsx)(`label`,{children:V?`New Password (Optional)`:`Password`}),(0,h.jsxs)(`div`,{className:`input-with-icon`,children:[(0,h.jsx)(pe,{size:16}),(0,h.jsx)(`input`,{type:H?`text`:`password`,value:G.password,onChange:e=>K({...G,password:e.target.value}),required:!V,placeholder:V?`Leave blank to keep current`:``,disabled:V?.role?.toLowerCase()===`developer`&&e.role?.toLowerCase()!==`developer`,style:{paddingRight:36}}),(0,h.jsx)(`button`,{type:`button`,className:`eye-toggle`,onClick:e=>{e.preventDefault(),e.stopPropagation(),U(!H)},children:H?(0,h.jsx)(l,{size:16}):(0,h.jsx)(f,{size:16})})]})]})]}),(0,h.jsxs)(`div`,{style:{display:`flex`,gap:12,marginTop:24},children:[(0,h.jsx)(`button`,{type:`submit`,className:`btn-save`,disabled:g,children:g?`Processing...`:V?`Update User`:`Create User`}),(0,h.jsx)(`button`,{type:`button`,className:`btn-cancel`,onClick:()=>{B(!1),dt(null),K({username:``,email:``,password:``,role:`Operator`,shift:``,branch:``,employee_id:``}),U(!1)},children:`Cancel`})]})]})]}):(0,h.jsxs)(`div`,{className:`settings-card`,children:[(0,h.jsxs)(`div`,{className:`card-header settings-team-header`,style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`},children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`h2`,{children:`Team Members`}),(0,h.jsx)(`p`,{children:`Manage access levels and account status`})]}),(0,h.jsxs)(`div`,{className:`settings-team-actions`,style:{display:`flex`,gap:12},children:[(0,h.jsxs)(`button`,{className:`btn-cancel`,onClick:Q,style:{display:`flex`,alignItems:`center`,justifyContent:`center`,gap:6,height:38,padding:`0 12px`,fontSize:13,background:`var(--surface-1)`,color:`var(--text)`,border:`1.5px solid var(--surface-2)`,borderRadius:8,cursor:`pointer`},children:[(0,h.jsx)(u,{size:14}),` Refresh`]}),(0,h.jsxs)(`button`,{className:`btn-add-user`,onClick:()=>B(!0),style:{display:`flex`,alignItems:`center`,justifyContent:`center`,gap:6},children:[(0,h.jsx)(ve,{size:18}),` Add User`]})]})]}),(0,h.jsxs)(`div`,{style:{display:`flex`,gap:`8px`,padding:`16px 24px 0 24px`,background:`var(--surface-1)`,overflowX:`auto`,whiteSpace:`nowrap`},children:[(0,h.jsx)(`button`,{onClick:()=>{yt(`system`),vt(`Admin`),bt(`All`)},style:{padding:`10px 20px`,border:`none`,background:Y===`system`?`var(--primary)`:`var(--surface-2)`,color:Y===`system`?`white`:`var(--text-muted)`,borderRadius:`8px 8px 0 0`,fontWeight:600,cursor:`pointer`,flexShrink:0},children:`System Users`}),(0,h.jsx)(`button`,{onClick:()=>{yt(`employee`),vt(`Employee`),bt(`All`)},style:{padding:`10px 20px`,border:`none`,background:Y===`employee`?`var(--primary)`:`var(--surface-2)`,color:Y===`employee`?`white`:`var(--text-muted)`,borderRadius:`8px 8px 0 0`,fontWeight:600,cursor:`pointer`,flexShrink:0},children:`Employees`})]}),(0,h.jsx)(`div`,{style:{display:`flex`,flexWrap:`wrap`,gap:`12px`,padding:`16px 24px`,borderBottom:`1px solid var(--surface-2)`,background:`var(--surface-1)`,alignItems:`center`},children:(0,h.jsxs)(`div`,{style:{flex:1,minWidth:`240px`,position:`relative`},children:[(0,h.jsx)(`span`,{style:{position:`absolute`,left:`12px`,top:`50%`,transform:`translateY(-50%)`,color:`var(--text-muted)`,display:`flex`,alignItems:`center`},children:(0,h.jsxs)(`svg`,{xmlns:`http://www.w3.org/2000/svg`,width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.3`,strokeLinecap:`round`,strokeLinejoin:`round`,children:[(0,h.jsx)(`circle`,{cx:`11`,cy:`11`,r:`8`}),(0,h.jsx)(`path`,{d:`m21 21-4.3-4.3`})]})}),(0,h.jsx)(`input`,{type:`text`,placeholder:`Search by name or email...`,value:gt,onChange:e=>_t(e.target.value),style:{width:`100%`,padding:`10px 12px 10px 36px`,border:`1.5px solid var(--surface-2)`,borderRadius:`8px`,background:`var(--surface)`,color:`var(--text)`,outline:`none`,fontSize:`13px`}})]})}),Y===`system`&&(0,h.jsx)(`div`,{style:{display:`flex`,gap:`8px`,padding:`12px 24px 0`,background:`var(--surface-1)`,overflowX:`auto`},children:[`Admin`,`Management`,`Operator`,`Salary Pay Operator`,`Cashier`,`Order Taker`].map(e=>(0,h.jsx)(`button`,{onClick:()=>vt(e),style:{padding:`6px 16px`,border:`1px solid var(--surface-2)`,background:J===e?`var(--primary)`:`white`,color:J===e?`white`:`var(--text)`,borderRadius:`20px`,fontSize:`13px`,cursor:`pointer`,fontWeight:500,whiteSpace:`nowrap`},children:e},e))}),(0,h.jsx)(`div`,{style:{display:`flex`,gap:`8px`,padding:`12px 24px`,background:`var(--surface-1)`,borderBottom:`1.5px solid var(--surface-2)`,overflowX:`auto`},children:[`All`,`1`,`2`,`3`].map(e=>(0,h.jsx)(`button`,{onClick:()=>bt(e),style:{padding:`6px 16px`,border:`1px solid var(--surface-2)`,background:X===e?`var(--primary)`:`white`,color:X===e?`white`:`var(--text)`,borderRadius:`20px`,fontSize:`13px`,cursor:`pointer`,fontWeight:500,whiteSpace:`nowrap`},children:e===`All`?`All Branches`:`Branch ${e} (R${e})`},e))}),(0,h.jsx)(`div`,{className:`users-table-wrap desktop-table-view`,style:{overflowX:`auto`,width:`100%`},children:(0,h.jsx)(`div`,{style:{minWidth:`800px`},children:(0,h.jsxs)(`table`,{className:`users-table`,style:{width:`100%`},children:[(0,h.jsx)(`thead`,{children:(0,h.jsxs)(`tr`,{children:[(0,h.jsx)(`th`,{style:{width:`50px`},children:`#`}),(0,h.jsx)(`th`,{children:`User`}),(0,h.jsx)(`th`,{children:`Role`}),(0,h.jsx)(`th`,{children:`Shift`}),(0,h.jsx)(`th`,{children:`Date Joined`}),(0,h.jsx)(`th`,{style:{textAlign:`right`},children:`Actions`})]})}),(0,h.jsx)(`tbody`,{children:Ft.map((t,n)=>(0,h.jsxs)(`tr`,{children:[(0,h.jsx)(`td`,{style:{fontSize:13,fontWeight:600,color:`var(--text-muted)`},children:n+1}),(0,h.jsx)(`td`,{children:(0,h.jsxs)(`div`,{className:`user-info-cell`,children:[(0,h.jsx)(`div`,{className:`user-avatar-sm`,children:t.username[0].toUpperCase()}),(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`div`,{className:`user-name`,children:t.username}),(0,h.jsx)(`div`,{className:`user-email`,children:t.email})]})]})}),(0,h.jsx)(`td`,{children:(0,h.jsxs)(`span`,{className:`role-badge ${t.role.toLowerCase()}`,children:[t.role===`Admin`?(0,h.jsx)(ue,{size:14}):t.role===`Developer`?(0,h.jsx)(ne,{size:14}):(0,h.jsx)(se,{size:14}),t.role]})}),(0,h.jsx)(`td`,{style:{fontSize:13,fontWeight:600,color:`var(--text-secondary)`},children:t.role===`Employee`?t.employee_name?(0,h.jsxs)(`span`,{style:{fontSize:12,fontWeight:700,color:`var(--primary)`,display:`inline-flex`,alignItems:`center`,gap:4},children:[`👤 `,t.employee_name,` (`,t.employee_code||`EMP-${t.employee_id}`,`)`]}):(0,h.jsx)(`span`,{style:{fontSize:11,color:`#f59e0b`,fontWeight:600},children:`⚠️ Not Linked`}):t.role===`Operator`?t.shift||`None`:`--`}),(0,h.jsx)(`td`,{children:new Date(t.created_at).toLocaleDateString()}),(0,h.jsx)(`td`,{children:(0,h.jsxs)(`div`,{className:`user-actions`,children:[(0,h.jsx)(`button`,{className:`action-btn edit`,onClick:()=>Vt(t),title:`Edit User`,disabled:t.role?.toLowerCase()===`developer`&&e.role?.toLowerCase()!==`developer`,children:(0,h.jsx)(te,{size:16})}),(0,h.jsx)(`button`,{className:`action-btn delete`,onClick:()=>zt(t.id),title:`Delete User`,disabled:t.id===e.id||t.role?.toLowerCase()===`developer`&&e.role?.toLowerCase()!==`developer`,children:(0,h.jsx)(be,{size:16})})]})})]},t.id))})]})})}),(0,h.jsx)(`div`,{className:`users-mobile-grid`,style:{display:`none`,flexDirection:`column`,gap:`12px`,marginTop:`16px`},children:Ft.map(t=>(0,h.jsx)(Se,{u:t,currentUser:e,onEdit:Vt,onDelete:zt},t.id))})]})}),n===`salary_permissions`&&$&&(0,h.jsx)(`div`,{className:`fade-in`,children:(0,h.jsxs)(`div`,{className:`settings-card`,children:[(0,h.jsxs)(`div`,{className:`card-header`,style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`},children:[(0,h.jsxs)(`div`,{children:[(0,h.jsxs)(`h2`,{style:{display:`flex`,alignItems:`center`,gap:`8px`,margin:`0 0 4px 0`},children:[(0,h.jsx)(ge,{size:22,style:{color:`var(--primary, #d97706)`}}),`Salary Payable User Permissions`]}),(0,h.jsx)(`p`,{style:{margin:0},children:`Configure access levels (Only View vs Pay Now) and authorized salary months for Salary Pay Operator users.`})]}),(0,h.jsxs)(`button`,{type:`button`,className:`btn btn-secondary btn-sm`,onClick:Ct,disabled:M,style:{display:`inline-flex`,alignItems:`center`,gap:`5px`},children:[(0,h.jsx)(u,{size:14,className:M?`spin`:``}),`Refresh`]})]}),M?(0,h.jsxs)(`div`,{style:{padding:`30px`,textAlign:`center`,color:`#64748b`},children:[(0,h.jsx)(u,{size:24,className:`spin`,style:{margin:`0 auto 10px auto`}}),(0,h.jsx)(`p`,{children:`Loading salary payable users & permissions...`})]}):D.length===0?(0,h.jsxs)(`div`,{style:{padding:`30px`,textAlign:`center`,color:`#64748b`,background:`#f8fafc`,borderRadius:`8px`,border:`1px dashed #cbd5e1`,margin:`16px 0`},children:[(0,h.jsx)(o,{size:32,style:{color:`#d97706`,marginBottom:`8px`}}),(0,h.jsx)(`h4`,{style:{margin:`0 0 6px 0`,color:`#1e293b`},children:`No Salary Pay Operator Users Found`}),(0,h.jsx)(`p`,{style:{margin:0,fontSize:`13px`},children:`Create a user with the role "Salary Pay Operator" in User Management to configure permissions.`})]}):(0,h.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`260px 1fr`,gap:`24px`,marginTop:`16px`},children:[(0,h.jsxs)(`div`,{style:{borderRight:`1px solid var(--border, #e2e8f0)`,paddingRight:`16px`},children:[(0,h.jsxs)(`label`,{style:{display:`block`,fontSize:`12px`,fontWeight:700,color:`#64748b`,textTransform:`uppercase`,marginBottom:`8px`},children:[`Salary Payable Users (`,D.length,`)`]}),(0,h.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`6px`},children:D.map(e=>{let t=k===e.id;return(0,h.jsxs)(`button`,{type:`button`,onClick:()=>wt(e),style:{display:`flex`,flexDirection:`column`,alignItems:`flex-start`,padding:`10px 12px`,borderRadius:`8px`,border:t?`2px solid var(--primary, #d97706)`:`1px solid var(--border, #cbd5e1)`,background:t?`#fffbeb`:`#fff`,cursor:`pointer`,textAlign:`left`,transition:`all 0.15s ease`},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,width:`100%`,alignItems:`center`},children:[(0,h.jsx)(`span`,{style:{fontWeight:800,fontSize:`13px`,color:`#1e293b`},children:e.username}),(0,h.jsx)(`span`,{style:{fontSize:`10px`,fontWeight:800,padding:`2px 6px`,borderRadius:`4px`,background:e.permission_type===`pay_now`?`#dcfce7`:`#e0f2fe`,color:e.permission_type===`pay_now`?`#15803d`:`#0369a1`},children:e.permission_type===`pay_now`?`Pay Now`:`Only View`})]}),(0,h.jsxs)(`span`,{style:{fontSize:`11px`,color:`#64748b`,marginTop:`2px`},children:[e.name?`${e.name} • `:``,`Branch: `,e.branch||`All`]})]},e.id)})})]}),(0,h.jsx)(`div`,{children:(()=>{let e=D.find(e=>e.id===k);return e?(0,h.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`20px`},children:[(0,h.jsxs)(`div`,{style:{background:`#f8fafc`,padding:`12px 16px`,borderRadius:`8px`,border:`1px solid #e2e8f0`,display:`flex`,justifyContent:`space-between`,alignItems:`center`},children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`span`,{style:{fontSize:`11px`,fontWeight:700,color:`#64748b`,textTransform:`uppercase`},children:`Configuring Permissions For:`}),(0,h.jsxs)(`div`,{style:{fontSize:`16px`,fontWeight:800,color:`#0f172a`},children:[e.username,` `,e.name?`(${e.name})`:``]}),(0,h.jsxs)(`div`,{style:{fontSize:`12px`,color:`#475569`},children:[`Email: `,e.email||`None`,` • Branch: `,e.branch||`All Branches`]})]}),e.updated_at&&(0,h.jsxs)(`span`,{style:{fontSize:`11px`,color:`#94a3b8`},children:[`Last updated by `,e.updated_by||`Admin`]})]}),(0,h.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:`20px`},children:[(0,h.jsxs)(`div`,{style:{background:`#f0f9ff`,border:`1.5px solid #bae6fd`,borderRadius:`12px`,padding:`16px`},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,marginBottom:`10px`,flexWrap:`wrap`,gap:`8px`},children:[(0,h.jsxs)(`div`,{children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`8px`},children:[(0,h.jsx)(f,{size:16,color:`#0284c7`}),(0,h.jsx)(`label`,{style:{fontSize:`13.5px`,fontWeight:800,color:`#0369a1`,margin:0},children:`1. Month View Permission (View Only / Access)`})]}),(0,h.jsxs)(`p`,{style:{margin:`3px 0 0 0`,fontSize:`12px`,color:`#0284c7`},children:[`Select months that `,e.username,` is authorized to `,(0,h.jsx)(`strong`,{children:`VIEW`}),`. Unselected months will be hidden.`]})]}),(0,h.jsxs)(`div`,{style:{display:`flex`,gap:`6px`},children:[(0,h.jsx)(`button`,{type:`button`,className:`btn btn-secondary btn-sm`,onClick:()=>{j(e=>({...e,allowed_view_months:[...O],allowed_months:[...O]}))},style:{fontSize:`11px`,padding:`3px 9px`,background:`#fff`,borderColor:`#38bdf8`,color:`#0369a1`},children:`Select All View`}),(0,h.jsx)(`button`,{type:`button`,className:`btn btn-secondary btn-sm`,onClick:()=>{j(e=>({...e,allowed_view_months:[],allowed_months:[]}))},style:{fontSize:`11px`,padding:`3px 9px`,background:`#fff`,borderColor:`#cbd5e1`},children:`Clear All View`})]})]}),(0,h.jsx)(`div`,{style:{display:`flex`,flexWrap:`wrap`,gap:`8px`,padding:`10px`,background:`#ffffff`,borderRadius:`8px`,border:`1px solid #e0f2fe`},children:O.map(e=>{let t=(A.allowed_view_months||[]).includes(e),n=xe(e);return(0,h.jsxs)(`button`,{type:`button`,onClick:()=>{j(n=>{let r=n.allowed_view_months||[],i=t?r.filter(t=>t!==e):[...r,e];return{...n,allowed_view_months:i,allowed_months:i}})},style:{display:`inline-flex`,alignItems:`center`,gap:`6px`,padding:`5px 12px`,borderRadius:`20px`,fontSize:`11.5px`,fontWeight:700,border:t?`1.5px solid #0284c7`:`1px solid #cbd5e1`,background:t?`#e0f2fe`:`#fff`,color:t?`#0369a1`:`#64748b`,cursor:`pointer`,transition:`all 0.15s ease`},children:[(0,h.jsx)(f,{size:13,style:{color:t?`#0284c7`:`#94a3b8`}}),(0,h.jsxs)(`span`,{children:[n,` (`,e,`)`]}),t&&(0,h.jsx)(oe,{size:13,style:{color:`#0284c7`}})]},`view-${e}`)})})]}),(0,h.jsxs)(`div`,{style:{background:`#f0fdf4`,border:`1.5px solid #bbf7d0`,borderRadius:`12px`,padding:`16px`},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,marginBottom:`10px`,flexWrap:`wrap`,gap:`8px`},children:[(0,h.jsxs)(`div`,{children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`8px`},children:[(0,h.jsx)(le,{size:16,color:`#16a34a`}),(0,h.jsx)(`label`,{style:{fontSize:`13.5px`,fontWeight:800,color:`#15803d`,margin:0},children:`2. Salary Payment Permission (Pay Now & Pay and Print)`})]}),(0,h.jsxs)(`p`,{style:{margin:`3px 0 0 0`,fontSize:`12px`,color:`#15803d`},children:[`Select months that `,e.username,` is authorized to `,(0,h.jsx)(`strong`,{children:`PROCESS SALARY PAYMENTS`}),` for.`]})]}),(0,h.jsxs)(`div`,{style:{display:`flex`,gap:`6px`},children:[(0,h.jsx)(`button`,{type:`button`,className:`btn btn-secondary btn-sm`,onClick:()=>{j(e=>{let t=[...O],n=e.allowed_view_months||[],r=Array.from(new Set([...n,...t]));return{...e,allowed_pay_months:t,allowed_view_months:r,allowed_months:r,permission_type:`pay_now`}})},style:{fontSize:`11px`,padding:`3px 9px`,background:`#fff`,borderColor:`#4ade80`,color:`#15803d`},children:`Select All Pay`}),(0,h.jsx)(`button`,{type:`button`,className:`btn btn-secondary btn-sm`,onClick:()=>{j(e=>({...e,allowed_pay_months:[]}))},style:{fontSize:`11px`,padding:`3px 9px`,background:`#fff`,borderColor:`#cbd5e1`},children:`Clear All Pay`})]})]}),(0,h.jsx)(`div`,{style:{display:`flex`,flexWrap:`wrap`,gap:`8px`,padding:`10px`,background:`#ffffff`,borderRadius:`8px`,border:`1px solid #dcfce7`},children:O.map(e=>{let t=(A.allowed_pay_months||[]).includes(e),n=xe(e);return(0,h.jsxs)(`button`,{type:`button`,onClick:()=>{j(n=>{let r=n.allowed_pay_months||[],i=t?r.filter(t=>t!==e):[...r,e],a=n.allowed_view_months||[];return!t&&!a.includes(e)&&(a=[...a,e]),{...n,allowed_pay_months:i,allowed_view_months:a,allowed_months:a,permission_type:i.length>0?`pay_now`:`view_only`}})},style:{display:`inline-flex`,alignItems:`center`,gap:`6px`,padding:`5px 12px`,borderRadius:`20px`,fontSize:`11.5px`,fontWeight:700,border:t?`1.5px solid #16a34a`:`1px solid #cbd5e1`,background:t?`#dcfce7`:`#fff`,color:t?`#15803d`:`#64748b`,cursor:`pointer`,transition:`all 0.15s ease`},children:[(0,h.jsx)(le,{size:13,style:{color:t?`#16a34a`:`#94a3b8`}}),(0,h.jsxs)(`span`,{children:[n,` (`,e,`)`]}),t&&(0,h.jsx)(oe,{size:13,style:{color:`#16a34a`}})]},`pay-${e}`)})})]}),(0,h.jsxs)(`div`,{style:{background:`#f8fafc`,border:`1px solid #e2e8f0`,borderRadius:`10px`,padding:`14px`},children:[(0,h.jsxs)(`div`,{style:{fontSize:`12.5px`,fontWeight:800,color:`#334155`,marginBottom:`8px`},children:[`Configured Monthly Access Summary for @`,e.username,`:`]}),(0,h.jsx)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(auto-fill, minmax(220px, 1fr))`,gap:`8px`},children:O.slice(0,8).map(e=>{let t=(A.allowed_view_months||[]).includes(e),n=(A.allowed_pay_months||[]).includes(e);return(0,h.jsxs)(`div`,{style:{background:`#fff`,border:`1px solid #e2e8f0`,borderRadius:`6px`,padding:`6px 10px`,display:`flex`,justifyContent:`space-between`,alignItems:`center`,fontSize:`11.5px`},children:[(0,h.jsx)(`span`,{style:{fontWeight:700,color:`#1e293b`},children:xe(e)}),(0,h.jsxs)(`div`,{style:{display:`flex`,gap:`4px`},children:[t?(0,h.jsx)(`span`,{style:{background:`#e0f2fe`,color:`#0369a1`,fontSize:`10px`,fontWeight:800,padding:`2px 6px`,borderRadius:`4px`},children:`VIEW`}):(0,h.jsx)(`span`,{style:{background:`#f1f5f9`,color:`#94a3b8`,fontSize:`10px`,padding:`2px 6px`,borderRadius:`4px`},children:`NO VIEW`}),n?(0,h.jsx)(`span`,{style:{background:`#dcfce7`,color:`#15803d`,fontSize:`10px`,fontWeight:800,padding:`2px 6px`,borderRadius:`4px`},children:`PAY`}):(0,h.jsx)(`span`,{style:{background:`#fef2f2`,color:`#991b1b`,fontSize:`10px`,padding:`2px 6px`,borderRadius:`4px`},children:`LOCKED`})]})]},`summary-${e}`)})})]}),(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`8px`},children:[(0,h.jsx)(`label`,{style:{fontSize:`12px`,color:`#64748b`,fontWeight:600},children:`Add specific month:`}),(0,h.jsx)(`input`,{type:`month`,value:N,onChange:e=>Xe(e.target.value),style:{padding:`4px 8px`,borderRadius:`6px`,border:`1px solid #cbd5e1`,fontSize:`12px`}}),(0,h.jsx)(`button`,{type:`button`,className:`btn btn-secondary btn-sm`,onClick:()=>{N&&/^\d{4}-\d{2}$/.test(N)&&(O.includes(N)||Ge(e=>[...e,N]),j(e=>({...e,allowed_view_months:Array.from(new Set([...e.allowed_view_months||[],N])),allowed_pay_months:Array.from(new Set([...e.allowed_pay_months||[],N])),allowed_months:Array.from(new Set([...e.allowed_months||[],N]))})),Xe(``))},style:{fontSize:`11px`,padding:`4px 10px`},children:`Add Month`})]})]}),(0,h.jsx)(`div`,{style:{borderTop:`1px solid #e2e8f0`,paddingTop:`16px`,display:`flex`,justifyContent:`flex-end`,gap:`10px`},children:(0,h.jsxs)(`button`,{type:`button`,className:`btn btn-primary`,onClick:Tt,disabled:Je,style:{display:`inline-flex`,alignItems:`center`,gap:`6px`,padding:`10px 24px`,fontWeight:800,fontSize:`13px`},children:[Je?(0,h.jsx)(u,{size:14,className:`spin`}):(0,h.jsx)(re,{size:14}),`Save Permissions for `,e.username]})})]}):null})()})]})]})})]})]}),(0,h.jsx)(`style`,{children:`
        .settings-container {
          padding: 24px;
          max-width: 1200px;
          margin: 0 auto;
        }

        .settings-header {
          margin-bottom: 32px;
        }

        .settings-header h1 {
          margin: 0;
          font-size: 24px;
          font-weight: 800;
          color: var(--text-primary);
        }

        .settings-header p {
          margin: 4px 0 0;
          color: var(--text-secondary);
          font-size: 14px;
        }

        .settings-layout {
          display: grid;
          grid-template-columns: 240px 1fr;
          gap: 32px;
          align-items: start;
        }

        /* Nav Sidebar */
        .settings-nav {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .settings-nav-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 16px;
          border-radius: 12px;
          border: none;
          background: transparent;
          color: var(--text-secondary);
          font-size: 14px;
          font-weight: 600;
          text-align: left;
          cursor: pointer;
          transition: all 0.2s;
        }

        .settings-nav-item:hover {
          background: var(--surface-2);
          color: var(--text-primary);
        }

        .settings-nav-item.active {
          background: color-mix(in srgb, var(--red) 10%, transparent);
          color: var(--red);
          border: 1px solid color-mix(in srgb, var(--red) 20%, transparent);
        }

        /* Settings Card */
        .settings-card {
          background: white;
          border: 1px solid var(--surface-2);
          border-radius: 20px;
          padding: 24px;
          box-shadow: var(--shadow);
        }

        .card-header {
          margin-bottom: 24px;
        }

        .card-header h2 {
          margin: 0;
          font-size: 18px;
          color: var(--text-primary);
          font-weight: 700;
        }

        .card-header p {
          margin: 4px 0 0;
          color: var(--text-muted);
          font-size: 14px;
        }

        /* Form Styling */
        .settings-form {
          display: flex;
          flex-direction: column;
        }

        .form-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
        }

        .form-group {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .form-group label {
          font-size: 13px;
          font-weight: 600;
          color: var(--text-secondary);
        }

        .input-with-icon {
          position: relative;
          width: 100%;
          display: flex;
          align-items: center;
        }

        .input-with-icon svg:first-child {
          position: absolute;
          left: 14px;
          color: var(--text-muted);
          z-index: 10;
          pointer-events: none;
        }

        .input-with-icon input, 
        .form-group input:not([type="radio"]):not([type="checkbox"]), 
        .form-group select {
          width: 100%;
          padding: 12px 42px 12px 42px;
          background: var(--surface);
          border: 1.5px solid var(--surface-2);
          border-radius: 12px;
          color: var(--text-primary);
          font-size: 14px;
          outline: none;
          transition: all 0.2s;
          display: block;
        }

        .form-group input:not([readonly]):not([type="radio"]):not([type="checkbox"]):focus,
        .form-group select:focus {
          border-color: var(--red);
          background: white;
          box-shadow: 0 0 0 3px color-mix(in srgb, var(--red) 10%, transparent);
        }

        .input-with-icon.readonly input {
          background: var(--surface-2);
          color: var(--text-muted);
          cursor: default;
        }

        .form-group select {
          padding-left: 14px;
          appearance: none;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='rgba(0,0,0,0.3)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
          background-repeat: no-repeat;
          background-position: right 14px center;
        }

        .input-with-icon .eye-toggle {
          position: absolute;
          right: 4px;
          top: 50%;
          transform: translateY(-50%);
          background: transparent;
          border: none;
          color: var(--text-muted);
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 34px;
          height: 34px;
          border-radius: 50%;
          z-index: 20;
          transition: all 0.2s;
        }

        .input-with-icon .eye-toggle:hover {
          background: var(--surface-2);
          color: var(--red);
        }

        .divider {
          height: 1px;
          background: var(--surface-2);
          margin: 32px 0;
        }

        /* Buttons */
        .btn-save {
          padding: 12px 24px;
          background: linear-gradient(135deg, var(--red), var(--red-dark));
          border: none;
          border-radius: 10px;
          color: #fff;
          font-size: 15px;
          font-weight: 700;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          transition: all 0.2s;
          box-shadow: 0 4px 12px rgba(227, 24, 55, 0.2);
        }

        .btn-save:hover { 
          opacity: 0.95;
          transform: translateY(-1px);
          box-shadow: 0 6px 16px rgba(227, 24, 55, 0.3);
        }
        
        .btn-save:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

        .btn-cancel {
          padding: 12px 24px;
          background: white;
          border: 1.5px solid var(--surface-2);
          border-radius: 10px;
          color: var(--text-secondary);
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        
        .btn-cancel:hover {
          background: var(--surface);
          color: var(--text-primary);
        }

        .btn-add-user {
          padding: 10px 16px;
          background: color-mix(in srgb, var(--red) 10%, transparent);
          border: 1px solid color-mix(in srgb, var(--red) 20%, transparent);
          border-radius: 10px;
          color: var(--red);
          font-size: 14px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.2s;
        }
        
        .btn-add-user:hover {
          background: var(--red);
          color: white;
        }

        /* Users Table */
        .users-table-wrap {
          margin-top: 16px;
          overflow-x: auto;
        }

        .users-table {
          width: 100%;
          border-collapse: collapse;
        }

        .users-table th {
          text-align: left;
          padding: 12px 16px;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 1px;
          color: var(--text-muted);
          border-bottom: 2px solid var(--surface-2);
        }

        .users-table td {
          padding: 16px;
          border-bottom: 1px solid var(--surface-2);
          color: var(--text-primary);
        }

        .user-info-cell {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .user-avatar-sm {
          width: 32px;
          height: 32px;
          border-radius: 10px;
          background: linear-gradient(135deg, var(--red), var(--orange));
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-weight: bold;
          font-size: 14px;
        }

        .user-name {
          font-size: 14px;
          font-weight: 600;
          color: var(--text-primary);
        }

        .user-email {
          font-size: 12px;
          color: var(--text-muted);
        }

        .role-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 10px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 700;
          text-transform: uppercase;
        }

        .role-badge.admin { background: color-mix(in srgb, var(--red) 10%, transparent); color: var(--red); }
        .role-badge.developer { background: color-mix(in srgb, #6366f1 10%, transparent); color: #6366f1; }
        .role-badge.operator { background: rgba(74,144,226,0.1); color: #4A90E2; }
        .role-badge.management { background: rgba(244,180,0,0.1); color: #F4B400; }
        .role-badge.employee { background: rgba(16,185,129,0.1); color: #10B981; }

        .user-actions {
          display: flex;
          justify-content: flex-end;
          gap: 8px;
        }

        .action-btn {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          border: 1px solid var(--surface-2);
          background: white;
          color: var(--text-muted);
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }

        .action-btn:hover:not(:disabled) {
          border-color: var(--text-primary);
          color: var(--text-primary);
          background: var(--surface);
        }

        .action-btn.delete:hover:not(:disabled) {
          border-color: #ff6b6b;
          color: #ff6b6b;
          background: #fff5f5;
        }
        
        .action-btn:disabled {
          opacity: 0.3;
          cursor: not-allowed;
        }

        .fade-in {
          animation: fadeIn 0.3s ease-in-out;
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 1000px) {
          .settings-layout {
            grid-template-columns: 1fr;
          }
          
          .settings-nav {
            flex-direction: row;
            flex-wrap: nowrap;
            overflow-x: auto;
            padding-bottom: 8px;
            width: 100%;
            -webkit-overflow-scrolling: touch;
          }
          
          .settings-nav-item {
            flex-shrink: 0;
            white-space: nowrap;
          }
          
          .form-grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 768px) {
          .desktop-table-view {
            display: none !important;
          }
          .users-mobile-grid {
            display: flex !important;
          }
          .settings-team-header {
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 16px !important;
          }
          .settings-team-actions {
            width: 100% !important;
            gap: 8px !important;
          }
          .settings-team-actions button {
            flex: 1 !important;
          }
          .settings-content, .settings-card, .settings-form {
            max-width: 100%;
            overflow-x: hidden;
            box-sizing: border-box;
          }
          .settings-container {
            overflow-x: hidden;
            width: 100%;
          }
        }

        /* POS Options Custom Styles */
        .pos-stock-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
        }

        @media (max-width: 900px) {
          .pos-stock-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 580px) {
          .pos-stock-grid {
            grid-template-columns: 1fr;
          }
        }

        .pos-stock-card {
          display: flex;
          align-items: flex-start;
          gap: 9px;
          padding: 10px 12px;
          border-radius: 10px;
          cursor: pointer;
          background: var(--surface);
          border: 1.5px solid var(--surface-2);
          transition: all 0.15s ease;
          user-select: none;
          position: relative;
          box-sizing: border-box;
        }

        .pos-stock-card:hover {
          border-color: #cbd5e1;
          background: #ffffff;
          transform: translateY(-1px);
          box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .pos-stock-card.selected {
          border-color: var(--primary) !important;
          background: rgba(244, 180, 0, 0.06) !important;
          box-shadow: 0 3px 12px rgba(244, 180, 0, 0.18) !important;
        }

        .pos-stock-card.selected:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 14px rgba(244, 180, 0, 0.22) !important;
        }

        .pos-view-pill-btn {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 5px 11px;
          border-radius: 6px;
          font-size: 12px;
          font-weight: 600;
          border: none;
          cursor: pointer;
          background: transparent;
          color: var(--text-muted);
          transition: all 0.15s ease;
        }

        .pos-view-pill-btn:hover {
          color: var(--text-primary);
        }

        .pos-view-pill-btn.active {
          background: #ffffff;
          color: var(--text-primary);
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.12);
        }
      `}),xt&&(0,h.jsx)(`div`,{className:`modal-overlay`,style:{zIndex:9999},children:(0,h.jsxs)(`div`,{className:`modal`,style:{maxWidth:400},children:[(0,h.jsxs)(`div`,{className:`modal-header`,children:[(0,h.jsx)(`h2`,{children:`Confirm Deletion`}),(0,h.jsx)(`button`,{className:`btn-close`,onClick:()=>Z(null),children:(0,h.jsx)(_e,{size:20})})]}),(0,h.jsxs)(`div`,{className:`modal-body`,style:{textAlign:`center`,padding:`20px 0`},children:[(0,h.jsx)(`p`,{style:{fontSize:16,marginBottom:20},children:`Are you sure you want to delete this user?`}),(0,h.jsxs)(`div`,{style:{display:`flex`,gap:12,justifyContent:`center`},children:[(0,h.jsx)(`button`,{className:`btn btn-secondary`,style:{padding:`10px 24px`},onClick:()=>Z(null),children:`Cancel`}),(0,h.jsx)(`button`,{className:`btn btn-primary`,style:{padding:`10px 24px`,background:`var(--red)`},onClick:Bt,children:`Yes, Delete`})]})]})]})})]})}function Se({u:e,currentUser:t,onEdit:n,onDelete:r}){let[i,a]=(0,m.useState)(!1);(0,m.useEffect)(()=>{let e=()=>a(!1);return window.addEventListener(`click`,e),()=>window.removeEventListener(`click`,e)},[]);let o=e.role?.toLowerCase()===`developer`&&t.role?.toLowerCase()!==`developer`,s=e.id===t.id||e.role?.toLowerCase()===`developer`&&t.role?.toLowerCase()!==`developer`;return(0,h.jsxs)(`div`,{style:{background:`white`,border:`1.5px solid var(--surface-2)`,borderRadius:`16px`,padding:`16px`,display:`flex`,alignItems:`center`,justifyContent:`space-between`,position:`relative`,boxShadow:`0 2px 8px rgba(0,0,0,0.03)`},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`12px`},children:[(0,h.jsx)(`div`,{style:{width:`40px`,height:`40px`,borderRadius:`12px`,background:`linear-gradient(135deg, var(--red), var(--orange))`,display:`flex`,alignItems:`center`,justifyContent:`center`,color:`white`,fontWeight:`bold`,fontSize:`15px`},children:e.username[0].toUpperCase()}),(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`div`,{style:{fontSize:`14px`,fontWeight:700,color:`var(--text-primary)`,marginBottom:`2px`},children:e.username}),(0,h.jsx)(`div`,{style:{fontSize:`11px`,color:`var(--text-muted)`,marginBottom:`6px`},children:e.email}),(0,h.jsxs)(`div`,{style:{display:`flex`,gap:`6px`,alignItems:`center`},children:[(0,h.jsx)(`span`,{className:`role-badge ${e.role.toLowerCase()}`,style:{fontSize:`10px`,padding:`2px 8px`},children:e.role}),e.role===`Operator`&&(0,h.jsxs)(`span`,{style:{fontSize:`10.5px`,color:`var(--text-secondary)`,fontWeight:600},children:[`• Shift `,e.shift||`None`]}),e.role===`Employee`&&(0,h.jsxs)(`span`,{style:{fontSize:`10.5px`,color:e.employee_name?`var(--primary)`:`#f59e0b`,fontWeight:600},children:[`• `,e.employee_name?`👤 ${e.employee_name}`:`⚠️ Not linked`]})]})]})]}),(0,h.jsxs)(`div`,{style:{position:`relative`},children:[(0,h.jsx)(`button`,{onClick:e=>{e.stopPropagation(),a(!i)},style:{background:`transparent`,border:`none`,cursor:`pointer`,padding:`8px`,color:`var(--text-muted)`,display:`flex`,alignItems:`center`,justifyContent:`center`},children:(0,h.jsx)(c,{size:20})}),i&&(0,h.jsxs)(`div`,{style:{position:`absolute`,right:0,top:`100%`,background:`white`,border:`1.5px solid var(--surface-2)`,borderRadius:`10px`,boxShadow:`0 4px 16px rgba(0,0,0,0.12)`,zIndex:100,minWidth:`120px`,marginTop:`4px`,overflow:`hidden`},children:[(0,h.jsx)(`button`,{onClick:()=>n(e),disabled:o,style:{display:`block`,width:`100%`,padding:`10px 14px`,background:`transparent`,border:`none`,cursor:o?`not-allowed`:`pointer`,fontSize:`13px`,textAlign:`left`,color:`var(--text-primary)`,fontWeight:500,opacity:o?.4:1},children:`Edit User`}),(0,h.jsx)(`button`,{onClick:()=>r(e.id),disabled:s,style:{display:`block`,width:`100%`,padding:`10px 14px`,background:`transparent`,border:`none`,cursor:s?`not-allowed`:`pointer`,fontSize:`13px`,textAlign:`left`,color:`#EF4444`,fontWeight:500,opacity:s?.4:1},children:`Delete User`})]})]})]})}export{g as default};