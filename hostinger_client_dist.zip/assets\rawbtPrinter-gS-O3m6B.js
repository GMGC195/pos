function e(e){return e?String(e).replace(/[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]+/g,``).replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g,``).replace(/\s*-\s*$/,``).replace(/^\s*-\s*/,``).replace(/\s*-\s*-+/g,`-`).replace(/\(\s*\)/g,``).replace(/\[\s*\]/g,``).replace(/\s+/g,` `).trim()||`Item`:``}var t=t=>{let n=``;n+=`\x1B@\x1B2`,n+=`\x1Ba`,n+=`\x1B!`,n+=`PIZZA SHOP\r
`,n+=`\x1B!\0`,n+=`Kitchen Slip\r
`,n+=`--------------------------------\r
`,n+=`\x1Ba\0`,n+=`Order #: ${t.order_id||t.id||`NEW`}\r
`,t.order_type&&(n+=`Type: ${e(t.order_type)}\r
`),t.customer_name&&(n+=`Customer: ${e(t.customer_name)}\r
`),t.table_no&&(n+=`Table: ${e(t.table_no)}\r
`),n+=`Date: ${new Date().toLocaleString()}\r
`,n+=`--------------------------------\r
`,t.items&&Array.isArray(t.items)&&t.items.forEach((t,r)=>{let i=e(t.name||t.item_name||``),a=t.qty||1,o=parseFloat(t.price||t.unit_price||0),s=t.total_price||o*a;n+=`${r+1}. ${i}\r
`,n+=`   ${a} x SAR ${o.toFixed(2)} = SAR ${Number(s).toFixed(2)}\r
`,t.selected_variations&&t.selected_variations.length>0&&(n+=`   + ${t.selected_variations.map(t=>e(t.name)).join(`, `)}\r
`)}),n+=`--------------------------------\r
`,n+=`\x1Ba`,n+=`Subtotal: SAR ${t.subtotal}\r
`,t.tax_amount>0&&(n+=`Tax: SAR ${t.tax_amount}\r
`),t.discount>0&&(n+=`Discount: -SAR ${t.discount}\r
`),n+=`\x1B!`,n+=`TOTAL: SAR ${t.total_amount}\r
`,n+=`\x1B!\0`,n+=`\x1Ba`,n+=`\r
Thank you for your order!\r
`,n+=`\r
\r
\r
\r
`,n+=`\x1Bi`;let r=`intent:${btoa(unescape(encodeURIComponent(n)))}#Intent;scheme=rawbt;package=ru.a402d.rawbtprinter;end;`;window.location.href=r},n=t=>{if(!t)return;let n=``,r=(e,t,n=32)=>{let r=String(e||``),i=String(t||``),a=Math.max(1,n-(r.length+i.length));return r+` `.repeat(a)+i},i=parseFloat(t.base_salary||0),a=parseFloat(t.deductions||0),o=t.payable_salary!==void 0&&t.payable_salary!==null&&t.payable_salary!==``?parseFloat(t.payable_salary):Math.max(0,i-a),s=parseFloat(t.cash_paid||0),c=parseFloat(t.bank_paid||0),l=t.paid_amount!==void 0&&t.paid_amount!==null&&parseFloat(t.paid_amount)>0?parseFloat(t.paid_amount):Math.round((s+c)*100)/100,u=t.net_salary!==void 0&&t.net_salary!==null&&t.net_salary!==``?parseFloat(t.net_salary):Math.max(0,o-parseFloat(t.this_month_adv||t.advance_deduction||0)),d=Math.round((u-l)*100)/100,f=(e,t=``)=>!e||e===`undefined`||e===`null`?t:String(e).trim(),p=f(t?.month||t?.pay_period,`Current`),m=f(t.branch||t.employee_branch,`B1`),h=`B1`;h=m.toLowerCase().includes(`3`)||m.toUpperCase()===`B3`||m.toUpperCase()===`R3`?`B3`:m.toLowerCase().includes(`2`)||m.toUpperCase()===`B2`||m.toUpperCase()===`R2`?`B2`:`B1`,n+=`\x1B@\x1B2`,n+=`\x1Ba`,n+=`\x1B!`,n+=`SALARY SLIP\r
`,n+=`\x1B!\0`,n+=new Date().toLocaleString()+`\r
`,n+=`================================\r
`,n+=`\x1Ba\0`,n+=r(`Employee:`,e(f(t.name||t.employee_name,`Staff`)))+`\r
`,n+=r(`ID:`,e(f(t.employee_id||t.employee_code||t.id,`N/A`)))+`\r
`,n+=r(`Branch:`,h)+`\r
`,n+=r(`Period:`,p)+`\r
`,n+=`--------------------------------\r
`,n+=r(`Base Salary:`,`SAR ${i.toFixed(2)}`)+`\r
`,n+=r(`Worked Duty:`,`SAR ${o.toFixed(2)}`)+`\r
`;let g=parseFloat(t.overtime_pay||0);g>0&&(n+=r(`Overtime:`,`SAR ${g.toFixed(2)}`)+`\r
`);let _=parseFloat(t.bonus||0);_>0&&(n+=r(`Bonus:`,`SAR ${_.toFixed(2)}`)+`\r
`),a>0&&(n+=r(`Cuts/Absence:`,`SAR ${a.toFixed(2)}`)+`\r
`);let v=parseFloat(t.this_month_adv||t.advance_deduction||0);v>0&&(n+=r(`Advance Deduct:`,`SAR ${v.toFixed(2)}`)+`\r
`),n+=`--------------------------------\r
`,n+=`\x1B!`,n+=r(`NET PAYABLE:`,`SAR ${u.toFixed(2)}`)+`\r
`,n+=`\x1B!\0`,n+=`================================\r
`;let y=parseFloat(t.current_paid_amount||0),b=parseFloat(t.current_cash_paid||0),x=parseFloat(t.current_bank_paid||0),S=t.previous_paid_amount===void 0?Math.max(0,l-y):parseFloat(t.previous_paid_amount);y>0?(n+=`CURRENT PAYMENT TRANSACTION\r
`,b>0&&(n+=r(`Current Cash:`,`SAR ${b.toFixed(2)}`)+`\r
`),x>0&&(n+=r(`Current Card/Bank:`,`SAR ${x.toFixed(2)}`)+`\r
`),n+=`\x1B!`,n+=r(`Current Disbursed:`,`SAR ${y.toFixed(2)}`)+`\r
`,n+=`\x1B!\0`,n+=`--------------------------------\r
`,n+=`CUMULATIVE SALARY SUMMARY\r
`,n+=r(`Previous Paid:`,`SAR ${S.toFixed(2)}`)+`\r
`,n+=r(`Total Paid to Date:`,`SAR ${l.toFixed(2)}`)+`\r
`,n+=r(`Remaining Salary:`,`SAR ${Math.max(0,d).toFixed(2)}`)+`\r
`,n+=r(`Status:`,l>=u?`PAID`:`PARTIAL`)+`\r
`):(n+=r(`Total Paid:`,`SAR ${l.toFixed(2)}`)+`\r
`,s>0&&(n+=r(`Cash Paid:`,`SAR ${s.toFixed(2)}`)+`\r
`),c>0&&(n+=r(`Bank Paid:`,`SAR ${c.toFixed(2)}`)+`\r
`),n+=r(`Remaining:`,`SAR ${Math.max(0,d).toFixed(2)}`)+`\r
`,n+=r(`Status:`,l>=u?`PAID`:`PARTIAL`)+`\r
`),n+=`--------------------------------\r
`,n+=`\r
Sign: __________________________\r
`,n+=`\x1Ba`,n+=`\r
Thank You\r
`,n+=`\r
\r
\r
`,n+=`\x1Bi`;let C=`intent:${btoa(unescape(encodeURIComponent(n)))}#Intent;scheme=rawbt;package=ru.a402d.rawbtprinter;end;`;window.location.href=C};export{t as n,n as t};