import{o as e}from"./rolldown-runtime-C0FnF6B9.js";import{h as t,m as n}from"./vendor-charts-QYGyGCjd.js";import"./vendor-misc-D0IzzYHV.js";import{n as r}from"./branding-BmC7Ep50.js";import{n as i}from"./AuthContext-DRuhpdUG.js";import{t as a}from"./api-Dg-qdIy2.js";import{R as o,t as s,w as c}from"./vendor-icons-8FYInbYV.js";var l=e(t(),1);function u(e){if(!e)return``;let t=String(e);for(let e of[/اصل پرچی کاؤنٹر سے حاصل کریں۔?/g,/مرغ بریانی/g,/گارلک بریڈ/g,/مرغ کڑاہی/g,/مرغ ہانڈی/g,/مرغ تکہ/g,/مرغ بوٹی/g,/مرغ کباب/g,/سیخ کباب/g,/ریشمی کباب/g,/مرغ روسٹ/g,/مرغ بروسٹ/g,/مرغ برگر/g,/بیف برگر/g,/زنگر برگر/g,/مرغ شوارما/g,/مرغ رول/g,/پراٹھا رول/g,/فرینچ فرائز/g,/لوڈڈ فرائز/g,/چیز پیزا/g,/مرغ پیزا/g,/فجیتا پیزا/g,/تکہ پیزا/g,/بی بی کیو پیزا/g,/پیپرونی پیزا/g,/گول گپے/g,/منرل واٹر/g,/کوکا کولا/g,/تازہ لیمونیڈ/g,/مینگو سموتھی/g,/کولڈ ڈرنک/g,/کڑک چائے/g,/سبز چائے/g,/گارلک نان/g,/چیز نان/g,/مرغ ونگز/g,/مرغ/g])t=t.replace(e,``);return t=t.replace(/[\u0679\u067E\u0686\u0698\u06AF\u06BA\u06BE\u06C1\u06D2]/g,``),t.replace(/\s+/g,` `).trim()}function d(e){return e?u(e).replace(/[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]+/g,``).replace(/\s*-\s*$/,``).replace(/^\s*-\s*/,``).replace(/\s*-\s*-+/g,`-`).replace(/\(\s*\)/g,``).replace(/\[\s*\]/g,``).replace(/\s+/g,` `).trim()||e.trim():``}function f(e,t=!0){if(!e)return``;let n=u(e);return t?n:d(n)}var p=(e,t=!0)=>f(e,t),m=n();function h({order:e,onClose:t,onEdit:n,allowPrint:u=!0}){let{user:d}=i(),f=d?.role?.trim().toLowerCase()===`management`,[h,g]=(0,l.useState)(!1),[_,v]=(0,l.useState)(!1);if(!e)return null;let y=new Date(e.created_at),b=e.order_type||(e.customer_address?.startsWith(`Table `)?`Dine-In`:e.customer_address===`Takeaway`?`Takeaway`:e.customer_address===`Dine-In`?`Dine-In`:`Delivery`),x=e.table_number||(e.customer_address?.startsWith(`Table `)?e.customer_address.replace(`Table `,``):``),S=e.order_taker||`Guest`,C=e.completed_by||(e.status===`Completed`?S:null),w=e.comments||``,T=[];b===`Dine-In`&&x&&T.push(`Table ${String(x).replace(/^Table\s*/i,``)}`),S&&T.push(`Placed: ${S}`),C&&T.push(`Completed: ${C}`),w&&T.push(`Note: ${w}`);let E=T.length>0?`<div style="font-size: 11px; font-weight: bold; margin: 2px 0; text-align: center;">${T.join(` | `)}</div>`:``,D=[];if(Array.isArray(e.edit_history))D=e.edit_history;else if(typeof e.edit_history==`string`)try{D=JSON.parse(e.edit_history)}catch{D=[]}let O=D.length>0?D[D.length-1]:null,k=(e.edit_reason||O?.reason||``).trim(),A=[],j=(e.items||[]).map(e=>({name:e.item_name||e.name,qty:e.qty,price:parseFloat(e.unit_price||e.price||0),isNew:!1,isCancelled:!1})),M=new Set,N=[];D.forEach(e=>{Array.isArray(e.changes)&&e.changes.forEach(e=>{if(e.type===`added`||e.type===`increased`)M.add((e.name||``).trim().toLowerCase());else if(e.type===`removed`||e.type===`decreased`){let t=e.qty||e.diffQty||0;t>0&&N.push({name:e.name,qty:t,price:parseFloat(e.unit_price||e.price||0),isCancelled:!0,isNew:!1})}})}),j.forEach(t=>{M.has((t.name||``).trim().toLowerCase())&&(e.edit_count>0||D.length>0)&&(t.isNew=!0),A.push(t)}),N.forEach(e=>{A.push(e)});let P=``,F=1;A.forEach(e=>{let t=parseFloat(e.price||e.unit_price||0),n=e.qty||1,i=t*n,a=t%1==0?t:t.toFixed(2),o=n>1?`${n} (${a})`:`${n}`,s=p(e.name||e.item_name);e.isCancelled?P+=`
        <div style="padding: 2px 0; text-decoration: line-through; color: #dc2626; opacity: 0.85;">
          <div style="font-size: 12px; word-break: break-word;">${F++}. ${s} <span style="font-size: 9px; font-weight: bold; background: #fee2e2; color: #991b1b; padding: 1px 4px; border-radius: 3px; text-decoration: none; display: inline-block;">[CANCELLED]</span></div>
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 600; padding-top: 1px; color: #000;">
            <span style="flex: 1.5;"></span>
            <span style="flex: 1; text-align: center;">${o}</span>
            <span style="flex: 1; text-align: right;">${r}${i.toFixed(2)}</span>
          </div>
        </div>
      `:e.isNew?P+=`
        <div style="padding: 2px 0;">
          <div style="font-size: 12.5px; font-weight: 700; word-break: break-word; color: #000;">${F++}. ${s} <span style="font-size: 9px; font-weight: bold; color: #15803d; background: #dcfce7; padding: 1px 4px; border-radius: 3px; display: inline-block;">+NEW</span></div>
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 600; padding-top: 1px; color: #000;">
            <span style="flex: 1.5;"></span>
            <span style="flex: 1; text-align: center; font-weight: bold;">${o}</span>
            <span style="flex: 1; text-align: right;">${r}${i.toFixed(2)}</span>
          </div>
        </div>
      `:P+=`
        <div style="padding: 2px 0;">
          <div style="font-size: 12.5px; font-weight: 700; word-break: break-word; color: #000;">${F++}. ${s}</div>
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 600; padding-top: 1px; color: #000;">
            <span style="flex: 1.5;"></span>
            <span style="flex: 1; text-align: center; font-weight: bold;">${o}</span>
            <span style="flex: 1; text-align: right;">${r}${i.toFixed(2)}</span>
          </div>
        </div>
      `});let I=e.branch||`Branch 1`,L=I;I===`Branch 1`?L=`B1`:I===`Branch 2`?L=`B2`:I===`Branch 3`&&(L=`B3`);let R=e.payment_method===`Credit`||parseFloat(e.payment_received||0)>0||e.credit_payments&&e.credit_payments.length>0,z=parseFloat(e.payment_received||0),B=e.remaining_due===void 0?Math.max(0,parseFloat(e.grand_total||0)-z):parseFloat(e.remaining_due),V=R?`
<div class="divider"></div>
${z>0?`
<div class="total-row" style="font-weight: 700; color: #15803d; font-size: 13px;">
  <span>Payment Received:</span>
  <span>${r}${z.toFixed(2)}</span>
</div>
`:``}
<div class="total-row" style="font-weight: 800; color: ${B>0?`#dc2626`:`#15803d`}; font-size: 13px;">
  <span>Remaining Due Amount:</span>
  <span>${r}${B.toFixed(2)}</span>
</div>
${Array.isArray(e.credit_payments)&&e.credit_payments.length>1?`
  <div style="font-size: 10.5px; color: #475569; margin-top: 3px; padding-left: 4px;">
    ${e.credit_payments.map((e,t)=>`
      <div style="display: flex; justify-content: space-between; padding: 1px 0;">
        <span>• Pmt #${t+1} (${e.payment_method||`Cash`} - ${new Date(e.created_at).toLocaleDateString()}):</span>
        <span>${r}${parseFloat(e.amount).toFixed(2)}</span>
      </div>
    `).join(``)}
  </div>
`:``}
`:``,H=`
<div class="center">
  <div style="font-size: 14px; font-weight: 900; margin: 2px 0;">
    ${L} - ${b}
  </div>
    <div style="font-size: 11px; text-align: center; margin: 3px 0; line-height: 1.3;">
      Kitchen slip. Please get original slip from counter.
    </div>
  ${E}
  <div style="margin: 2px 0; font-size: 14px; font-weight: 900;">
    Order #${e.id} - ${e.edit_count>0?`Edit ${e.slip_number||`-`}${String.fromCharCode(64+e.edit_count)}`:e.slip_number||`-`}
  </div>
  ${k?`<div style="font-size: 11px; font-weight: bold; margin: 2px 0; color: #1e3a8a; background: #f0fdf4; padding: 2px 4px; border-radius: 3px;">Edit Reason: ${k}</div>`:``}
  <p class="sub" style="margin-bottom: 2px; font-size: 10px;">${y.toLocaleDateString()} ${y.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`,second:`2-digit`,hour12:!1})}</p>
</div>
<div class="divider"></div>
<div class="row" style="font-weight: bold; font-size: 12px;">
  <span style="flex: 1.5;">Item</span>
  <span style="flex: 1; text-align: center;">QTY</span>
  <span style="flex: 1; text-align: right;">Amount</span>
</div>
<div class="divider"></div>
${P}
<div class="divider"></div>
<div class="total-row"><span>Active Items</span><span>${(e.items||[]).reduce((e,t)=>e+t.qty,0)}</span></div>
<div class="total-row"><span>Subtotal</span><span>${r}${parseFloat(e.subtotal).toFixed(2)}</span></div>
${parseFloat(e.discount||0)>0?`<div class="total-row"><span>Discount</span><span>-${r}${parseFloat(e.discount).toFixed(2)}</span></div>`:``}
<div class="total-row grand"><span>TOTAL</span><span>${r}${parseFloat(e.grand_total).toFixed(2)}</span></div>
<div class="total-row"><span>Payment</span><span>${e.status===`Hold`?`Hold (Pending)`:e.payment_method?e.payment_method+` - `+e.status:e.status}</span></div>
${V}
  `,U=`<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <title>Kitchen Slip</title>
  <style>
    @page { size: 80mm auto; margin: 0; }
    * { 
      box-sizing: border-box; 
      margin: 0; 
      padding: 0; 
      -webkit-print-color-adjust: exact !important; 
      print-color-adjust: exact !important; 
    }
    html { margin: 0; padding: 0; background: #fff; }
    body {
      width: 100%;
      font-weight: 600;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Tahoma, Arial, sans-serif;
      font-size: 12.5px;
      color: #000;
      background: #fff;
      padding: 0 25px 0 5px; /* Added 20px to the right as requested */
      margin: 0;
      line-height: 1.35;
      text-rendering: geometricPrecision;
    }
    .center { text-align: center; }
    h2 { font-size: 14px; font-weight: 700; margin-bottom: 4px; color: #000; }
    .sub { font-size: 11px; font-weight: 600; color: #000; margin-bottom: 2px; }
    .divider {
      border-top: 1.5px dashed #000;
      margin: 5px 0;
    }
    .row {
      display: flex;
      justify-content: space-between;
      padding: 2.5px 0;
      font-size: 12.5px;
      font-weight: 600;
      color: #000;
    }
    .item-name {
      flex: 2;
      margin-right: 2px;
      word-break: break-word;
      font-weight: 700;
      color: #000;
    }
    .item-qty {
      width: 30px;
      text-align: center;
      margin-right: 2px;
      font-weight: 700;
      color: #000;
    }
    .item-price { 
      flex: 1.2;
      text-align: right; 
      white-space: nowrap; 
      overflow: hidden;
      font-weight: 700;
      color: #000;
    }
    .total-row {
      display: flex;
      justify-content: space-between;
      padding: 2.5px 0;
      font-size: 12.5px;
      font-weight: 600;
      color: #000;
    }
    .grand {
      font-size: 16px;
      font-weight: 800;
      border-top: 1.5px solid #000;
      border-bottom: 1.5px solid #000;
      padding: 4px 0;
      margin: 4px 0;
      color: #000;
    }
    .footer { margin-top: 4px; margin-bottom: 0; font-size: 11px; font-weight: 600; color: #000; }
    .dotted { border-top: 1.5px dotted #000; margin: 4px 0; }
  </style>
</head>
<body>
${H}
</body>
</html>`;return(0,m.jsxs)(`div`,{className:`modal-overlay`,onClick:e=>{e.target.classList.contains(`modal-overlay`)&&t()},children:[(0,m.jsxs)(`div`,{className:`modal`,style:{maxWidth:400,padding:0,overflow:`hidden`,display:`flex`,flexDirection:`column`,maxHeight:`85vh`,boxSizing:`border-box`},children:[(0,m.jsxs)(`div`,{style:{padding:`16px 20px`,borderBottom:`1px solid var(--surface-2)`,display:`flex`,justifyContent:`space-between`,alignItems:`center`,background:`white`,flexShrink:0},children:[(0,m.jsx)(`h3`,{style:{margin:0,fontSize:16},children:`Order Details`}),(0,m.jsx)(`button`,{onClick:t,style:{background:`transparent`,border:`none`,cursor:`pointer`,color:`#666`},children:(0,m.jsx)(s,{size:20})})]}),(0,m.jsxs)(`div`,{style:{padding:20,overflowY:`auto`,background:`#fcfcfc`,flex:1},children:[e.status===`Cancelled`&&e.cancel_reason&&(0,m.jsxs)(`div`,{style:{background:`#fef2f2`,border:`1px solid #fecaca`,padding:`12px`,borderRadius:`8px`,marginBottom:`16px`,color:`#991b1b`,fontSize:`14px`},children:[(0,m.jsxs)(`div`,{style:{fontWeight:800,marginBottom:`4px`,display:`flex`,alignItems:`center`,gap:`6px`},children:[(0,m.jsx)(`span`,{style:{fontSize:`16px`},children:`⚠️`}),` Order Cancelled`]}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`strong`,{children:`Reason:`}),` `,e.cancel_reason]})]}),(e.is_edited||k||D.length>0)&&(0,m.jsxs)(`div`,{style:{background:`#eff6ff`,border:`1px solid #bfdbfe`,padding:`12px 14px`,borderRadius:`8px`,marginBottom:`16px`,color:`#1e40af`,fontSize:`13px`},children:[(0,m.jsxs)(`div`,{style:{fontWeight:800,marginBottom:`4px`,display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,m.jsxs)(`span`,{style:{display:`flex`,alignItems:`center`,gap:`6px`},children:[(0,m.jsx)(`span`,{style:{fontSize:`16px`},children:`✏️`}),` Order Edited `,e.edit_count>0?`(${e.edit_count}x)`:``]}),O?.edited_by&&(0,m.jsxs)(`span`,{style:{fontSize:`11px`,fontWeight:600,color:`#2563eb`},children:[`By: `,O.edited_by]})]}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`strong`,{children:`Reason:`}),` `,k||`Order items updated`]}),D.length>1&&(0,m.jsxs)(`details`,{style:{marginTop:8,fontSize:`12px`,color:`#334155`,cursor:`pointer`},children:[(0,m.jsxs)(`summary`,{style:{fontWeight:600,outline:`none`},children:[`View full edit history (`,D.length,` edits)`]}),(0,m.jsx)(`div`,{style:{marginTop:6,display:`flex`,flexDirection:`column`,gap:6},children:D.map((e,t)=>(0,m.jsxs)(`div`,{style:{background:`white`,padding:`6px 8px`,borderRadius:4,border:`1px solid #e2e8f0`,fontSize:11},children:[(0,m.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontWeight:600},children:[(0,m.jsxs)(`span`,{children:[`Edit #`,t+1,` by `,e.edited_by||`Staff`]}),(0,m.jsx)(`span`,{style:{color:`#64748b`},children:new Date(e.timestamp).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})})]}),e.reason&&(0,m.jsxs)(`div`,{style:{color:`#1e293b`,marginTop:2},children:[`Reason: `,e.reason]})]},t))})]})]}),(0,m.jsxs)(`div`,{style:{background:`white`,padding:`10px 10px 6px 15px`,boxShadow:`0 4px 12px rgba(0,0,0,0.05)`,fontFamily:`Tahoma, Geneva, sans-serif`,color:`#000`,fontSize:12,width:`80mm`,margin:`0 auto`,boxSizing:`border-box`},children:[(0,m.jsx)(`style`,{children:`
                .preview-slip * { box-sizing: border-box; margin: 0; padding: 0; font-weight: bold; }
                .preview-slip .center { text-align: center; }
                .preview-slip .divider { border-top: 1.5px dashed #000;
      margin: 5px 0; }
                .preview-slip .row { display: flex; justify-content: space-between; padding: 2px 0; font-size: 12px; }
                .preview-slip .item-name { flex: 2; margin-right: 2px; word-break: break-word; }
                .preview-slip .item-qty { width: 30px; text-align: center; margin-right: 2px; }
                .preview-slip .item-price { flex: 1.2; text-align: right; white-space: nowrap; overflow: hidden; }
                .preview-slip .total-row { display: flex; justify-content: space-between; padding: 2px 0; }
                .preview-slip .grand { font-size: 16px; font-weight: bold; border-top: 2px solid #000; border-bottom: 2px solid #000; padding: 4px 0; margin: 4px 0; }
              `}),(0,m.jsx)(`div`,{className:`preview-slip`,dangerouslySetInnerHTML:{__html:H}})]})]}),(0,m.jsxs)(`div`,{style:{padding:`16px 20px`,borderTop:`1px solid var(--surface-2)`,display:`flex`,gap:10,background:`white`,flexShrink:0,alignItems:`center`},children:[(0,m.jsx)(`button`,{className:`btn btn-secondary`,onClick:t,style:{padding:`10px`,display:`flex`,alignItems:`center`,justifyContent:`center`},title:`Close`,children:(0,m.jsx)(s,{size:20})}),n&&(0,m.jsxs)(`button`,{className:`btn btn-secondary`,disabled:f,onClick:()=>{f||n(e.id)},style:{flex:1,display:`flex`,alignItems:`center`,justifyContent:`center`,gap:8,cursor:f?`not-allowed`:`pointer`,opacity:f?.6:1},children:[(0,m.jsx)(c,{size:18}),` Edit`]}),u&&(0,m.jsxs)(`button`,{className:`btn btn-primary`,onClick:async()=>{if(h)return;g(!0);try{if((localStorage.getItem(`printMode`)||`standard`)===`cloud`){let n=localStorage.getItem(`printerIp`)||`127.0.0.1`;await a.post(`/api/orders/${e.id}/reprint`,{printerIp:n}),v(!0),setTimeout(()=>{v(!1),g(!1),t()},1500);return}}catch(e){console.error(`Failed to check or trigger cloud reprint:`,e)}let n=document.createElement(`iframe`);n.style.display=`none`,document.body.appendChild(n),n.contentDocument.write(U),n.contentDocument.close(),setTimeout(()=>{n.contentWindow.focus(),n.contentWindow.print(),setTimeout(()=>{document.body.removeChild(n),g(!1),t()},1e3)},500)},disabled:h,style:{flex:n?1:2,display:`flex`,alignItems:`center`,justifyContent:`center`,gap:8},children:[(0,m.jsx)(o,{size:18}),` `,h?`Printing...`:n?`Print`:`Print Receipt`]})]})]}),_&&(0,m.jsx)(`div`,{className:`modal-overlay`,style:{zIndex:999999,display:`flex`,alignItems:`center`,justifyContent:`center`},children:(0,m.jsxs)(`div`,{className:`modal`,style:{maxWidth:350,textAlign:`center`,padding:`40px 20px`,borderRadius:`16px`},children:[(0,m.jsx)(`div`,{style:{width:80,height:80,background:`#10b981`,borderRadius:`50%`,color:`white`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:40,margin:`0 auto 20px auto`},children:`✓`}),(0,m.jsx)(`h2`,{style:{margin:`0 0 10px 0`,fontSize:22,color:`#333`},children:`Successfully sent`}),(0,m.jsx)(`p`,{style:{margin:0,fontSize:15,color:`#666`},children:`Slip sent to kitchen`})]})})]})}export{p as n,h as t};