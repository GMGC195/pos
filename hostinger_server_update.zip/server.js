require('dotenv').config();
process.env.TZ = 'Asia/Riyadh'; // Set timezone to Saudi Arabia

const express = require('express');
const cors = require('cors');

// Handle unexpected errors (like Neon DB ECONNRESET on idle clients) to prevent app crash
process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection:', reason);
});

const pool = require('./db');
const { initCron } = require('./cron/expiryCheck');

// Database initialization (reloaded)
const runWithStartupRetry = async (fn, maxRetries = 3) => {
  for (let i = 0; i < maxRetries; i++) {
    try {
      await fn();
      return;
    } catch (err) {
      const isTransient = err.message?.includes('Connection terminated') ||
                          err.message?.includes('timeout') ||
                          err.code === 'ECONNRESET';
      if (isTransient && i < maxRetries - 1) {
        const delay = 2000 * (i + 1);
        console.warn(`⚠️ Database schema verification warning: ${err.message} — retrying in ${delay/1000}s...`);
        await new Promise(r => setTimeout(r, delay));
      } else {
        console.warn('⚠️ Database schema verification warning:', err.message);
        return;
      }
    }
  }
};

(async () => {
  await runWithStartupRetry(async () => {
  try {
    // Make timezone permanent for the DB user (fixes Hostinger / Neon pooling timezone drops)
    try {
      await pool.query("ALTER ROLE current_user SET timezone TO 'Asia/Riyadh'");
    } catch (tzErr) {
      // Non-fatal if DB user lacks ALTER ROLE permission
    }
    
    const safeStartupQueries = [
      'ALTER TABLE orders ADD COLUMN IF NOT EXISTS client_order_id UUID UNIQUE',
      'ALTER TABLE orders ADD COLUMN IF NOT EXISTS shift_id INTEGER',
      'ALTER TABLE orders ADD COLUMN IF NOT EXISTS edit_count INTEGER DEFAULT 0',
      'ALTER TABLE orders ADD COLUMN IF NOT EXISTS edit_reason TEXT',
      "ALTER TABLE orders ADD COLUMN IF NOT EXISTS edit_history JSONB DEFAULT '[]'::jsonb",
      'ALTER TABLE orders ADD COLUMN IF NOT EXISTS completed_by VARCHAR(150)',
      'ALTER TABLE orders ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ',
      `CREATE TABLE IF NOT EXISTS employee_documents (
        id SERIAL PRIMARY KEY,
        employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE,
        document_name VARCHAR(255) NOT NULL,
        document_type VARCHAR(50),
        document_number VARCHAR(100),
        note TEXT,
        file_url TEXT,
        file_path TEXT,
        expiry_date DATE,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )`,
      'ALTER TABLE employee_documents ADD COLUMN IF NOT EXISTS document_type VARCHAR(50)',
      'ALTER TABLE employee_documents ADD COLUMN IF NOT EXISTS document_number VARCHAR(100)',
      'ALTER TABLE employee_documents ADD COLUMN IF NOT EXISTS note TEXT',
      'ALTER TABLE employee_documents ADD COLUMN IF NOT EXISTS file_path TEXT',
      'ALTER TABLE employee_documents ADD COLUMN IF NOT EXISTS expiry_date DATE',
      'ALTER TABLE shift_closings ADD COLUMN IF NOT EXISTS closing_card NUMERIC(10, 2) DEFAULT 0',
      'ALTER TABLE shift_closings ADD COLUMN IF NOT EXISTS card_difference NUMERIC(10, 2) DEFAULT 0',
      'ALTER TABLE shift_closings ADD COLUMN IF NOT EXISTS cash_difference NUMERIC(10, 2) DEFAULT 0',
      `CREATE TABLE IF NOT EXISTS discount_packages (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        discount_percentage NUMERIC(5,2) NOT NULL DEFAULT 0,
        discount_rules JSONB DEFAULT '[]'::jsonb,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )`,
      "ALTER TABLE discount_packages ADD COLUMN IF NOT EXISTS discount_rules JSONB DEFAULT '[]'::jsonb",
      "ALTER TABLE credit_customers ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'Active'",
      "ALTER TABLE credit_customers ADD COLUMN IF NOT EXISTS category VARCHAR(30) DEFAULT 'Regular Customer'",
      "ALTER TABLE credit_customers ADD COLUMN IF NOT EXISTS company_name VARCHAR(150)",
      "ALTER TABLE credit_customers ADD COLUMN IF NOT EXISTS is_extra_pay BOOLEAN DEFAULT FALSE",
      "ALTER TABLE credit_customers ADD COLUMN IF NOT EXISTS discount_package_id INTEGER REFERENCES discount_packages(id) ON DELETE SET NULL",
      "ALTER TABLE credit_customers ADD COLUMN IF NOT EXISTS employee_id INTEGER REFERENCES employees(id) ON DELETE SET NULL",
      "CREATE INDEX IF NOT EXISTS idx_credit_customers_employee_id ON credit_customers(employee_id)",
      "CREATE INDEX IF NOT EXISTS idx_credit_customers_discount_package_id ON credit_customers(discount_package_id)",
      "ALTER TABLE credit_transactions ADD COLUMN IF NOT EXISTS billing_month VARCHAR(7)",
      "ALTER TABLE credit_transactions ADD COLUMN IF NOT EXISTS comments TEXT",
      "ALTER TABLE credit_transactions ADD COLUMN IF NOT EXISTS classification VARCHAR(50) DEFAULT 'Regular'",
      "CREATE INDEX IF NOT EXISTS idx_credit_transactions_customer_id ON credit_transactions(credit_customer_id)",
      "CREATE INDEX IF NOT EXISTS idx_credit_transactions_billing_month ON credit_transactions(billing_month)"
    ];

    for (const sq of safeStartupQueries) {
      try {
        await pool.query(sq);
      } catch (sqErr) {
        console.warn('Startup query notice:', sqErr.message);
      }
    }

    await pool.query(`
      CREATE TABLE IF NOT EXISTS notifications (
        id SERIAL PRIMARY KEY,
        message TEXT,
        type VARCHAR(50),
        target_roles JSONB DEFAULT '[]'::jsonb,
        target_users JSONB DEFAULT '[]'::jsonb,
        is_read BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    await pool.query("ALTER TABLE notifications ADD COLUMN IF NOT EXISTS target_users JSONB DEFAULT '[]'::jsonb");
    await pool.query("ALTER TABLE notifications ADD COLUMN IF NOT EXISTS target_roles JSONB DEFAULT '[]'::jsonb");
    
    // Ensure settings table and report_emails column exist
    await pool.query(`
      CREATE TABLE IF NOT EXISTS settings (
        id SERIAL PRIMARY KEY,
        auto_print_enabled BOOLEAN DEFAULT FALSE,
        printer_ip VARCHAR(50) DEFAULT '127.0.0.1',
        low_stock_behavior VARCHAR(50) DEFAULT 'block',
        report_emails JSONB DEFAULT '["mr.caffee25@gmail.com"]'::jsonb
      )
    `);
    await pool.query('ALTER TABLE settings ADD COLUMN IF NOT EXISTS low_stock_behavior VARCHAR(50) DEFAULT \'block\'');
    await pool.query('ALTER TABLE settings ADD COLUMN IF NOT EXISTS report_emails JSONB DEFAULT \'["mr.caffee25@gmail.com"]\'::jsonb');
    
    // Create cashier_shifts table for explicit shift tracking
    await pool.query(`
      CREATE TABLE IF NOT EXISTS cashier_shifts (
        id SERIAL PRIMARY KEY,
        cashier_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        cashier_name VARCHAR(100) NOT NULL,
        branch VARCHAR(100) NOT NULL,
        start_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        end_time TIMESTAMPTZ,
        opening_cash NUMERIC(10, 2) DEFAULT 0,
        status VARCHAR(20) DEFAULT 'Open',
        closing_cash NUMERIC(10, 2) DEFAULT 0,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    await pool.query('ALTER TABLE cashier_shifts ADD COLUMN IF NOT EXISTS closing_cash NUMERIC(10, 2) DEFAULT 0');
    await pool.query('ALTER TABLE credit_customers ADD COLUMN IF NOT EXISTS branch VARCHAR(100)');
    await pool.query('ALTER TABLE credit_transactions ADD COLUMN IF NOT EXISTS is_shift_closed BOOLEAN DEFAULT FALSE, ADD COLUMN IF NOT EXISTS is_daily_closed BOOLEAN DEFAULT FALSE, ADD COLUMN IF NOT EXISTS branch VARCHAR(100), ADD COLUMN IF NOT EXISTS cashier_name VARCHAR(100), ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50)');
    // Ensure all historical payments created before today are closed so only today's/active payments appear
    await pool.query(`
      UPDATE credit_transactions 
      SET is_shift_closed = TRUE, is_daily_closed = TRUE 
      WHERE type = 'PAYMENT' AND (id < 113 OR created_at < CURRENT_DATE)
    `);
    await pool.query(`
      UPDATE credit_transactions 
      SET branch = COALESCE(branch, 'Branch 1')
      WHERE branch IS NULL
    `);

    // Update shift_closings for credit reporting, closing cash, opening cash, interval items, difference tracking, and shifts breakdown
    try {
      await pool.query('ALTER TABLE shift_closings ADD COLUMN IF NOT EXISTS credit_sales DECIMAL(10,2) DEFAULT 0, ADD COLUMN IF NOT EXISTS major_payments DECIMAL(10,2) DEFAULT 0, ADD COLUMN IF NOT EXISTS closing_cash NUMERIC(10, 2) DEFAULT 0, ADD COLUMN IF NOT EXISTS opening_cash NUMERIC(10, 2) DEFAULT 0, ADD COLUMN IF NOT EXISTS interval_items TEXT, ADD COLUMN IF NOT EXISTS difference NUMERIC(10, 2) DEFAULT 0, ADD COLUMN IF NOT EXISTS difference_reason TEXT, ADD COLUMN IF NOT EXISTS shifts_summary JSONB');
      // Backfill opening_cash from cashier_shifts where available
      await pool.query(`
        UPDATE shift_closings sc
        SET opening_cash = COALESCE(cs.opening_cash, 0)
        FROM cashier_shifts cs
        WHERE sc.cashier_name = cs.cashier_name 
          AND sc.branch = cs.branch 
          AND cs.start_time <= sc.logout_time
          AND (sc.opening_cash IS NULL OR sc.opening_cash = 0)
      `);
      // Backfill closing_cash from cashier_shifts where available
      await pool.query(`
        UPDATE shift_closings sc
        SET closing_cash = COALESCE(cs.closing_cash, 0)
        FROM cashier_shifts cs
        WHERE sc.cashier_name = cs.cashier_name 
          AND sc.branch = cs.branch 
          AND cs.start_time <= sc.logout_time
          AND (sc.closing_cash IS NULL OR sc.closing_cash = 0)
          AND cs.closing_cash > 0
      `);
    } catch (e) {
      console.warn('Could not alter or backfill shift_closings:', e.message);
    }
    
    // Create employees table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS employees (
        id SERIAL PRIMARY KEY,
        name VARCHAR(150) NOT NULL,
        role VARCHAR(50),
        salary NUMERIC(10, 2) DEFAULT 0,
        status VARCHAR(20) DEFAULT 'Active',
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Drop email and phone columns if they exist
    await pool.query('ALTER TABLE employees DROP COLUMN IF EXISTS email CASCADE');
    await pool.query('ALTER TABLE employees DROP COLUMN IF EXISTS phone CASCADE');
    
    // Rename shift column to working_hours if it exists
    try {
      await pool.query('ALTER TABLE employees RENAME COLUMN shift TO working_hours');
    } catch (e) {}

    // Add working_hours column if not exists (in case it didn't exist before)
    await pool.query(`
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS working_hours VARCHAR(20) DEFAULT 'R1'
    `);
    
    // Add shift_hours column if not exists
    await pool.query(`
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS shift_hours NUMERIC(4, 2) DEFAULT 12.0
    `);

    // Add branch column
    await pool.query(`
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS branch VARCHAR(100)
    `);

    // Add new shift column
    await pool.query(`
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS shift VARCHAR(50) DEFAULT 'Day'
    `);

    // Add strict_attendance column
    await pool.query(`
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS strict_attendance BOOLEAN DEFAULT false
    `);

    // Add custom deduction columns
    await pool.query(`
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS custom_deduction_active BOOLEAN DEFAULT false
    `);
    
    await pool.query(`
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS custom_deduction_rules JSONB DEFAULT '[]'::jsonb
    `);

    // Rename employee_shifts to employee_working_hours if it exists
    try {
      await pool.query('ALTER TABLE employee_shifts RENAME TO employee_working_hours');
    } catch (e) {}

    // Create employee_working_hours config table if not exists
    await pool.query(`
      CREATE TABLE IF NOT EXISTS employee_working_hours (
        id SERIAL PRIMARY KEY,
        name VARCHAR(50) UNIQUE NOT NULL,
        start_time VARCHAR(20) NOT NULL DEFAULT '10:00',
        end_time VARCHAR(20) NOT NULL DEFAULT '23:00',
        hours NUMERIC(4, 2) NOT NULL DEFAULT 13.0,
        is_split_shift BOOLEAN DEFAULT false,
        start_time_2 VARCHAR(20),
        end_time_2 VARCHAR(20)
      )
    `);

    // Ensure new split shift columns exist on employee_working_hours
    try {
      await pool.query('ALTER TABLE employee_working_hours ADD COLUMN is_split_shift BOOLEAN DEFAULT false');
      await pool.query('ALTER TABLE employee_working_hours ADD COLUMN start_time_2 VARCHAR(20)');
      await pool.query('ALTER TABLE employee_working_hours ADD COLUMN end_time_2 VARCHAR(20)');
    } catch (e) {
      // Columns likely already exist
    }

    // NOTE: No default seed for working hours - entries are created per employee only
    // Cleanup: remove working hour records that don't match any real employee (e.g. R1, R2, R3 legacy seeds)
    try {
      await pool.query(`
        DELETE FROM employee_working_hours wh
        WHERE NOT EXISTS (
          SELECT 1 FROM employees e WHERE LOWER(e.name) = LOWER(wh.name)
        )
      `);
    } catch (e) {
      console.log('Cleanup skipped:', e.message);
    }

    // Convert existing shifts to 24-hour format
    const shiftsRes = await pool.query('SELECT id, start_time, end_time FROM employee_working_hours');
    for (const row of shiftsRes.rows) {
      const convertTo24 = (timeStr) => {
        if (!timeStr) return timeStr;
        const match = timeStr.match(/^(\d+):(\d+)\s*(AM|PM)$/i);
        if (match) {
          let hrs = parseInt(match[1], 10);
          const mins = parseInt(match[2], 10);
          const ampm = match[3].toUpperCase();
          if (ampm === 'PM' && hrs < 12) hrs += 12;
          if (ampm === 'AM' && hrs === 12) hrs = 0;
          return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
        }
        return timeStr;
      };
      const newStart = convertTo24(row.start_time);
      const newEnd = convertTo24(row.end_time);
      if (newStart !== row.start_time || newEnd !== row.end_time) {
        await pool.query('UPDATE employee_working_hours SET start_time = $1, end_time = $2 WHERE id = $3', [newStart, newEnd, row.id]);
        console.log(`Migrated shift ${row.id} time to 24h format.`);
      }
    }

    // Add employee_id column if not exists
    await pool.query(`
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS employee_id VARCHAR(50) UNIQUE
    `);

    // Add department column if not exists
    await pool.query(`
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS department VARCHAR(100)
    `);

    // Add position column if not exists
    await pool.query(`
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS position VARCHAR(100)
    `);

    // Backfill existing employees without an employee_id
    await pool.query(`
      UPDATE employees SET employee_id = 'EMP-' || LPAD(id::text, 4, '0') WHERE employee_id IS NULL
    `);
    
    // Create employee_attendance table if not exists
    await pool.query(`
      CREATE TABLE IF NOT EXISTS employee_attendance (
        id SERIAL PRIMARY KEY,
        employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE,
        check_in TIMESTAMPTZ,
        check_out TIMESTAMPTZ,
        status VARCHAR(50) DEFAULT 'Present',
        notes TEXT,
        is_paid BOOLEAN DEFAULT true,
        date DATE DEFAULT CURRENT_DATE,
        on_break BOOLEAN DEFAULT false,
        break_start TIMESTAMPTZ,
        total_break_duration_seconds INTEGER DEFAULT 0,
        shift_name VARCHAR(50),
        shift_hours NUMERIC(4, 2),
        shift_start_time VARCHAR(20),
        shift_end_time VARCHAR(20),
        is_split_shift BOOLEAN DEFAULT false,
        shift_start_time_2 VARCHAR(20),
        shift_end_time_2 VARCHAR(20),
        created_by VARCHAR(100),
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Ensure new split shift columns exist on employee_attendance
    try {
      await pool.query('ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS is_split_shift BOOLEAN DEFAULT false');
      await pool.query('ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS shift_start_time_2 VARCHAR(20)');
      await pool.query('ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS shift_end_time_2 VARCHAR(20)');
      await pool.query("ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS break_logs JSONB DEFAULT '[]'::jsonb");
      // Add edit_count for orders
      await pool.query('ALTER TABLE orders ADD COLUMN IF NOT EXISTS edit_count INTEGER DEFAULT 0');
    } catch (e) {
      // Columns likely already exist
    }

    // Create edited_attendance table for audit logging
    await pool.query(`
      CREATE TABLE IF NOT EXISTS edited_attendance (
        id SERIAL PRIMARY KEY,
        attendance_id INTEGER REFERENCES employee_attendance(id) ON DELETE CASCADE,
        employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE,
        original_check_in TIMESTAMPTZ,
        original_check_out TIMESTAMPTZ,
        new_check_in TIMESTAMPTZ,
        new_check_out TIMESTAMPTZ,
        edited_by VARCHAR(150),
        reason TEXT,
        edited_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Create attendance_edit_requests table for employee requested changes
    await pool.query(`
      CREATE TABLE IF NOT EXISTS attendance_edit_requests (
        id SERIAL PRIMARY KEY,
        attendance_id INTEGER REFERENCES employee_attendance(id) ON DELETE CASCADE,
        employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE,
        requested_by_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        target_role VARCHAR(20) NOT NULL,
        requested_check_in TIMESTAMPTZ,
        requested_check_out TIMESTAMPTZ,
        reason TEXT,
        status VARCHAR(20) DEFAULT 'Pending',
        created_at TIMESTAMPTZ DEFAULT NOW(),
        request_type VARCHAR(20) DEFAULT 'Edit'
      )
    `);
    
    // Ensure request_type column exists if table was already created
    await pool.query('ALTER TABLE attendance_edit_requests ADD COLUMN IF NOT EXISTS request_type VARCHAR(20) DEFAULT \'Edit\'');

    // Ensure employee_attendance has remarks column
    await pool.query('ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS remarks TEXT');
    await pool.query('ALTER TABLE employee_attendance ALTER COLUMN remarks TYPE TEXT');
    // Add shift tracking columns
    await pool.query('ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS shift_name VARCHAR(50)');
    await pool.query('ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS shift_hours NUMERIC(4, 2)');
    await pool.query('ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS shift_start_time VARCHAR(20)');
    await pool.query('ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS shift_end_time VARCHAR(20)');

    // Migrate existing records: fetch employee's current shift details and populate historical attendance
    await pool.query(`
      UPDATE employee_attendance ea
      SET 
        shift_name = e.working_hours,
        shift_hours = COALESCE(e.shift_hours, 12.0),
        shift_start_time = es.start_time,
        shift_end_time = es.end_time
      FROM employees e
      LEFT JOIN employee_working_hours es ON e.working_hours = es.name
      WHERE ea.employee_id = e.id AND ea.shift_name IS NULL
    `);
    // Ensure employee_attendance has created_by and branch column
    await pool.query('ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS created_by VARCHAR(150)');
    await pool.query('ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS branch VARCHAR(100)');
    try {
      await pool.query(`
        UPDATE employee_attendance ea
        SET branch = COALESCE(e.branch, 'Branch 1')
        FROM employees e
        WHERE ea.employee_id = e.id AND (ea.branch IS NULL OR ea.branch = '')
      `);
    } catch (e) {}

    // Ensure users has shift and branch column
    await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS shift VARCHAR(50)');
    await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS branch VARCHAR(100)');
    await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS employee_id INTEGER REFERENCES employees(id) ON DELETE SET NULL');
    await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN DEFAULT TRUE');

    // Migration: Auto-create user accounts for existing employees
    const employeesRes = await pool.query('SELECT * FROM employees');
    const bcrypt = require('bcrypt');
    for (const emp of employeesRes.rows) {
      const empId = emp.id;
      const employeeCode = emp.employee_id || `EMP-${String(empId).padStart(4, '0')}`;
      const userCheck = await pool.query(
        'SELECT * FROM users WHERE employee_id = $1',
        [empId]
      );
      if (userCheck.rows.length === 0) {
        let baseUsername = emp.name.toLowerCase().replace(/[^a-z0-9]/g, '');
        if (!baseUsername) {
          baseUsername = `emp${empId}`;
        }
        let username = baseUsername;
        let counter = 1;
        while (true) {
          const checkU = await pool.query('SELECT id FROM users WHERE username = $1', [username]);
          if (checkU.rows.length === 0) {
            break;
          }
          username = `${baseUsername}${counter}`;
          counter++;
        }
        const email = `${username}@alrawaq.com`;
        const passwordHash = await bcrypt.hash('user123', 10);
        await pool.query(
          `INSERT INTO users (username, email, password_hash, role, employee_id, must_change_password)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [username, email, passwordHash, 'Employee', empId, true]
        );
        console.log(`Migrated: Auto-created user account for existing employee: ${emp.name} (${username})`);
      }
    }

    // Ensure Uzair is always Developer
    await pool.query(`UPDATE users SET role = 'Developer' WHERE email = 'uzairshafqat106@gmail.com'`);

    // Create indexes
    await pool.query(`CREATE INDEX IF NOT EXISTS idx_attendance_employee ON employee_attendance(employee_id)`);
    await pool.query(`CREATE INDEX IF NOT EXISTS idx_attendance_date ON employee_attendance(date)`);

    // Ensure all stock alert columns exist
    await pool.query('ALTER TABLE stock ADD COLUMN IF NOT EXISTS low_stock_threshold NUMERIC(10,3) DEFAULT 0');
    await pool.query('ALTER TABLE stock ADD COLUMN IF NOT EXISTS low_stock_at TIMESTAMP');
    await pool.query('ALTER TABLE stock ADD COLUMN IF NOT EXISTS is_dismissed BOOLEAN DEFAULT FALSE');
    
    // Fix any historically negative stock quantities
    await pool.query('UPDATE stock SET quantity = 0 WHERE quantity < 0');
    await pool.query('UPDATE stock_history SET remaining_quantity = 0 WHERE remaining_quantity < 0');

    // Add non-negative constraints if they don't already exist
    await pool.query(`
      DO $$ BEGIN
        BEGIN ALTER TABLE stock ADD CONSTRAINT stock_quantity_non_negative CHECK (quantity >= 0);
        EXCEPTION WHEN duplicate_object THEN NULL; END;
        BEGIN ALTER TABLE stock_history ADD CONSTRAINT stock_history_remaining_non_negative CHECK (remaining_quantity >= 0);
        EXCEPTION WHEN duplicate_object THEN NULL; END;
      END $$;
    `);

    // Per-size recipe support: add size_label column and update unique constraint
    await pool.query('ALTER TABLE recipes ADD COLUMN IF NOT EXISTS size_label VARCHAR(50)');
    await pool.query(`
      DO $$ BEGIN
        -- Drop old unique constraint on (item_id, stock_id) if still exists
        BEGIN ALTER TABLE recipes DROP CONSTRAINT IF EXISTS recipes_item_id_stock_id_key;
        EXCEPTION WHEN OTHERS THEN NULL; END;
        -- Create new unique index treating NULL size_label as '' (all sizes)
        BEGIN
          CREATE UNIQUE INDEX recipes_item_stock_size_unique
          ON recipes (item_id, stock_id, COALESCE(size_label, ''));
        EXCEPTION WHEN duplicate_table THEN NULL; END;
      END $$;
    `);

    // Add payroll schema tables and column updates
    await pool.query(`
      ALTER TABLE employee_attendance ADD COLUMN IF NOT EXISTS is_paid BOOLEAN DEFAULT TRUE
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS payroll_settings (
        id SERIAL PRIMARY KEY,
        key VARCHAR(100) UNIQUE NOT NULL,
        value TEXT
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS employee_payroll_settings (
        employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE UNIQUE,
        overtime_rate NUMERIC(10, 2),
        base_salary NUMERIC(10, 2),
        allowed_leaves INTEGER
      )
    `);

    // Seed default settings
    await pool.query(`
      INSERT INTO payroll_settings (key, value)
      VALUES 
        ('global_overtime_rate', '150.00'),
        ('allowed_leaves', '2')
      ON CONFLICT (key) DO NOTHING
    `);

    // Create payroll records table to store finalized logs & manual adjustments
    await pool.query(`
      CREATE TABLE IF NOT EXISTS employee_payroll_records (
        id SERIAL PRIMARY KEY,
        employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE,
        month VARCHAR(7) NOT NULL,
        base_salary NUMERIC(10, 2) NOT NULL,
        presents INTEGER DEFAULT 0,
        absents INTEGER DEFAULT 0,
        leaves INTEGER DEFAULT 0,
        holidays INTEGER DEFAULT 0,
        overtime_hours NUMERIC(10, 2) DEFAULT 0,
        overtime_pay NUMERIC(10, 2) DEFAULT 0,
        deductions NUMERIC(10, 2) DEFAULT 0,
        other_adjustments NUMERIC(10, 2) DEFAULT 0,
        bonus NUMERIC(10, 2) DEFAULT 0,
        last_month_adjustment NUMERIC(10, 2) DEFAULT 0,
        internet NUMERIC(10, 2) DEFAULT 0,
        kafalat NUMERIC(10, 2) DEFAULT 0,
        expected_hours NUMERIC(10, 2) DEFAULT 0,
        actual_hours NUMERIC(10, 2) DEFAULT 0,
        dynamic_adjustments JSONB DEFAULT '{}'::jsonb,
        payable_salary NUMERIC(10, 2) DEFAULT 0,
        total_adjustments NUMERIC(10, 2) DEFAULT 0,
        advance_deduction NUMERIC(10, 2) DEFAULT 0,
        recurring_adjustments NUMERIC(10, 2) DEFAULT 0,
        last_month_balance NUMERIC(10, 2) DEFAULT 0,
        carried_forward_to_next NUMERIC(10, 2) DEFAULT 0,
        cash_paid NUMERIC(10, 2) DEFAULT 0,
        bank_paid NUMERIC(10, 2) DEFAULT 0,
        net_salary NUMERIC(10, 2) NOT NULL,
        paid_amount NUMERIC(10, 2) DEFAULT 0,
        status VARCHAR(20) DEFAULT 'Pending',
        paid_date TIMESTAMPTZ,
        notes TEXT,
        UNIQUE(employee_id, month)
      )
    `);

    // Ensure columns exist if table already existed
    try {
      await pool.query('ALTER TABLE employee_payroll_records ADD COLUMN IF NOT EXISTS dynamic_adjustments JSONB DEFAULT \'{}\'::jsonb');
      await pool.query('ALTER TABLE employee_payroll_records ADD COLUMN IF NOT EXISTS cash_paid NUMERIC(10, 2) DEFAULT 0');
      await pool.query('ALTER TABLE employee_payroll_records ADD COLUMN IF NOT EXISTS bank_paid NUMERIC(10, 2) DEFAULT 0');
      await pool.query('ALTER TABLE employee_payroll_records ADD COLUMN IF NOT EXISTS last_month_balance NUMERIC(10, 2) DEFAULT 0');
      await pool.query('ALTER TABLE employee_payroll_records ADD COLUMN IF NOT EXISTS payable_salary NUMERIC(10, 2) DEFAULT 0');
      await pool.query('ALTER TABLE employee_payroll_records ADD COLUMN IF NOT EXISTS carried_forward_to_next NUMERIC(10, 2) DEFAULT 0');
      await pool.query('ALTER TABLE employee_payroll_records ADD COLUMN IF NOT EXISTS total_adjustments NUMERIC(10, 2) DEFAULT 0');
      await pool.query('ALTER TABLE employee_payroll_records ADD COLUMN IF NOT EXISTS advance_deduction NUMERIC(10, 2) DEFAULT 0');
      await pool.query('ALTER TABLE employee_payroll_records ADD COLUMN IF NOT EXISTS recurring_adjustments NUMERIC(10, 2) DEFAULT 0');
    } catch (e) {}

    // Create payroll adjustment types table for dynamic columns
    await pool.query(`
      CREATE TABLE IF NOT EXISTS payroll_adjustment_types (
        id SERIAL PRIMARY KEY,
        label VARCHAR(100) UNIQUE NOT NULL,
        type VARCHAR(20) DEFAULT 'One-Time', -- 'One-Time' or 'Recurring'
        action VARCHAR(20) DEFAULT 'Add', -- 'Add', 'Deduct', or 'Both'
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Ensure 'Other (±)' column exists and rename 'Demo' if needed
    try {
      await pool.query(`
        UPDATE payroll_adjustment_types 
        SET label = 'Other', action = 'Both' 
        WHERE LOWER(label) = 'demo'
      `);

      const checkOther = await pool.query(`SELECT 1 FROM payroll_adjustment_types WHERE LOWER(label) = 'other'`);
      if (checkOther.rows.length === 0) {
        await pool.query(`INSERT INTO payroll_adjustment_types (label, type, action) VALUES ('Other', 'One-Time', 'Both')`);
      } else {
        await pool.query(`UPDATE payroll_adjustment_types SET action = 'Both' WHERE LOWER(label) = 'other'`);
      }
    } catch (e) {
      console.error('Notice on payroll adjustment types config:', e.message);
    }

    // Create employee_financial_adjustments table for one-time historical logs
    await pool.query(`
      CREATE TABLE IF NOT EXISTS employee_financial_adjustments (
        id SERIAL PRIMARY KEY,
        employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE,
        type VARCHAR(50) NOT NULL,
        custom_label VARCHAR(150),
        amount NUMERIC(10, 2) NOT NULL,
        action_type VARCHAR(20) NOT NULL, -- 'Give' or 'Deduct'
        date DATE NOT NULL,
        notes TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Create employee_payroll_payments table for individual payment logs / installments
    await pool.query(`
      CREATE TABLE IF NOT EXISTS employee_payroll_payments (
        id SERIAL PRIMARY KEY,
        employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE,
        month VARCHAR(7) NOT NULL,
        payment_method VARCHAR(20) NOT NULL, -- 'Cash' or 'Bank'
        amount NUMERIC(10, 2) NOT NULL,
        paid_by VARCHAR(100),
        notes TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    try {
      await pool.query('CREATE INDEX IF NOT EXISTS idx_employee_payroll_payments_emp_month ON employee_payroll_payments(employee_id, month)');
    } catch (e) {}

    // Create salary_audit_logs table for append-only audit tracking
    await pool.query(`
      CREATE TABLE IF NOT EXISTS salary_audit_logs (
        id SERIAL PRIMARY KEY,
        employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE,
        employee_name VARCHAR(150),
        employee_code VARCHAR(50),
        month VARCHAR(7),
        action VARCHAR(100) NOT NULL,
        previous_value TEXT,
        new_value TEXT,
        amount NUMERIC(10, 2),
        description TEXT,
        performed_by VARCHAR(100),
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    try {
      await pool.query('CREATE INDEX IF NOT EXISTS idx_salary_audit_logs_emp ON salary_audit_logs(employee_id)');
      await pool.query('CREATE INDEX IF NOT EXISTS idx_salary_audit_logs_month ON salary_audit_logs(month)');
      await pool.query('CREATE INDEX IF NOT EXISTS idx_salary_audit_logs_created ON salary_audit_logs(created_at DESC)');
    } catch (e) {}

    // Create credit_audit_logs table for Khata adjustments & balance reset tracking
    await pool.query(`
      CREATE TABLE IF NOT EXISTS credit_audit_logs (
        id SERIAL PRIMARY KEY,
        transaction_id INTEGER REFERENCES credit_transactions(id) ON DELETE SET NULL,
        credit_customer_id INTEGER REFERENCES credit_customers(id) ON DELETE CASCADE,
        action VARCHAR(50) NOT NULL,
        performed_by VARCHAR(100) NOT NULL,
        performed_by_role VARCHAR(50),
        previous_values JSONB,
        new_values JSONB,
        reason TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    try {
      await pool.query('CREATE INDEX IF NOT EXISTS idx_credit_audit_customer ON credit_audit_logs(credit_customer_id)');
      await pool.query('CREATE INDEX IF NOT EXISTS idx_credit_audit_created ON credit_audit_logs(created_at DESC)');
      await pool.query('ALTER TABLE credit_transactions ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ, ADD COLUMN IF NOT EXISTS updated_by VARCHAR(100)');
    } catch (e) {}

    // Create activity_logs table for unified central activity tracking
    await pool.query(`
      CREATE TABLE IF NOT EXISTS activity_logs (
        id SERIAL PRIMARY KEY,
        module VARCHAR(50) NOT NULL,
        action VARCHAR(100) NOT NULL,
        entity_id VARCHAR(100),
        entity_name VARCHAR(255),
        description TEXT,
        reason TEXT,
        old_data JSONB,
        new_data JSONB,
        performed_by VARCHAR(100),
        branch VARCHAR(100),
        month VARCHAR(7),
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    try {
      await pool.query('CREATE INDEX IF NOT EXISTS idx_activity_logs_module ON activity_logs(module)');
      await pool.query('CREATE INDEX IF NOT EXISTS idx_activity_logs_created ON activity_logs(created_at DESC)');
      await pool.query('CREATE INDEX IF NOT EXISTS idx_activity_logs_month ON activity_logs(month)');
    } catch (e) {}

    // Ensure columns exist if table was created previously without them
    try {
      await pool.query('ALTER TABLE employee_financial_adjustments ADD COLUMN custom_label VARCHAR(150)');
    } catch (e) {}
    try {
      await pool.query('ALTER TABLE employee_financial_adjustments ADD COLUMN notes TEXT');
    } catch (e) {}

    // Create employee_recurring_adjustments table for monthly automated cuts
    await pool.query(`
      CREATE TABLE IF NOT EXISTS employee_recurring_adjustments (
        id SERIAL PRIMARY KEY,
        employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE,
        type VARCHAR(50) NOT NULL,
        custom_label VARCHAR(150),
        amount NUMERIC(10, 2) NOT NULL,
        amount_type VARCHAR(20) DEFAULT 'Fixed', -- 'Fixed' or 'Percentage'
        action_type VARCHAR(20) NOT NULL, -- 'Give' or 'Deduct'
        remaining_amount NUMERIC(10, 2), -- For loans tracking
        start_date DATE NOT NULL,
        end_date DATE,
        notes TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Ensure columns exist if table was created previously without them
    try {
      await pool.query('ALTER TABLE employee_recurring_adjustments ADD COLUMN custom_label VARCHAR(150)');
    } catch (e) {}
    try {
      await pool.query('ALTER TABLE employee_recurring_adjustments ADD COLUMN amount_type VARCHAR(20) DEFAULT \'Fixed\'');
    } catch (e) {}
    try {
      await pool.query('ALTER TABLE employee_recurring_adjustments ADD COLUMN notes TEXT');
    } catch (e) {}
    try {
      await pool.query('ALTER TABLE employee_recurring_adjustments ADD COLUMN start_date DATE DEFAULT CURRENT_DATE');
    } catch (e) {}
    try {
      await pool.query('ALTER TABLE employee_recurring_adjustments ADD COLUMN end_date DATE');
    } catch (e) {}

    // Create item_categories schema and migrate existing data
    await pool.query(`
      CREATE TABLE IF NOT EXISTS item_categories (
        item_id INTEGER REFERENCES items(id) ON DELETE CASCADE,
        category_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
        PRIMARY KEY (item_id, category_id)
      )
    `);

    // Migrate existing data if category_id exists in items
    await pool.query(`
      INSERT INTO item_categories (item_id, category_id)
      SELECT id, category_id FROM items WHERE category_id IS NOT NULL
      ON CONFLICT DO NOTHING
    `);

    // Create tables schema
    await pool.query(`
      CREATE TABLE IF NOT EXISTS tables (
        id SERIAL PRIMARY KEY,
        table_number VARCHAR(50) NOT NULL UNIQUE,
        status VARCHAR(20) DEFAULT 'Active',
        available_branches JSONB DEFAULT '["Branch 1", "Branch 2", "Branch 3"]'::jsonb,
        sort_order INT DEFAULT 0,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Ensure sort_order column exists
    await pool.query(`ALTER TABLE tables ADD COLUMN IF NOT EXISTS sort_order INT DEFAULT 0`);

    // Pre-fill 1 to 20 tables if the table is completely empty
    const checkTables = await pool.query('SELECT COUNT(*) FROM tables');
    if (parseInt(checkTables.rows[0].count) === 0) {
      for (let i = 1; i <= 20; i++) {
        await pool.query('INSERT INTO tables (table_number, sort_order) VALUES ($1, $2)', [String(i), i]);
      }
      console.log('Migrated: Auto-created default tables 1 to 20');
    }

    // Auto-verify Order Sequences ranges per branch
    try {
      await pool.query(`CREATE SEQUENCE IF NOT EXISTS order_id_branch_1 START 100000;`);
      await pool.query(`CREATE SEQUENCE IF NOT EXISTS order_id_branch_2 START 200000;`);
      await pool.query(`CREATE SEQUENCE IF NOT EXISTS order_id_branch_3 START 300000;`);

      const s1 = await pool.query("SELECT last_value FROM order_id_branch_1");
      if (s1.rows.length && Number(s1.rows[0].last_value) < 100000) {
        await pool.query("ALTER SEQUENCE order_id_branch_1 RESTART WITH 100000;");
      }
      const s2 = await pool.query("SELECT last_value FROM order_id_branch_2");
      if (s2.rows.length && Number(s2.rows[0].last_value) < 200000) {
        await pool.query("ALTER SEQUENCE order_id_branch_2 RESTART WITH 200000;");
      }
      const s3 = await pool.query("SELECT last_value FROM order_id_branch_3");
      if (s3.rows.length && Number(s3.rows[0].last_value) < 300000) {
        await pool.query("ALTER SEQUENCE order_id_branch_3 RESTART WITH 300000;");
      }
    } catch (seqErr) {
      console.warn('⚠️ Order sequences verification warning:', seqErr.message);
    }

    // Create Internal Branch Transfer Tables
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS internal_branch_transfers (
          id SERIAL PRIMARY KEY,
          transfer_id VARCHAR(50) UNIQUE NOT NULL,
          from_branch VARCHAR(100) NOT NULL,
          to_branch VARCHAR(100) NOT NULL,
          requested_by_user_id INTEGER,
          requested_by_name VARCHAR(150),
          request_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
          needed_by_time VARCHAR(50),
          status VARCHAR(30) DEFAULT 'Pending',
          dispatched_at TIMESTAMPTZ,
          dispatched_by_user_id INTEGER,
          dispatched_by_name VARCHAR(150),
          received_at TIMESTAMPTZ,
          received_by_user_id INTEGER,
          received_by_name VARCHAR(150),
          notes TEXT,
          created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_ibt_from_branch ON internal_branch_transfers(from_branch);
        CREATE INDEX IF NOT EXISTS idx_ibt_to_branch ON internal_branch_transfers(to_branch);
        CREATE INDEX IF NOT EXISTS idx_ibt_status ON internal_branch_transfers(status);
        CREATE INDEX IF NOT EXISTS idx_ibt_request_date ON internal_branch_transfers(request_date);

        CREATE TABLE IF NOT EXISTS internal_branch_transfer_items (
          id SERIAL PRIMARY KEY,
          transfer_id INTEGER REFERENCES internal_branch_transfers(id) ON DELETE CASCADE,
          item_id INTEGER REFERENCES items(id) ON DELETE SET NULL,
          dish_name VARCHAR(255) NOT NULL,
          uom VARCHAR(50) NOT NULL,
          requested_qty NUMERIC(12,3) NOT NULL,
          sent_qty NUMERIC(12,3),
          received_qty NUMERIC(12,3),
          variance_qty NUMERIC(12,3),
          remarks TEXT,
          image_url TEXT,
          price NUMERIC(10,2),
          created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_ibti_transfer_id ON internal_branch_transfer_items(transfer_id);

        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS is_external BOOLEAN DEFAULT FALSE;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS expected_delivery_at TIMESTAMPTZ;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS delivery_minutes INTEGER DEFAULT 30;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS processing_started_at TIMESTAMPTZ;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS processing_started_by_user_id INTEGER;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS processing_started_by_name VARCHAR(150);
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS ready_for_dispatch_at TIMESTAMPTZ;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS ready_by_name VARCHAR(150);
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS handover_by_name VARCHAR(150);
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS handover_to_name VARCHAR(150);
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS original_delivery_at TIMESTAMPTZ;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS time_extended_at TIMESTAMPTZ;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS time_extended_by_name VARCHAR(150);
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS time_extend_reason TEXT;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS discrepancy_reason TEXT;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS extension_status VARCHAR(30) DEFAULT 'None';
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS pending_extension_minutes INTEGER;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS pending_extension_reason TEXT;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS pending_extension_requested_by INTEGER;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS pending_extension_requested_by_name VARCHAR(150);
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS pending_extension_requested_at TIMESTAMPTZ;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS total_extended_minutes INTEGER DEFAULT 0;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS original_delivery_minutes INTEGER DEFAULT 30;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS original_needed_by_time VARCHAR(50);
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS extension_reviewed_by_name VARCHAR(150);
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS extension_reviewed_at TIMESTAMPTZ;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS extension_rejection_reason TEXT;
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS request_type VARCHAR(50) DEFAULT 'Transfer Request';
        ALTER TABLE internal_branch_transfers ADD COLUMN IF NOT EXISTS priority VARCHAR(20) DEFAULT 'Normal';

        ALTER TABLE internal_branch_transfer_items ADD COLUMN IF NOT EXISTS confirmed_qty NUMERIC(12,3);
        ALTER TABLE internal_branch_transfer_items ADD COLUMN IF NOT EXISTS quantity_change_reason TEXT;
        ALTER TABLE internal_branch_transfer_items ADD COLUMN IF NOT EXISTS image_url TEXT;
        ALTER TABLE internal_branch_transfer_items ADD COLUMN IF NOT EXISTS price NUMERIC(10,2);
        ALTER TABLE internal_branch_transfer_items ADD COLUMN IF NOT EXISTS sku VARCHAR(100);
        ALTER TABLE internal_branch_transfer_items ADD COLUMN IF NOT EXISTS barcode VARCHAR(100);

        CREATE TABLE IF NOT EXISTS internal_branch_activity_logs (
          id SERIAL PRIMARY KEY,
          transfer_id INTEGER REFERENCES internal_branch_transfers(id) ON DELETE CASCADE,
          action VARCHAR(50) NOT NULL,
          from_branch VARCHAR(100),
          to_branch VARCHAR(100),
          performed_by_id INTEGER,
          performed_by_name VARCHAR(150),
          details TEXT,
          metadata JSONB,
          created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_ibal_transfer_id ON internal_branch_activity_logs(transfer_id);

        ALTER TABLE internal_branch_activity_logs ADD COLUMN IF NOT EXISTS user_role VARCHAR(50);
        ALTER TABLE internal_branch_activity_logs ADD COLUMN IF NOT EXISTS previous_value TEXT;
        ALTER TABLE internal_branch_activity_logs ADD COLUMN IF NOT EXISTS new_value TEXT;
        ALTER TABLE internal_branch_activity_logs ADD COLUMN IF NOT EXISTS reason TEXT;

        CREATE TABLE IF NOT EXISTS shift_closing_audit_logs (
          id SERIAL PRIMARY KEY,
          shift_closing_id INTEGER REFERENCES shift_closings(id) ON DELETE CASCADE,
          shift_id INTEGER,
          branch VARCHAR(100),
          edited_by_user_id INTEGER,
          edited_by_name VARCHAR(150),
          user_role VARCHAR(50),
          previous_cash NUMERIC(12,2),
          updated_cash NUMERIC(12,2),
          previous_card NUMERIC(12,2),
          updated_card NUMERIC(12,2),
          previous_difference NUMERIC(12,2),
          updated_difference NUMERIC(12,2),
          reason TEXT NOT NULL,
          created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_scal_shift_closing_id ON shift_closing_audit_logs(shift_closing_id);
      `);
    } catch (tblErr) {
      console.warn('⚠️ Internal Branch / Audit tables verification warning:', tblErr.message);
    }

    console.log('✅ Database schema verified: all columns and constraints up to date.');
  } catch (err) {
    throw err; // Let runWithStartupRetry handle it
  }
  }); // end runWithStartupRetry
})();

const app = express();
const PORT = process.env.PORT || 5000;
const http = require('http');
const { Server } = require('socket.io');

const server = http.createServer(app);

// CORS — allowed origins (add your deployed frontend URLs here)
const ALLOWED_ORIGINS = [
  'http://localhost:5173',
  'http://localhost:3000',
  // Production Hostinger & domain deployments
  'https://alrawaq.zivoxtech.com',
  'https://alrawaqrestaurant.zivoxtech.com',
  /https:\/\/.*\.zivoxtech\.com$/,
  // Vercel deployments
  'https://ddnjj.vercel.app',
  'https://1-mu-pink.vercel.app',
  'https://alrawaq.vercel.app',
  // Allow any Vercel preview URLs for this project
  /https:\/\/.*\.vercel\.app$/,
  // Custom FRONTEND_URL from env (if set, supports comma-separated values)
  ...(process.env.FRONTEND_URL ? process.env.FRONTEND_URL.split(',').map(url => url.trim()) : []),
];

app.use(cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (e.g. mobile apps, curl, Postman)
    if (!origin) return callback(null, true);
    const allowed = ALLOWED_ORIGINS.some(o =>
      typeof o === 'string' ? o === origin : (o instanceof RegExp ? o.test(origin) : false)
    ) || origin.includes('zivoxtech.com') || origin.includes('vercel.app') || origin.includes('localhost');
    if (allowed) return callback(null, true);
    callback(new Error(`CORS blocked: ${origin}`));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Cache-Control', 'Pragma', 'Expires'],
}));

// Handle preflight for all routes
app.options('*', cors());

app.use(express.json({ limit: '10mb' }));

// Serve uploads directory statically
const path = require('path');
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Disable caching for all API responses
app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

const io = new Server(server, {
  cors: {
    origin: (origin, callback) => {
      if (!origin) return callback(null, true);
      const allowed = ALLOWED_ORIGINS.some(o =>
        typeof o === 'string' ? o === origin : (o instanceof RegExp ? o.test(origin) : false)
      ) || origin.includes('zivoxtech.com') || origin.includes('vercel.app') || origin.includes('localhost');
      if (allowed) return callback(null, true);
      callback(new Error(`Socket.io CORS blocked: ${origin}`));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS']
  },
  transports: ['polling', 'websocket'],
  allowEIO3: true
});

io.on('connection', (socket) => {
  console.log(`🔌 Socket.io client connected: ${socket.id}`);
  socket.on('disconnect', () => {
    console.log(`🔌 Socket.io client disconnected: ${socket.id}`);
  });
});

// Middleware to expose io to routes
app.use((req, res, next) => {
  req.io = io;
  next();
});

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/categories', require('./routes/categories'));
app.use('/api/items', require('./routes/items'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/transactions', require('./routes/transactions'));
app.use('/api/stats', require('./routes/stats'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/stock', require('./routes/stock'));
app.use('/api/upload', require('./routes/upload'));
app.use('/api/recipes', require('./routes/recipes'));
app.use('/api/support', require('./routes/support'));
app.use('/api/employees', require('./routes/employees'));
app.use('/api/attendance', require('./routes/attendance'));
app.use('/api/payroll', require('./routes/payroll'));
app.use('/api/tables', require('./routes/tables'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/credit', require('./routes/credit'));
app.use('/api/employee-portal', require('./routes/employeePortal'));
app.use('/api/logs', require('./routes/activityLogs').router);
app.use('/api/activity-logs', require('./routes/activityLogs').router);
app.use('/api/internal-branch', require('./routes/internalBranch'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal Server Error' });
});

let listenAttempts = 0;
const MAX_LISTEN_RETRIES = 10;

function startListening() {
  server.listen(PORT, () => {
    console.log(`🍕 Pizza Shop Server running on http://localhost:${PORT}`);
    initCron();
  });
}

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    listenAttempts++;
    if (listenAttempts <= MAX_LISTEN_RETRIES) {
      console.warn(`⚠️ Port ${PORT} is currently in use, retrying in 1.5s... (attempt ${listenAttempts}/${MAX_LISTEN_RETRIES})`);
      setTimeout(() => {
        try { server.close(); } catch (_) {}
        startListening();
      }, 1500);
      return;
    }
    console.error(`❌ Port ${PORT} is still in use after ${MAX_LISTEN_RETRIES} retries.`);
    console.error(`👉 PowerShell mein yeh command run karein: Stop-Process -Id (Get-NetTCPConnection -LocalPort ${PORT}).OwningProcess -Force`);
    process.exit(1);
  } else {
    console.error('❌ Server error:', err);
    process.exit(1);
  }
});

startListening();


