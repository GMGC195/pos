require('dotenv').config();
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function test() {
  const params = ['2026-09-01', '2026-09-13'];
  let query = `
    SELECT t.payment_method, COUNT(*) as count, SUM(t.amount) as total 
    FROM transactions t
    JOIN orders o ON t.order_id = o.id
    WHERE 1=1 AND t.created_at >= $1::date AND t.created_at < ($2::date + INTERVAL '1 day')
    GROUP BY t.payment_method
  `;
  try {
    const res = await pool.query(query, params);
    console.table(res.rows);
  } catch (err) {
    console.error(err);
  }
  pool.end();
}
test();
