const express = require('express');
const router = express.Router();
const pool = require('../db');
const { authenticateToken, blockSalaryPayOperator } = require('../middleware/auth');
router.use(blockSalaryPayOperator);

function normalizeBranch(b) {
  if (!b) return null;
  const lower = String(b).trim().toLowerCase();
  if (lower === 'restaurant 1' || lower === 'r1') return 'Branch 1';
  if (lower === 'restaurant 2' || lower === 'r2') return 'Branch 2';
  if (lower === 'restaurant 3' || lower === 'r3') return 'Branch 3';
  return b.trim();
}

// GET all items with category name
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { category, search, all } = req.query;
    // Branch isolation for Order Taker / Operator / Cashier
    const userRole = req.user.role?.trim().toLowerCase();
    const userBranch = req.user.branch;
    
    let targetBranch = null;

    if (all === 'true') {
      targetBranch = null; // Unrestricted centralized catalog requested
    } else if (['order taker', 'operator', 'cashier'].includes(userRole) && userBranch) {
      targetBranch = normalizeBranch(userBranch);
    } else if (req.query.branch && req.query.branch !== 'All') {
      targetBranch = normalizeBranch(req.query.branch);
    }

    let query = `
      SELECT i.*, 
        (SELECT json_agg(c.name) FROM categories c JOIN item_categories ic ON c.id = ic.category_id WHERE ic.item_id = i.id) as category_names,
        (SELECT json_agg(ic.category_id) FROM item_categories ic WHERE ic.item_id = i.id) as category_ids,
        COALESCE(s.sold_qty, 0) as sold_qty
      FROM items i
      LEFT JOIN (
        SELECT oi.item_id, SUM(oi.qty) as sold_qty
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        WHERE o.status = 'Completed' 
    `;
    const params = [];

    if (targetBranch) {
      params.push(targetBranch);
      query += ` AND o.branch = $${params.length}`;
    }
    
    query += `
        GROUP BY oi.item_id
      ) s ON s.item_id = i.id
      WHERE 1=1
    `;

    if (targetBranch) {
      params.push(`%"${targetBranch}"%`);
      query += ` AND (i.available_branches IS NULL OR i.available_branches::text = '[]' OR i.available_branches::text = 'null' OR i.available_branches::text LIKE $${params.length})`;
    }

    if (category && category !== 'All') {
      params.push(category);
      query += ` AND EXISTS (SELECT 1 FROM item_categories ic JOIN categories cat ON cat.id = ic.category_id WHERE ic.item_id = i.id AND cat.name = $${params.length})`;
    }

    if (search) {
      params.push(`%${search}%`);
      query += ` AND i.name ILIKE $${params.length}`;
    }

    query += ' ORDER BY sold_qty DESC, i.id ASC';
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single item
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT i.*, 
        (SELECT json_agg(c.name) FROM categories c JOIN item_categories ic ON c.id = ic.category_id WHERE ic.item_id = i.id) as category_names,
        (SELECT json_agg(ic.category_id) FROM item_categories ic WHERE ic.item_id = i.id) as category_ids
       FROM items i WHERE i.id = $1`,
      [req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Item not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create item
router.post('/', authenticateToken, async (req, res) => {
  let { category_id, category_ids, name, price, image_url, size_options, status, short_code } = req.body;
  if (!category_ids && category_id) category_ids = [category_id];
  if (!category_ids) category_ids = [];
  
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    let available_branches = ['Branch 1', 'Branch 2', 'Branch 3'];
    const userRole = req.user.role?.trim().toLowerCase();
    if (['order taker', 'operator', 'cashier'].includes(userRole) && req.user.branch) {
      available_branches = [req.user.branch];
    }

    const result = await client.query(
      `INSERT INTO items (category_id, name, price, image_url, size_options, status, available_branches, short_code)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [category_id || null, name, price, image_url || '', size_options || [], status || 'Active', JSON.stringify(available_branches), short_code || '']
    );
    const newItem = result.rows[0];

    for (const catId of category_ids) {
      await client.query('INSERT INTO item_categories (item_id, category_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [newItem.id, catId]);
    }

    await client.query('COMMIT');
    res.status(201).json(newItem);
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
});

// PUT update item
router.put('/:id', authenticateToken, async (req, res) => {
  let { category_id, category_ids, name, price, image_url, size_options, status, short_code } = req.body;
  if (!category_ids && category_id) category_ids = [category_id];
  if (!category_ids) category_ids = [];
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // 1. Fetch current item
    const currentItemRes = await client.query('SELECT * FROM items WHERE id = $1', [req.params.id]);
    if (currentItemRes.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Item not found' });
    }
    const currentItem = currentItemRes.rows[0];

    const isRestrictedRole = ['order taker', 'operator', 'cashier'].includes(req.user.role?.trim().toLowerCase());
    const userBranch = req.user.branch;
    let availableBranches = currentItem.available_branches || [];

    // If it's a restricted user and the item is shared with other branches
    if (isRestrictedRole && availableBranches.length > 1 && availableBranches.includes(userBranch)) {
      // Remove this branch from the original item
      const newOriginalBranches = availableBranches.filter(b => b !== userBranch);
      await client.query('UPDATE items SET available_branches = $1 WHERE id = $2', [JSON.stringify(newOriginalBranches), req.params.id]);

      // Create a new item for this branch with the updated details
      const createResult = await client.query(
        `INSERT INTO items (category_id, name, price, image_url, size_options, status, available_branches, short_code)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
        [category_id, name, price, image_url || '', size_options || [], status || 'Active', JSON.stringify([userBranch]), short_code || '']
      );
      
      const newItem = createResult.rows[0];

      // Copy recipes from old item to new item
      const recipesRes = await client.query('SELECT * FROM recipes WHERE item_id = $1', [req.params.id]);
      for (const recipe of recipesRes.rows) {
        await client.query(
          'INSERT INTO recipes (item_id, stock_id, quantity_used, size_label) VALUES ($1, $2, $3, $4)',
          [newItem.id, recipe.stock_id, recipe.quantity_used, recipe.size_label]
        );
      }

      // Add item categories for the new item
      for (const catId of category_ids) {
        await client.query('INSERT INTO item_categories (item_id, category_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [newItem.id, catId]);
      }

      await client.query('COMMIT');
      return res.json(newItem);
    } else {
      // Normal update
      const result = await client.query(
        `UPDATE items SET category_id=$1, name=$2, price=$3, image_url=$4, size_options=$5, status=$6, short_code=$7
         WHERE id=$8 RETURNING *`,
        [category_id || null, name, price, image_url || '', size_options || [], status || 'Active', short_code || '', req.params.id]
      );
      
      // Update item_categories
      await client.query('DELETE FROM item_categories WHERE item_id = $1', [req.params.id]);
      for (const catId of category_ids) {
        await client.query('INSERT INTO item_categories (item_id, category_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [req.params.id, catId]);
      }

      await client.query('COMMIT');
      res.json(result.rows[0]);
    }
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
});

// PATCH update available branches
router.patch('/:id/branches', authenticateToken, async (req, res) => {
  const { available_branches } = req.body;
  try {
    const result = await pool.query(
      'UPDATE items SET available_branches = $1 WHERE id = $2 RETURNING *',
      [JSON.stringify(available_branches), req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Item not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE item
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    await pool.query('DELETE FROM items WHERE id = $1', [req.params.id]);
    res.json({ message: 'Item deleted successfully' });
  } catch (err) {
    if (err.code === '23503') {
      return res.status(409).json({ error: 'Item is mapped to past orders/recipes. Please set status to "Inactive" instead.' });
    }
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
